<?php
global $command;
$theHost = str_replace("www.", "", $_SERVER["HTTP_HOST"]);
$theServer = php_uname('n')."_".$_SERVER['SERVER_ADDR'];
$thisDir = __DIR__;
$scriptBase = $_SERVER['PHP_SELF'];//web name of running script 
$scriptPath = dirname($scriptBase);//web directory of running script
$docRoot = $_SERVER['DOCUMENT_ROOT'];

$protocol="http".((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS']=='on')?"s":"")."://";

$myGlobals = array(
    'command'=>$command,
    'theHost'=>$theHost,
    'siteProtocol'=>$protocol,
    'theServer'=>$theServer,
    'thePort'=> $_SERVER['SERVER_PORT'],
    'thisDir'=>$thisDir,
    'thisURL'=>$_SERVER['REQUEST_URI'],
    'scriptBase'=>$scriptBase,
    'libraries'=>'lib',
    'include'=>'inc',
    'getURI' => (isset($_GET['url'])? $_GET['url'] : null),
    'requestMethod'=> $_SERVER['REQUEST_METHOD'],
    'site'=>'site',
    'domainName'=>'cityhoppers.com.ng',
    'companyName'=> 'CityHoppers',
    'media'=>'media',
    'inc'=>'inc',
    'siteName'=>'cityhoppers',
    'templateFolder'=>'base',
    'dashboard'=>'dashboard',
    'admin'=>'root',
    'baselinePath'=>"/home/kinroya1/cityhoppers.com.ng",
    'dbName'=> 'kinroya1_cityhoppers',
    'dbHost'=> 'localhost',
    'dbUser'=> 'kinroya1_cityhoppers',
    'dbPass'=> 'nM$S?.jwEmNR',
    'sitePage'=>'home',
    'dateNow'=>date("Y-m-d H:i:s"),
    'dateNow2'=>date("Y-m-d"),
    'nextThursday'=>date("Y-m-d H:i:s", strtotime("next thursday")),
    'nextMonday'=>date("Y-m-d H:i:s", strtotime("next monday")),
    'lastThursday'=>date("Y-m-d H:i:s", strtotime("previous thursday")),
    'lastMonday'=>date("Y-m-d H:i:s", strtotime("previous monday")),
    'today'=> date('l')

);
foreach ($myGlobals as $key => $value) {
    $$key = $value;
}
