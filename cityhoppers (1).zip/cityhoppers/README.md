About Us:
CityHoppers is a startup company founded in 2019 by a group of investors with a mission to provide high quality inter-state transportation services within Nigeria.
CityHoppers aims to provide organized and comfortable road travel options for clients using luxurious Coach buses. Cityhoppers is the outcome of many years of careful study and planning with the sole aim of elevating travel experiences to a pleasant, relaxed and efficient experience. Much effort and thoughts have been invested in eliminating undesirable and stressful issues which may have been considered a norm with other land travel experiences.
At CityHoppers, special considerations and business processes have been designed to ensure excellent service and delivery. CityHoppers aims to be the ultimate service provider of choice for the corporate sector, executives and business community. Our priorities encompass all of our client's concerns which include:

Comfort 

Reliability

Affordability

Safety

Security 

Punctuality 

------------
To DO List
-----------
Time Elapse Interval Settings Admin
Update Steeing Accross Board for All Booking Section
Implements The Seat Recovery For All Un Completed Bookings