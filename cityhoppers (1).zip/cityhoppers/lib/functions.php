<?php

function getSession(){
  global $Site;
  $return=null;
  if ( !empty($Site["session"]['Site']) ) {
      $return=$Site["session"];
  }else{
    @session_destroy();
  }
  return $return;
}

function setSession($value) {
  global $Site;
  $_SESSION["Site"] = $value;
  $Site["session"] = $_SESSION;
}

function sessionExists($session){
  global $ezDb,$siteName;
  $return=null;
  if( !empty($ezDb->get_var("SELECT `token` FROM `userprofile` WHERE `token`='".sha1(md5(base64_encode($session)))."';")) ):
    $return=true;
  endif;
  return $return;
}

function setCookies($name,$value=null,$second=86400){
   setcookie($name, $value, time() + ($second), "/");
}

function getCookie($name){
   $cookie=null;
   if(isset($_COOKIE[$name])):
      $cookie = $_COOKIE[$name];
      if(empty($cookie)):
         unset($_COOKIE[$name]);
         $cookie = null;
      endif;
   endif;
   return $cookie;
}

function destroyCookie($name){
   if( isset($_COOKIE[$name]) ){
      $_COOKIE[$name]="";
      setCookies($name, "", time() - 3600);
      unset($_COOKIE[$name]);
   }
}

function useIfPosted($theField, $theDefaultValue = "") {
  if (isset($_POST["$theField"])) {
      return filter_var($_POST["$theField"], FILTER_SANITIZE_STRING);
  } else {
      return $theDefaultValue;
  }
}

function useIfIntPosted($theField, $theDefaultValue = "") {
  if (isset($_POST["$theField"])) {
      return filter_var($_POST["$theField"], FILTER_SANITIZE_NUMBER_INT);
  } else {
      return $theDefaultValue;
  }
}

function useIfSent($theField, $theDefaultValue = "") {
  //works? like use_if_posted but for all post/get  form variables
  if (isset($_REQUEST["$theField"])) {
      return filter_var($_REQUEST["$theField"], FILTER_SANITIZE_STRING);
  } else {
      return $theDefaultValue;
  }
}

function useIfIntSent($theField, $theDefaultValue = "") {
  if (isset($_REQUEST["$theField"]) && $_REQUEST["$theField"] != "") {
      return filter_var($_REQUEST["$theField"], FILTER_SANITIZE_NUMBER_INT);
  } else {
      return $theDefaultValue;
  }
}

function checkEmail($email) {
   return filter_var($email, FILTER_VALIDATE_EMAIL);
}

function checkPhone($phone){
    // Alt preg_match('/^[A-z0-9_\-]+[@][A-z0-9_\-]+([.][A-z0-9_\-]+)+[A-z.]{2,4}$/', $email);
     // Allow +, - and . in phone number
     $filtered_phone_number = filter_var($phone, FILTER_SANITIZE_NUMBER_INT);
     // Remove "-" from number
     $phone_to_check = str_replace("-", "", $filtered_phone_number);
     $phone_to_check = str_replace(")", "", $phone_to_check);
     $phone_to_check = str_replace("(", "", $phone_to_check);
     // Check the lenght of number
     // This can be customized if you want phone number from a specific country
     if (strlen($phone_to_check) < 10 || strlen($phone_to_check) > 14) {
        return false;
     } else {
       return true;
     }
}

function useIfExists($filename, $actionFilename, $alternative = "", $actionAlternative = "") {
   //phase out in favour of use_if
   //echo("$filename $alternative $actionFilename $actionAlternative"); //debug
   if (file_exists($filename)) {
      //        echo("file exists, doing $actionFilename($filename)"); //debug
      $theFunction = $actionFilename;
      //        echo $theFunction.",".$filename;//debug
   } else {
      if ($alternative != "") {
         $filename = $alternative;
      }
      //        echo("doesn't exist, using alternative: $actionFilename($alternative)");//debug
      if ($actionAlternative != "") {
         $theFunction = $actionAlternative;
      }
   }
   if (isset($theFunction)) {
      $theFunction("$filename");
   }
   //    echo("$actionFilename($filename)");//debug
}

function includeIt($filename) {
  include $filename;
}

function requireIt($filename) {
  require $filename;
}

function redirect($theUrl) {
  header("Location: $theUrl");
  exit;
}

function cryptoRandSecure($min, $max) {
   //http://us1.php.net/manual/en/function.openssl-random-pseudo-bytes.php#104322
   $range = $max - $min;
   if ($range < 0) {
      return $min; // not so random...
   } $log = log($range, 2);
   $bytes = (int) ($log / 8) + 1; // length in bytes
   $bits = (int) $log + 1; // length in bits
   $filter = (int) (1 << $bits) - 1; // set all lower bits to 1
   do {
      $rnd = hexdec(bin2hex(openssl_random_pseudo_bytes($bytes)));
      $rnd = $rnd & $filter; // discard irrelevant bits
   } while ($rnd >= $range);
   return $min + $rnd;
}

function getToken($length) {
    //http://us1.php.net/manual/en/function.openssl-random-pseudo-bytes.php#104322
    $token = "";
    $codeAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $codeAlphabet.= "abcdefghijklmnopqrstuvwxyz";
    $codeAlphabet.= "0123456789";
    for ($i = 0; $i < $length; $i++) {
        $token .= $codeAlphabet[cryptoRandSecure(0, strlen($codeAlphabet))];
    }
    return $token;
}

function testInput($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data, ENT_QUOTES);
  return $data;
}

// smarty display function;

function smartyDisplay($template){
  global $smarty;
  if ($smarty->templateExists($template)==true) {
    $smarty->display($template);
  } elseif($smarty->templateExists($template)==false){
      $smarty->display("default.html");
  }
}

//logout control
function logoutUser($page="login"){
  global $Site;
  unset($Site["session"]["User"]);
  unset($Site["session"]['Site']["Page"]);
  $_SESSION=$Site["session"];
  redirect("$page");
}

// login authentication function
function loginUser(){
  global $ezDb, $siteName, $dashboard, $admin, $smarty, $Site, $domainName, $siteProtocol, $sitePage;
  $userName=$Site["post"]['dataUsername'];
  $password=$Site["post"]['dataPass'];
  $userType= ($sitePage=="admin"? 'admin': 'client');
  if( $data=$ezDb->get_row("SELECT `password`,`username` FROM `userprofile` WHERE (`username`='$userName' OR `email`='$userName') AND `usertype`='$userType' AND `verified`='1';") ){
    if( $data->password==base64_encode($password) ){
      $Site["session"]['User'][$userType]['Token'] = getToken(6);
      $ezDb->query("UPDATE `userprofile` SET `token`='".sha1(md5(base64_encode($Site["session"]["User"][$userType]["Token"])))."' WHERE `username`='$data->username';");
      $Site["session"]["User"]["Username"]=$data->username;
      $Site["session"]['Site']["Page"]= ($sitePage=="admin"? $admin: $dashboard);
      if($Site["session"]['Site']["Page"]==$dashboard){
        logVisit($data->username);
      }else{
        logEvent($data->username, '', 'Login', '');
      }
      $_SESSION=$Site["session"];
      return true;
    }else{
      $smarty->assign("fail",'Invalid username or password!');
    }
  }else{
    $smarty->assign("fail",'Invalid username or password!');
  }
}

//true logics
/*Latest Real Functions*/
// Delete Directory and Files
function deleteDirAndFilesInIt($target) {
  if(is_dir($target)){
      $files = glob( $target . '*', GLOB_MARK ); //GLOB_MARK adds a slash to directories returned

      foreach( $files as $file ){
          deleteDirAndFilesInIt( $file );      
      }
      if (file_exists($target)) {
        rmdir( $target );
      }
      return true;
  } elseif(is_file($target)) {
    if(file_exists($target)){
      unlink( $target );
    }
    return true;  
  }else{
    return false;
  }
}

//user user information functions
function userInfo($username=null) {
  global $ezDb, $Site, $smarty;
  $username = ( !empty($username)? $username: $Site["session"]["User"]["Username"] );

  $return =$ezDb->get_row("SELECT * FROM `userprofile` WHERE `username`='$username' OR `email`='$username';");

  if( !empty($return) ){
    if( !empty($Site["session"]["User"]) ){
      $return->profiledocs=json_decode($return->profiledocs);
      $return->initials= ucfirst( substr($return->firstname, 0,1) ) ."". ucfirst( substr($return->lastname, 0,1) );
      $Site["session"]["User"]["userinfo"] = $return;
    }
  }
  return $return;
}

function getSources($type='0', $token=null){
  global $ezDb, $Site, $smarty, $dateNow;
  //ignore the type for now
  if(!empty($token)){
    $return= $ezDb->get_col("SELECT DISTINCT `source` FROM `tripschedules` WHERE (`token`='$token' OR `source`='$token') AND TIMESTAMPDIFF(MINUTE, '$dateNow', `departure`)>30 ORDER BY `datemodified` DESC;");
  }else{
    $return= $ezDb->get_col("SELECT DISTINCT `source` FROM `tripschedules` WHERE TIMESTAMPDIFF(MINUTE, '$dateNow', `departure`)>30 ORDER BY `datemodified` DESC;");
  }
  return $return;
}

function getSources1($type='0', $token=null){
  global $ezDb, $Site, $smarty, $dateNow;
  //ignore the type for now
  if(!empty($token)){
    $return= $ezDb->get_col("SELECT DISTINCT `source` FROM `tripschedules1` WHERE (`token`='$token' OR `source`='$token') AND TIMESTAMPDIFF(MINUTE, '$dateNow', `departure`)>30 ORDER BY `datemodified` DESC;");
  }else{
    $return= $ezDb->get_col("SELECT DISTINCT `source` FROM `tripschedules1` WHERE TIMESTAMPDIFF(MINUTE, '$dateNow', `departure`)>30 ORDER BY `datemodified` DESC;");
  }
  return $return;
}

function getSourcesAndDestination($type='0', $source, $destination){
  global $ezDb, $Site, $smarty;
  $return= $ezDb->get_results("SELECT * FROM `tripschedules` WHERE `source`='$source' AND `destination`='$destination' ORDER BY `datemodified` DESC;");
  return $return;
}
// new
function getSourcesAndDestination1($type='0', $source, $destination){
  global $ezDb, $Site, $smarty;
  $nextFlt=/*($type=='1'? "OR (`source`='$destination' AND `destination`='$source')":"")*/"";
  $return= $ezDb->get_results("SELECT * FROM `tripschedules1` WHERE (`source`='$source' AND `destination`='$destination') $nextFlt ORDER BY `datemodified` DESC;");
  return $return;
}

function checkDepartureORReturnTime( $deptDate , $field='departure', $time=30){
  global $ezDb, $Site, $smarty, $dateNow;
  $return= $ezDb->get_var("SELECT COUNT(`$field`) FROM `tripschedules` WHERE TIMESTAMPDIFF(MINUTE, '$dateNow', `$field`)>$time ORDER BY `datemodified` DESC;");
  return $return;
}
// new
function checkDepartureORReturnTime1( $deptDate , $field='departure', $time=30){
  global $ezDb, $Site, $smarty, $dateNow;
  $return= $ezDb->get_var("SELECT COUNT(`$field`) FROM `tripschedules1` WHERE TIMESTAMPDIFF(MINUTE, '$dateNow', `$field`)>$time ORDER BY `datemodified` DESC;");
  return $return;
}

function dateDifference($lowerDate, $laterDate){
  $datetime1 = new DateTime($lowerDate);
  $datetime2 = new DateTime($laterDate);
  $return = $datetime1->diff($datetime2);
  $return = dateDiffToNum($return);
  // error_log(json_encode($return));
  return $return;
}
function dateDiffToNum($date,$property='min')
{
  // to be improved
  switch ($property) {
    case 'min':
      $date->min= (($date->d * 24 * 60)+ ($date->h * 60)+ ($date->i)+ ($date->m * 60)+ ($date->y * 60));
      break;
    
    default:
       $date->min= (($date->d * 24 * 60)+ ($date->h * 60)+ ($date->i)+ ($date->m * 60 * 24 * 28)+ ($date->y * 60 * 24 * 365));
      break;
  }
  // {"y":0,"m":0,"d":11,"h":7,"i":11,"s":0,"weekday":0,"weekday_behavior":0,"first_last_day_of":0,"invert":0,"days":11,"special_type":0,"special_amount":0,"have_weekday_relative":0,"have_special_relative":0}

  return $date;
}

function getDestinations($type='0', $source=null){//cleared
  global $ezDb, $Site, $smarty, $dateNow;
  // Ignore the type for now
  if(!empty($source)){
    $return= $ezDb->get_results("SELECT DISTINCT `destination` FROM `tripschedules` WHERE `source`='$source' AND `destination`!='$source' AND TIMESTAMPDIFF(MINUTE, '$dateNow', `departure`)>30 ORDER BY `datemodified` DESC;");
  }else{
    // $return= $ezDb->get_col("SELECT DISTINCT `destination` FROM `tripschedules` ORDER BY `datemodified` DESC;");
    $return=null;
  }
  return $return;
}
function getDestinations1($type='0', $source=null){//cleared
  global $ezDb, $Site, $smarty, $dateNow;
  // Ignore the type for now
  if(!empty($source)){
    $return= $ezDb->get_results("SELECT DISTINCT `destination` FROM `tripschedules1` WHERE `source`='$source' AND `destination`!='$source' AND TIMESTAMPDIFF(MINUTE, '$dateNow', `departure`)>30 ORDER BY `datemodified` DESC;");
  }else{
    $return=null;
  }
  return $return;
}

function getTicketDetails( $token=null){
  global $ezDb, $Site, $smarty, $dateNow;
  $return=false;
  if(!empty($token)){
    $return=$ezDb->get_row("SELECT `bk`.`bookinginfo`, `bk`.`bookingDate`, `bk`.`ticketNo`, `bk`.`client`, `bk`.`bookedBy`, `bk`.`noOfPerson`, `bk`.`totalFee`, `tb`.`search`, `tb`.`vehicle`, `tb`.`userdata`, `tb`.`ipaddress`, `tb`.`dateadded`, `tb`.`status`  FROM `booking1` AS `bk`, `temp_booking1` AS `tb` WHERE `bk`.`bookingtoken`=`tb`.`token` AND `tb`.`status`='1' AND (LOWER(`bk`.`ticketNo`)=LOWER('$token') OR `bk`.`ticketNo`='LOWER(".explode("_", $token)[0].")');");
    if (!empty($return)) {
      foreach ($return as $val) {
        $val->bookingInfo=json_decode($val->bookingInfo);
        $val->search=json_decode($val->search);
        $val->vehicle=json_decode($val->vehicle);
        $val->userdata=json_decode($val->userdata);
      }
    }
  }else{
     $return=$ezDb->get_results("SELECT `bk`.`bookingInfo`, `bk`.`bookingDate`, `bk`.`ticketNo`, `bk`.`client`, `bk`.`bookedBy`, `bk`.`noOfPersons`, `bk`.`totalFee`, `tb`.`search`, `tb`.`vehicle`, `tb`.`userdata`, `tb`.`ipaddress`, `tb`.`dateadded`, `tb`.`status` FROM `booking1` AS `bk`, `temp_booking1` AS `tb` WHERE `bk`.`bookingtoken`=`tb`.`token` ORDER BY `bk`.`bookingDate` DESC;");
   // error_log(0);
  }
  return $return;
}

function getTiming($type='0', $sources=null, $destination=null){
  global $ezDb, $Site, $smarty, $dateNow;
  // Use the type technology
  $theDDates=new StdClass();
  if(!empty($sources) and !empty($destination)){//%Y-%m-%dT%H:%i:%s
    $theDDates->departures= $ezDb->get_col("SELECT DISTINCT DATE_FORMAT(`departure`, '%Y-%m-%d') AS `departure`  FROM `tripschedules` WHERE `source`='$sources' AND `destination`='$destination' AND `type`='$type' AND TIMESTAMPDIFF(MINUTE,'$dateNow',`departure`)>30 ORDER BY `departure` ASC;");
    if($type=='1' or $type==1){
      $theDDates->returns= $ezDb->get_col("SELECT DISTINCT DATE_FORMAT(`return`, '%Y-%m-%d') AS `return` FROM `tripschedules` WHERE `source`='$sources' AND `destination`='$destination' AND `type`='$type' AND DATEDIFF(`return`,'$dateNow')>1  ORDER BY `return` ASC;");
    }
    // $ezDb->get_var("SELECT DISTINCT `departure` FROM `tripschedules` WHERE `source`='$sources' AND `destination`='$destination' AND `type`='$type' AND TIMESTAMPDIFF(MINUTE,'$dateNow',`departure`)>30 ORDER BY `datemodified` DESC;"); remove me
  }elseif(!empty($sources)){
    $theDDates->departures= $ezDb->get_col("SELECT DISTINCT DATE_FORMAT(`departure`, '%Y-%m-%d') AS `departure` FROM `tripschedules` WHERE `source`='$sources' AND `destination`='$destination' AND TIMESTAMPDIFF(MINUTE,'$dateNow',`departure`)>30 ORDER BY `datemodified` ASC;");
  }elseif(!empty($destination)){
    $theDDates->returns= $ezDb->get_col("SELECT DISTINCT DATE_FORMAT(`return`, '%Y-%m-%d') AS `return` FROM `tripschedules` WHERE `source`='$sources' AND `destination`='$destination' AND `type`='1'  AND TIMESTAMPDIFF(MINUTE,'$dateNow',`return`)>60 ORDER BY `datemodified` ASC;");
  }else{
    $theDDates=null;
  }
  $return=$theDDates;
  return $return;
}

function getTiming1($type='0', $sources=null, $destination=null){
  global $ezDb, $Site, $smarty, $dateNow;
  // Use the type technology
  $theDDates=new StdClass();
  if(!empty($sources) and !empty($destination)){//%Y-%m-%dT%H:%i:%s
    $theDDates->departures= $ezDb->get_col("SELECT DISTINCT DATE_FORMAT(`departure`, '%Y-%m-%d') AS `departure`  FROM `tripschedules1` WHERE `source`='$sources' AND `destination`='$destination' AND TIMESTAMPDIFF(MINUTE,'$dateNow',`departure`)>30 ORDER BY `departure` ASC;");
    if($type=='1' or $type==1){
      $theDDates->returns= $ezDb->get_col("SELECT DISTINCT DATE_FORMAT(`departure`, '%Y-%m-%d') AS `return` FROM `tripschedules1` WHERE `source`='$destination' AND `destination`='$sources' AND DATEDIFF(`departure`,'$dateNow')>1  ORDER BY `departure` ASC;");
    }
  }elseif(!empty($sources)){
    $theDDates->departures= $ezDb->get_col("SELECT DISTINCT DATE_FORMAT(`departure`, '%Y-%m-%d') AS `departure` FROM `tripschedules1` WHERE `source`='$sources' AND TIMESTAMPDIFF(MINUTE,'$dateNow',`departure`)>30 ORDER BY `departure` ASC;");
  }elseif(!empty($destination)){
    $theDDates->returns= $ezDb->get_col("SELECT DISTINCT DATE_FORMAT(`departure`, '%Y-%m-%d') AS `return` FROM `tripschedules1` WHERE `destination`='$destination' AND `type`='1'  AND DATEDIFF(`departure`,'$dateNow')>60 ORDER BY `departure` ASC;");
  }else{
    $theDDates=null;
  }
  $return=$theDDates;
  return $return;
}

function foundSeat($seats, $passengers=null){//remember to cross check no of passengers to no of selected seat
  $newSeat=array();
  $idx=0;
  foreach ($seats as $value) {
    if(empty($value) or $value<1 or $value > 55){//can be changed later on
      continue;
    }
    $newSeat[$idx]=$value;
    $idx++;
  }
  // error_log('4');
  return $newSeat;
}

function optimizeJSON($variable){
  $variable=json_encode($variable);
  $variable=str_replace('""', '', $variable);
  $variable=rtrim($variable,'"');
  $variable=ltrim($variable,'"');
  return $variable;
}

function bookinTokenExists($token=null){
  global $ezDb, $Site, $smarty;
  return $ezDb->get_var("SELECT `token` FROM `temp_booking` WHERE `token`='$token' AND `status`='0'");
}
// new
function bookinTokenExists1($token=null){
  global $ezDb, $Site, $smarty;
  return $ezDb->get_var("SELECT `token` FROM `temp_booking1` WHERE `token`='$token' AND `status`='0'");
}

function ticketExists($value=null){
  global $ezDb, $Site, $smarty;
  return $ezDb->get_var("SELECT `ticketNo` FROM `booking` WHERE `ticketNo`='$value'");
}
//new
function ticketExists1($value=null){
  global $ezDb, $Site, $smarty;
  return $ezDb->get_var("SELECT `ticketNo` FROM `booking1` WHERE `ticketNo`='$value'");
}

/*Root Admin Connect*/
function getManifest($manifestId=null){
  global $ezDb, $Site, $smarty, $sessions, $dateNow;
  $return=null;
  if(!empty($manifestId)){
    $return=$ezDb->get_row("SELECT *, IF( TIMESTAMPDIFF(DAY, '$dateNow', `return`)=0, true, false ) AS `returnSt`, IF( TIMESTAMPDIFF(DAY, '$dateNow', `departure`)=0, true, false ) AS `departureSt` FROM `tripschedules` WHERE (TIMESTAMPDIFF(DAY, '$dateNow', `return`)=0 OR TIMESTAMPDIFF(DAY, '$dateNow', `departure`)=0) AND (`chosenSeats` !='' OR `chosenSeats1`!='') AND `token`='$manifestId' ORDER BY `datemodified` DESC;");
    $return=manifestRoutine($return);
  }
  return $return;
}

function manifestRoutine($manifests=null){
  global $ezDb, $Site, $smarty, $sessions, $dateNow;
  if(! empty($manifests)){
      $manifests->bookedLists=$ezDb->get_results("SELECT `bk`.`bookinginfo`, `bk`.`bookingDate`, `bk`.`ticketNo`, `bk`.`client`, `bk`.`bookedBy`, `bk`.`noOfPerson`, `bk`.`totalFee`, `tb`.`search`, `tb`.`vehicle`, `tb`.`userdata`, `tb`.`ipaddress`, `tb`.`dateadded`, `tb`.`status`  FROM `booking` AS `bk`, `temp_booking` AS `tb` WHERE `bk`.`bookingtoken`=`tb`.`token` AND `tb`.`status`='1' AND `tb`.`vehicle` LIKE '%\"$manifests->token\"%'");
      $manifests->totalTickets=0;
      $manifests->sumTotal=0.00;
      if(!empty($manifests->bookedLists )){
        foreach ($manifests->bookedLists as  $mbl) {
          $ttT=json_decode($mbl->vehicle);
          $ttS=json_decode($mbl->search);
          // Fix Calc

          // $manifests->totalTickets+=count($ttT->seats);
          //   $manifests->sumTotal+=($mbl->totalFee);
          if($ttT->returnDate==$manifests->return and $manifests->returnSt=='1'){
           $manifests->totalTickets+=count($ttT->seats);
           $manifests->sumTotal+=($mbl->totalFee/2);
           // error_log('message');
          }elseif($ttT->departureDate==$manifests->departure and $manifests->departureSt=='1'){
           $manifests->totalTickets+=count($ttT->seats);
           if($ttS->tripType=='Round Trip'){
             $manifests->sumTotal+=($mbl->totalFee/2);
           }else{
             $manifests->sumTotal+=$mbl->totalFee;
           }
           // error_log('message1');
          }else{
           // error_log('message2');
          }
        }
      }
      $manifests->drivernVehicleDetails=$ezDb->get_row("SELECT DISTINCT `title`, `firstname`, `middlename`, `lastname`, `phone`, `email`, `username`, `model`, `plateno`, `capacity`, `type` FROM `userprofile`, `vehicles` WHERE `userprofile`.`username`=`vehicles`.`driversid` AND `vehicleid`='$manifests->vehicleid'");
      $manifests->bookedSeat=count(json_decode(($manifests->returnSt=='1'? $manifests->chosenSeats1: $manifests->chosenSeats)));
      $manifests->vacantSeat= $manifests->capacity - $manifests->totalTickets;
  }
  return $manifests;
}

// new
function getManifest1($manifestId=null){
  global $ezDb, $Site, $smarty, $sessions, $dateNow;
  $return=null;
  if(!empty($manifestId)){
    $return=$ezDb->get_row("SELECT * FROM `tripschedules1` WHERE TIMESTAMPDIFF(DAY, '$dateNow', `departure`)=0 AND (`chosenseats` !='') AND `token`='$manifestId' ORDER BY `datemodified` DESC;");
    $return=manifestRoutine1($return);
  }
  return $return;
}

function manifestRoutine1($manifests=null){
  global $ezDb, $Site, $smarty, $sessions, $dateNow;
  if(! empty($manifests)){
      $manifests->bookedLists=$ezDb->get_results("SELECT `bk`.`bookinginfo`, `bk`.`bookingDate`, `bk`.`ticketNo`, `bk`.`client`, `bk`.`bookedBy`, `bk`.`noOfPerson`, `bk`.`totalFee`, `tb`.`search`, `tb`.`vehicle`, `tb`.`userdata`, `tb`.`ipaddress`, `tb`.`dateadded`, `tb`.`status`  FROM `booking1` AS `bk`, `temp_booking1` AS `tb` WHERE `bk`.`bookingtoken`=`tb`.`token` AND `tb`.`status`='1' AND `tb`.`vehicle` LIKE '%\"$manifests->token\"%'");
      $manifests->totalTickets=0;
      $manifests->sumTotal=0.00;
      if(!empty($manifests->bookedLists )){
        foreach ($manifests->bookedLists as  $mbl) {
          $ttT=json_decode($mbl->vehicle);
          $ttS=json_decode($mbl->search);
          // Fix Calc

          // $manifests->totalTickets+=count($ttT->seats);
          //   $manifests->sumTotal+=($mbl->totalFee);
          if($ttT->departureDate==$manifests->departure){
           $manifests->totalTickets+=count($ttT->seats);
           if($ttS->tripType=='Round Trip'){
             $manifests->sumTotal+=($mbl->totalFee/2);
           }else{
             $manifests->sumTotal+=$mbl->totalFee;
           }
           // error_log('message1');
          }else{
           // error_log('message2');
          }
        }
      }
      $manifests->drivernVehicleDetails=$ezDb->get_row("SELECT DISTINCT `title`, `firstname`, `middlename`, `lastname`, `phone`, `email`, `username`, `model`, `plateno`, `capacity`, `type` FROM `userprofile`, `vehicles` WHERE `userprofile`.`username`=`vehicles`.`driversid` AND `vehicleid`='$manifests->vehicleid'");
      $manifests->bookedSeat=count(json_decode(($manifests->returnSt=='1'? $manifests->chosenSeats1: $manifests->chosenSeats)));
      $manifests->vacantSeat= $manifests->capacity - $manifests->totalTickets;
  }
  return $manifests;
}
/*End Latest Real Function*/

//Wallet and Transaction logics
function setupWallet($username=null){
  global $ezDb, $Site, $siteName;
  $username=base64_encode(( empty($username) ? $Site["session"]["User"]["Username"] : $username ));
  if( !empty($username) and  $ezDb->get_var("SELECT `username` FROM `userprofile` WHERE `username`='$username';") and $ezDb->get_var("SELECT COUNT(`id`) FROM `".$siteName."_accounts` WHERE `user`='$username'") == 0 ){
    $ezDb->query("INSERT INTO `".$siteName."_accounts` (`user`) VALUES('$username');");
  }
}
//get bank detail
function getBankDetail($username=null){
  global $ezDb, $siteName, $Site;
  if(!empty($username)){
    $username=base64_encode($username);
  }else{
    $username=base64_encode($Site["session"]["User"]["Username"]);
  }
  return $ezDb->get_row("SELECT `bank`, `accountName`, `accountNumber`, `bvn`, `dateUpdated`, `status` FROM `".$siteName."_bankdetails` WHERE `users`='$username';");
}


// return system settings
function getSettings($field=null){
  global $ezDb, $siteName, $Site;
  $return=false;
  if(empty($field)){
    $return=$ezDb->get_row("SELECT * FROM `settings`;");
    if (!empty($return)) {
      foreach ($return as $key=>$value) {
        $return->$key=json_decode($value);
      }
    }
  }else{
    $return=$ezDb->get_var("SELECT `$field` FROM `settings`;");
  }
  return $return;
}

//return all stored countries in database
function getCountries($id=null){
  global $ezDb, $siteName, $Site;
  $filter=( !empty($id)? "WHERE (`id`='$id' OR `name`='$id')" : "");
  return $ezDb->get_results("SELECT * FROM `countries` $filter ORDER BY `name` ASC;");
}

function getStates($cid=null,$id=null){
  global $ezDb, $siteName, $Site;
  if (empty(trim($cid))) {
    $cid=1;
  }
  $filter=( !empty($cid)? "AND (`cn`.`id`='$cid' OR `cn`.`name`='$cid')": ""). (!empty($id)? " AND (`st`.`id`='$id' OR `st`.`name`='$id')": "");
  return $ezDb->get_results("SELECT `st`.`id`, `st`.`name`, `st`.`country_id` FROM `states` AS `st`, `countries` AS `cn` WHERE `st`.`country_id`=`cn`.`id` $filter ORDER BY `st`.`name` ASC;");
}

function getCities($sid=null,$id=null){
  global $ezDb, $siteName, $Site;
  if (empty(trim($sid))) {
    $sid=1;
  }
  $filter=( !empty($sid)? "AND (`st`.`id`='$sid' OR `st`.`name`='$sid')": ""). (!empty($id)? " AND (`ct`.`id`='$id' OR `ct`.`name`='$id')": "");
  return $ezDb->get_results("SELECT `ct`.`id`, `ct`.`name`, `ct`.`state_id` FROM `cities` AS `ct`, `states` AS `st` WHERE `ct`.`state_id`=`st`.`id` $filter ORDER BY `ct`.`name` ASC;");
}

//Function for Security Token Generation
function generateSecurityToken(){
  global $ezDb, $siteName, $companyName, $sitePage, $Site;
  $dateNow=date("Y-m-d H:i:s");
  $eol = "\r\n";
  $headers = "From: Lawcon <admin@cityhoppers.com.ng>" . $eol;
  $headers .= "Organisation: $companyName" . $eol;
  $headers .= "MIME-Version: 1.0" . $eol;
  $headers .= "Content-Transfer-Encoding: 7bit" . $eol;
  $prefix="";
  $user = base64_encode($Site["session"]["User"]["Username"]);
  $user_email = base64_decode($ezDb->get_var("SELECT `email` FROM `userprofile` WHERE `username`='$user'"));
  $sec_token = $prefix.getToken(20);
  $the_subject = "Security Token Request";
  $the_message = "Token: $eol $eol $sec_token";
  if ($ezDb->query("UPDATE `userprofile` SET `recKey`='$sec_token', `recDate`='$dateNow' WHERE `username`='$user' AND `active`='1' AND `verified`='1'")):
    if (mail($user_email, $the_subject, $the_message, $headers)):
      return 'Security token has been successfully sent to your email';
    else:
      return 'There is a problem sending a security token to your email';
    endif;
  endif;
}
function nullifySecurityToken(){
  global $ezDb, $siteName, $companyName, $sitePage, $Site;
  $user = base64_encode($Site["session"]["User"]["Username"]);
  $ezDb->query("UPDATE `userprofile` SET `recKey`=NULL WHERE `username`='$user' AND `active`='1' AND `verified`='1'");
}
//log visit
function logVisit($username){
  global $ezDb, $siteName, $Site;
  /*$servers=(object) $Site['server'];*/
  /*$dateNow=date("Y-m-d");
  $ezDb->query("INSERT INTO `user_visits` (`user`, `datevisited`, `location`) VALUES ('$username', '$dateNow', '$servers->REMOTE_ADDR');");*/
}

//Log admin Events
function logEvent($username, $tablename, $type, $content=''){
  global $ezDb, $siteName, $remoteIP, $Site;
  // return $ezDb->query("INSERT INTO `users_logs` (`user`, `token`, `tablename`, `data`, `ipaddress`, `device`, `event`, `datelogged`) VALUES ('$username', ".(empty($tablename)?"NULL" :"'$tablename'").", '$type', '$content', '$remoteIP', '$dateNow')");
  // To be Optimized
}

// Get the real extension of a file.
function getMime($file) {
  if (function_exists("finfo_file")) {
    $finfo = finfo_open(FILEINFO_MIME_TYPE); // return mime type ala mimetype extension
    $mime = finfo_file($finfo, $file);
    finfo_close($finfo);
    return $mime;
  } else if (function_exists("mime_content_type")) {
    return mime_content_type($file);
  } else if (!stristr(ini_get("disable_functions"), "shell_exec")) {
    // http://stackoverflow.com/a/134930/1593459
    $file = escapeshellarg($file);
    $mime = shell_exec("file -bi " . $file);
    return $mime;
  } else {
    return false;
  }
}

function tableRoutine($tablename, $fields, $where, $order, $orderBy="DESC", $entryDefault="5"){
  global $dateNow, $gets, $smarty, $ezDb;

  $gets->search=(empty($gets->search)? "": $gets->search);
  $filter=" ";
  if(!empty($gets->search) and !empty($columns=$ezDb->get_row("SELECT * FROM `$tablename` LIMIT 1")) ){
    $cnter=0;
    foreach ($columns as $key => $value) {
      if (strtolower($key)=='id') {
        continue;
      }
      $filter.=($cnter==0? "`$key` LIKE '%$gets->search%' ": "OR `$key` LIKE '%$gets->search%' ");
      $cnter++;
    }
    $where=(empty($where)? "WHERE ($filter)": "WHERE $where AND ($filter)");
  }else{
    $where=(empty($where)? "": "WHERE $where");
  }
  // $where=(empty($where)? "": "WHERE $where");
  $order=(empty($order)? "": "ORDER BY $order $orderBy");

  $gets->totalRecs=$ezDb->get_var("SELECT COUNT(`id`) FROM `$tablename` $where;");
  $gets->entry=((empty($gets->entry) or !is_numeric($gets->entry) or $gets->entry<5)? $entryDefault : $gets->entry);
  $totalPages=($gets->entry>=$gets->totalRecs? 1: ($gets->totalRecs/$gets->entry) );
  $totalPagesArray=explode(".", "$totalPages");
  $gets->totalPages=(count($totalPagesArray)>1? $totalPagesArray[0]+1: $totalPages);

  $gets->page=((empty($gets->page) or $gets->page<0 or $gets->page > $gets->totalPages)? "1": $gets->page);
  if ( ( $gets->page * $gets->entry ) > $gets->totalRecs ) {
    // $gets->from= (( $gets->page * $gets->entry ) % $gets->totalRecs);
    $gets->from=  ($gets->page-1) * $gets->entry ;
    $gets->to= $gets->totalRecs;
  }elseif( ( $gets->page * $gets->entry ) <= ($gets->totalRecs) ){
    $gets->from=($gets->page-1) * $gets->entry;
    $gets->to= ($gets->page * $gets->entry );
  }
  // error_log(json_encode($gets));
  // error_log("SELECT $fields FROM `$tablename` $where $order LIMIT $gets->from, $gets->entry;");

  $ret=$ezDb->get_results("SELECT $fields FROM `$tablename` $where $order LIMIT $gets->from, $gets->entry;");
  $smarty->assign("Pager", $gets)->assign("countStarted", $gets->form+1);
  return $ret;
}

/*Mailing Templater*/
function setDivElement($bookings, $tempBookings, $i){
  global $Site;
  return '<div class="col-md-6 border-dark card text-center" id="printMe" style="max-width: 400px;">
            <div class="card-header" style="min-height: 40px;">
              <img src="'.$Site['siteProtocol'].$Site['domainName'].'/site/media/i/logo.png" style="max-width: 90px; float: left;" alt="City Hoppers">
              <h6 style="text-align: center; padding-top: 10px;">TICKET ITINERARY</h6>
            </div>
            <div class="card-text text-justify">
              <small style=" font-size: 70%;">
                <strong>Booking ID:</strong> '.(count($tempBookings->userdata->email)==1? $bookings->ticketNo: $bookings->ticketNo.'_'.$i).'<br/>
                <strong>Direction: </strong>'.$tempBookings->search->travelFrom.' to '.$tempBookings->search->travelTo.'<br/>
                <strong>Booking Type: </strong>'.$tempBookings->search->tripType.'<br/>
                <strong>Departure Date:</strong> '.date("h:i a l, d m Y", strtotime($tempBookings->vehicle->departureDate)).'<br/>'.
                ($tempBookings->search->tripType=='Round Trip'?'<strong>Return Date:</strong> '.date("h:i a l, d m Y", strtotime($tempBookings->vehicle->returnDate)).'<br/>':'')
                .'<strong>Number of Passengers:</strong> '.$tempBookings->search->passenger.'<br/>
                <strong>Passenger Name:</strong> '.$tempBookings->userdata->firstName[$i].' '.$tempBookings->userdata->lastName[$i].'
              </small>
            </div>
            <div class="card-body" style=" padding-top: 0.5rem; padding-bottom: 0.5rem;">
              <hr style=" margin-top: 0.5rem; margin-bottom: 0.5rem;" />
              <div class="table-responsive">
                <table class="table table-striped table-bordered table-sm">
                  <tr>
                    <th>Departure Vehicle No:</th><td>'.$tempBookings->vehicle->vehicleid.'</td>
                  </tr>
                  '. ($tempBookings->search->tripType=='Round Trip'?'
                  <tr><th>Return Trip Vehicle No:</th><td>'.$tempBookings->vehicle->vehicleid1.'</td></tr>':'').'
                  <tr>
                    <th>Passenger:</th><td>'.$tempBookings->userdata->email[$i].'</td>
                  </tr>
                  <tr>
                    <th>Total Passenger:</th><td>'.$tempBookings->search->passenger.'</td>
                  </tr>
                  <tr>
                    <th>Booked Seats on Departure:</th><td>'.$tempBookings->vehicle->seats[$i].'</td>
                  </tr>
                  '. ($tempBookings->search->tripType=='Round Trip'?'
                    <tr><th>Booked Seats on Return Trip:</th><td>'.$tempBookings->vehicle->seats1[$i].'</td></tr>':'').'
                  <tr>
                    <th><h5>Ticket Fee</h5></th><td><h5>₦ '.($tempBookings->userdata->total/count($tempBookings->userdata->email)).'</h5></td>
                  </tr>
                </table>
              </div>
            </div>
            <div class="card-footer text-muted">
              <p class="note"><strong><h5>No Refund After Payment</h5></strong></p>
              <p class="note"><h5><small style=" font-size: 70%;">For More Inquiry, Contact Customer Care Line: <strong><a href="tel:+234-906-993-8649"> +234-906-993-8649</a></strong></small></h5></p>
              <p class="note"><h5><small style=" font-size: 70%;">Ensure that you are on board by 30 minutes before the take off (Departure or Return) time</h5></p>
            </div>
          </div>';
}

/*Run Two Weeks Up Front Schedule*/
function runTwoWeeksUpfront($posts, $user){
  global $ezDb, $dateNow;
  $lastschedule=$posts;
  for ($h=0; $h < 13; $h++) : 
    error_log(json_encode($lastschedule));
    $schedID="schid".date("Ymdhis").round(microtime(true)).getToken(2);
    if( $lastschedule->type=='1'){
        //round trip
      $ezDb->query("INSERT INTO `tripschedules` (`vehicleid`, `token`, `source`, `destination`, `departure`, `return`, `type`, `discount`, `unitfee`, `capacity`, `addedby`, `dateadded`, `datemodified`) VALUES ('$lastschedule->vehicleid', '$schedID', '$lastschedule->source', '$lastschedule->destination', DATE_ADD('$lastschedule->departure', INTERVAL 2 DAY), DATE_ADD('$lastschedule->return', INTERVAL 2 DAY), '$lastschedule->type', '$lastschedule->discount', '$lastschedule->unitfee', '$lastschedule->capacity', '$user', '$dateNow', '$dateNow');");
    }elseif( $lastschedule->type=='0'){
      //one way
      $ezDb->query("INSERT INTO `tripschedules` (`vehicleid`, `token`, `source`, `destination`, `departure`, `return`, `type`, `discount`, `unitfee`, `capacity`, `addedby`, `dateadded`, `datemodified`) VALUES ('$lastschedule->vehicleid', '$schedID', '$lastschedule->destination', '$lastschedule->source', DATE_ADD('$lastschedule->departure', INTERVAL 1 DAY), '$lastschedule->return', '$lastschedule->type', '$lastschedule->discount', '$lastschedule->unitfee', '$lastschedule->capacity', '$user', '$dateNow', '$dateNow');");
    }
    $lastschedule=$ezDb->get_row("SELECT * FROM `tripschedules` WHERE `token`='$schedID' ORDER BY `datemodified` DESC LIMIT 1;");
    error_log(json_encode($lastschedule));
  endfor;
}

function runTwoWeeksUpfront1($posts, $user){
  global $ezDb, $dateNow;
  $lastschedule=$posts;
  $type=$lastschedule->type;
  for ($h=0; $h < 13; $h++) { 
    // error_log(json_encode($lastschedule));
    $schedID="schid".date("Ymdhis").round(microtime(true)).getToken(2);
    if( $type=='1'){
        //round trip departure
      if( empty( $ezDb->get_var("SELECT `token` FROM `tripschedules1` WHERE `vehicleid`='$lastschedule->vehicleid' AND `departure`=DATE_ADD('$lastschedule->return', INTERVAL 1 DAY)"))){
        $ezDb->query("INSERT INTO `tripschedules1` (`vehicleid`, `token`, `source`, `destination`, `departure`, `discount`, `unitfee`, `capacity`, `addedby`, `dateadded`, `datemodified`) VALUES ('$lastschedule->vehicleid', '$schedID', '$lastschedule->source', '$lastschedule->destination', DATE_ADD('$lastschedule->return', INTERVAL 1 DAY), '$lastschedule->discount', '$lastschedule->unitfee', '$lastschedule->capacity', '$user', '$dateNow', '$dateNow');");
        $lastschedule->departure= $ezDb->get_var("SELECT `departure` FROM `tripschedules1` WHERE `token`='$schedID';");
        // $tempDirection=$lastschedule->destination;
        // $lastschedule->destination=$lastschedule->source;
        // $lastschedule->source=$tempDirection;
      }else{
        $lastschedule->departure= $ezDb->get_var("SELECT DATE_ADD('$lastschedule->return', INTERVAL 1 DAY) FROM `tripschedules1` WHERE `vehicleid`='$lastschedule->vehicleid' AND `departure`=DATE_ADD('$lastschedule->return', INTERVAL 1 DAY)");
      }
      // round trip return
      if(empty( $ezDb->get_var("SELECT `token` FROM `tripschedules1` WHERE `vehicleid`='$lastschedule->vehicleid' AND `departure`=DATE_ADD('$lastschedule->departure', INTERVAL 1 DAY)"))){
        $ezDb->query("INSERT INTO `tripschedules1` (`vehicleid`, `token`, `source`, `destination`, `departure`, `discount`, `unitfee`, `capacity`, `addedby`, `dateadded`, `datemodified`) VALUES ('$lastschedule->vehicleid', 'ret-$schedID', '$lastschedule->destination', '$lastschedule->source', DATE_ADD('$lastschedule->departure', INTERVAL 1 DAY), '$lastschedule->discount', '$lastschedule->unitfee', '$lastschedule->capacity', '$user', '$dateNow', '$dateNow');");
        $lastschedule->return= $ezDb->get_var("SELECT `departure` FROM `tripschedules1` WHERE `token`='ret-$schedID';");
      }else{
        $lastschedule->return= $ezDb->get_var("SELECT DATE_ADD('$lastschedule->departure', INTERVAL 1 DAY) FROM `tripschedules1` WHERE `vehicleid`='$lastschedule->vehicleid' AND `departure`=DATE_ADD('$lastschedule->departure', INTERVAL 1 DAY)");
      }

    }elseif( $lastschedule->type=='0'){
      //one way
      if(empty( $ezDb->get_var("SELECT `token` FROM `tripschedules1` WHERE `vehicleid`='$lastschedule->vehicleid' AND `departure`=DATE_ADD('$lastschedule->departure', INTERVAL 1 DAY)"))){
        $ezDb->query("INSERT INTO `tripschedules1` (`vehicleid`, `token`, `source`, `destination`, `departure`, `discount`, `unitfee`, `capacity`, `addedby`, `dateadded`, `datemodified`) VALUES ('$lastschedule->vehicleid', '$schedID', '$lastschedule->destination', '$lastschedule->source', DATE_ADD('$lastschedule->departure', INTERVAL 1 DAY), '$lastschedule->discount', '$lastschedule->unitfee', '$lastschedule->capacity', '$user', '$dateNow', '$dateNow');");
        $lastschedule->departure= $ezDb->get_var("SELECT `departure` FROM `tripschedules1` WHERE `token`='$schedID';");
        $tempDirection=$lastschedule->destination;
        $lastschedule->destination=$lastschedule->source;
        $lastschedule->source=$tempDirection;
      }else{
        $lastschedule=$ezDb->get_row("SELECT * FROM `tripschedules1` WHERE `vehicleid`='$lastschedule->vehicleid' AND `departure`=DATE_ADD('$lastschedule->departure', INTERVAL 1 DAY);");
      }
    }
  }
}

/*Generating Schedule Routine*/
function scheduleRoutineGenerator(){
  global $ezDb, $dateNow;
  // error_log("schedule routine engine");
  if($ezDb->query("SELECT `datefired` FROM `cronjobrequests` WHERE DATEDIFF(`datefired`,'$dateNow')>-1 AND `status`='1'")){
    return;
  }
  // error_log("schedule routine started");
  $vehicles=$ezDb->get_results("SELECT DISTINCT `id`,`vehicleid`,`model`,`plateno`,`capacity`,`driversid`,`addedby`,`dateadded`,`type`,`description` FROM `vehicles`");
  if(!empty($vehicles)){
    foreach ($vehicles as $vehicle) {
      $lastschedule=$ezDb->get_row("SELECT * FROM `tripschedules` WHERE `vehicleid`='$vehicle->vehicleid' ORDER BY `datemodified` DESC LIMIT 1;");
      // Not Sure There could be pre checkings
      $schedID="schid".date("Ymdhis").round(microtime(true)).getToken(2);
      // $schedID=$lastschedule->token.getToken(2);
      if( $lastschedule->type=='1'){
        //round trip
        $ezDb->query("INSERT INTO `tripschedules` (`vehicleid`, `token`, `source`, `destination`, `departure`, `return`, `type`, `discount`, `unitfee`, `capacity`, `addedby`, `dateadded`, `datemodified`) VALUES ('$lastschedule->vehicleid', '$schedID', '$lastschedule->source', '$lastschedule->destination', DATE_ADD('$lastschedule->departure', INTERVAL 2 DAY), DATE_ADD('$lastschedule->return', INTERVAL 2 DAY), '$lastschedule->type', '$lastschedule->discount', '$lastschedule->unitfee', '$lastschedule->capacity', 'auto', '$dateNow', '$dateNow');");
      }elseif( $lastschedule->type=='0'){
        //one way
        $ezDb->query("INSERT INTO `tripschedules` (`vehicleid`, `token`, `source`, `destination`, `departure`, `return`, `type`, `discount`, `unitfee`, `capacity`, `addedby`, `dateadded`, `datemodified`) VALUES ('$lastschedule->vehicleid', '$schedID', '$lastschedule->destination', '$lastschedule->source', DATE_ADD('$lastschedule->departure', INTERVAL 1 DAY), '$lastschedule->return', '$lastschedule->type', '$lastschedule->discount', '$lastschedule->unitfee', '$lastschedule->capacity', 'auto', '$dateNow', '$dateNow');");
      }
      // Not sure there could be post checkings
    }
    $ezDb->query("UPDATE `cronjobrequests` SET `datefired`='$dateNow', `status`='1'");
  }
  $ezDb->query("UPDATE `tripschedules1` SET `chosenseats`='' WHERE `chosenseats`='null'");
}

function scheduleRoutineGenerator1(){
  global $ezDb, $dateNow;
  // error_log("schedule routine engine");
  $countLmt=1;
  if(!empty($ezDb->query("SELECT `datefired` FROM `cronjobrequests1` WHERE DATEDIFF(`datefired`,'$dateNow')>-1 AND `status`='1'"))){
    return;
  }
  $countLmt=$ezDb->query("SELECT ABS(DATEDIFF(`datefired`,'$dateNow')) FROM `cronjobrequests1` WHERE `status`='1'");
  // error_log("schedule routine started");
  $vehicles=$ezDb->get_results("SELECT DISTINCT `id`,`vehicleid`,`model`,`plateno`,`capacity`,`driversid`,`addedby`,`dateadded`,`type`,`description` FROM `vehicles`");
  if(!empty($vehicles)){
    foreach ($vehicles as $vehicle) {
      $lastschedule=$ezDb->get_row("SELECT * FROM `tripschedules1` WHERE `vehicleid`='$vehicle->vehicleid' ORDER BY `departure` DESC LIMIT 1;");
      for($y=0; $y<$countLmt; $y++){
        // Not Sure There could be pre checkings
        $schedID="autoschid".date("Ymdhis").round(microtime(true)).getToken(2);
        //all sched
        if(empty( $ezDb->get_var("SELECT `token` FROM `tripschedules1` WHERE `vehicleid`='$lastschedule->vehicleid' AND `departure`=DATE_ADD('$lastschedule->departure', INTERVAL 1 DAY)"))){
          $ezDb->query("INSERT INTO `tripschedules1` (`vehicleid`, `token`, `source`, `destination`, `departure`, `discount`, `unitfee`, `capacity`, `addedby`, `dateadded`, `datemodified`) VALUES ('$lastschedule->vehicleid', '$schedID', '$lastschedule->destination', '$lastschedule->source', DATE_ADD('$lastschedule->departure', INTERVAL 1 DAY), '$lastschedule->discount', '$lastschedule->unitfee', '$lastschedule->capacity', 'auto', '$dateNow', '$dateNow');");
          $lastschedule->departure= $ezDb->get_var("SELECT `departure` FROM `tripschedules1` WHERE `token`='$schedID';");
          $tempDirection=$lastschedule->destination;
          $lastschedule->destination=$lastschedule->source;
          $lastschedule->source=$tempDirection;
          // error_log(json_encode($lastschedule));
        }else{
          $lastschedule=$ezDb->get_row("SELECT * FROM `tripschedules1` WHERE `vehicleid`='$lastschedule->vehicleid' AND `departure`=DATE_ADD('$lastschedule->departure', INTERVAL 1 DAY);");
        }
      }
      //  sure there wont be post checkings
    }
    $ezDb->query("UPDATE `cronjobrequests1` SET `datefired`='$dateNow', `status`='1'");
  }
}

/*Optimize Temp Booking & Schedules*/
function optimizeTempBookings(){
  global $ezDb, $dateNow;
  // $redundants=$ezDb->get_results("SELECT `token`, `search`, `vehicle` FROM `temp_booking` WHERE `status`='0' AND DATEDIFF('$dateNow',`dateadded`)>=1");
  $redundants=$ezDb->get_results("SELECT `token`, `search`, `vehicle` FROM `temp_booking1` WHERE `status`='0' AND  TIMESTAMPDIFF(MINUTE,`dateadded`,'$dateNow')>=60");
  if(!empty($redundants)){
    // error_log(json_encode($redundants)."\n\n");
    foreach ($redundants as $redundant) {
      // error_log(json_encode($redundant)."\n\n");
      $checkerR=0;
      $redundant->search=json_decode($redundant->search);
      $redundant->vehicle=json_decode($redundant->vehicle);
      if( !empty($redundant->vehicle->departureID)){
        // $redundant->vehicle->seats=json_decode($redundant->vehicle->seats);
        $affectedschedule=$ezDb->get_row("SELECT `token`, `chosenseats` FROM `tripschedules1` WHERE `token`='".$redundant->vehicle->departureID."'");
        //error_log(json_encode($affectedschedule)."\n-\n")
        $affectedschedule->chosenseats=json_decode($affectedschedule->chosenseats);
        if(!empty($redundant->vehicle->seats) and is_array($redundant->vehicle->seats)){
          $newchosenseats=array_diff($affectedschedule->chosenseats, $redundant->vehicle->seats);
        }else{
          $newchosenseats=$affectedschedule->chosenseats;
        }
        $newchosenseats=(empty($newchosenseats)?"":json_encode($newchosenseats));
        if($ezDb->query("UPDATE `tripschedules1` SET `chosenseats`='".$newchosenseats."' WHERE `token`='".$redundant->vehicle->departureID."'")){
          $checkerR++;
        }
      }
      if( !empty($redundant->vehicle->returnID)){
        // $redundant->vehicle->seats1=json_decode($redundant->vehicle->seats1);
        $affectedschedule=$ezDb->get_row("SELECT `token`, `chosenseats` FROM `tripschedules1` WHERE `token`='".$redundant->vehicle->returnID."'");
        //error_log(json_encode($affectedschedule)."\n--\n");
        $affectedschedule->chosenseats=json_decode($affectedschedule->chosenseats);
        if(!empty($redundant->vehicle->seats1) and is_array($redundant->vehicle->seats1)){
          $newchosenseats1=array_diff($affectedschedule->chosenseats, $redundant->vehicle->seats1);
        }else{
          $newchosenseats1=$affectedschedule->chosenseats;
        }
        $newchosenseats1=(empty($newchosenseats1)?"":json_encode($newchosenseats1));
        if($ezDb->query("UPDATE `tripschedules1` SET `chosenseats`='".$newchosenseats1."' WHERE `token`='".$redundant->vehicle->returnID."'")){
          $checkerR++;
        }
      }
      if($checkerR>0 or empty($redundant->vehicle->seats)){
        $ezDb->query("DELETE FROM `temp_booking1` WHERE `token`='$redundant->token' AND `status`='0'");
      }
    }
  }
}