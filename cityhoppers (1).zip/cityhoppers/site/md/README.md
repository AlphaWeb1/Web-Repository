--------------------- GUIDE TO LAWCON DEVELOPMENT----------------------
# 1. Home Page Content
	* [Cachy Words/ Sentences]...

	* (What We Do {About Us})...

	* Contents (Featured lawyers, Client's Submissions[testimonials])

	* Links (FAQ, Contact/About, Login, Signup, Terms and Policy, Search or Meet [lawyers])

# 2. Dashboard Content

	* Client Area (Highlights, Profile, Search & Consult [+ rating], My Cases [+ files and docs] @client, History [Payment & Transations, Consultations] Notification & Reminder, Helpline)

	* Lawyers Account (Highlights, Profile [+ rating, boost search access], My Cases [+ files and docs] @lawyer, Clients, Notification & Reminder, History [Transactions], Helpline);

# 3. Admin Content

	* Not Yet Defined


# Notices
	a. place your db_config.php in your www Dir NOT in the project.