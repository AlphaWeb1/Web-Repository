<?php

require_once "Mail.php"; // PEAR Mail package
require_once ('Mail/mime.php'); // PEAR Mail_Mime packge
// $Site['siteProtocol'].$Site['domainName']."/resend?e=$posts->email"

$catsTempl='';

/*"

About us:
CityHoppers strives to be the best in the industry - a well organized, comfortable and reliable road travel option. We also offer efficient booking platform for the convenience of our clients. Our corporate goal is to make your travel experience as comfortable and enjoyable as possible. Thank you again for your patronage."*/
$divElements='<div class="row">
	<div class="container">
		<div class="panel panel-success col-md-6 col-md-offset-3">
			<div class="panel-heading text-center"><h2 class="prodTitle"><img src="'.$Site['siteProtocol'].$Site['domainName'].'/site/media/i/logo.png" style="height: 70px;"></h2></div>
			<div class="panel-body">
				<h5>Dear '.$post->firstname.'</h5>
				<p>
					Thank you for registering with (cityhoppers.com.ng) We are delighted to have you as our esteemed customer!
				</p>
				<p> We shall continue to strive and work tirelessly to provide you seamless service. We hope to become the ultimate service provider of choice for all your personal, group, corporate and business needs.
				</p>
				<p style="display:none;">
					<ul>
						<li>Ensuring you with optimum travle comfort</li>
						<li>Providing you with a reliable service assurance</li>
						<li>Experiencing the most affordable travel fee</li>
						<li>Concurrent monitoring of your trip safety and provision of adequate security meansures.</li>
					</ul>
				</p>
				<p>
					To complete the signup process, we do require email authentication. We request that you activate your account by clicking below or copy and paste the link below: <br/>
					<a href="'.$Site['siteProtocol'].$Site['domainName'].'/verify?k='.$confirmkey.'">'.$Site['siteProtocol'].$Site['domainName'].'/verify?k='.$confirmkey.'</a>
				</p>
				<p style="display: none;">
					We welcome you to enjoy a high confort trip anytime! Stay relaxed while we assure your daily trip booking experience to be mind blowing and extraordinary.
				</p>
				<p>About us:<br/>
				CityHoppers strives to be the best in the industry - a well organized, comfortable and reliable road travel option. We also offer efficient booking platform for the convenience of our clients. Our corporate goal is to make your travel experience as comfortable and enjoyable as possible. Thank you again for your patronage.
				</p>
			</div>
		</div>
	</div>
</div>';


$from = "signup@cityhoppers.com.ng"; //enter your email address
// $to = "info@".$domainName; //enter the email address of the contact your sending to
$to = $posts->email; //enter the email address of the contact your sending to
$subject = 'cityhoppers Welcomes You To Her Client Family'; // subject of your email

$headers = array ('From' => $from,'To' => $to, 'Subject' => $subject);

$text = "Sender : Signup@Cityhoppers\n\nMessage: Thank you for registering on cityhoppers.com.ng, The best well organized and comfortable road travel platform you could ever wish for. We are delighted to have you as a customer!".PHP_EOL; // text versions of email.
$html = '<html>
	      <head>
	      	<title>Subscription</title>
	      	<link rel="stylesheet" href="https://cityhoppers.com.ng/lib/common/bootstrap/css/bootstrap.min.css" />
			<link rel="stylesheet" href="https://cityhoppers.com.ng/lib/common/font-awesome/css/font-awesome.min.css">
			<link rel="stylesheet" href="https://cityhoppers.com.ng/lib/common/css/style.css" type="text/css" />
			<style>
			</style>
	      </head>
      	  <body>
      	  	'.$divElements.'
			<script src="https://cityhoppers.com.ng/lib/common/js/jquery-3.3.1.js"></script>
			<script src="https://cityhoppers.com.ng/lib/common/bootstrap/js/bootstrap.min.js"></script>
			<script src="https://cityhoppers.com.ng/lib/common/js/script.js"></script>
      	  </body>
      </html>'; // html versions of email.

$crlf = "\n";

$mime = new Mail_mime($crlf);
$mime->setTXTBody($text);
$mime->setHTMLBody($html);

//do not ever try to call these lines in reverse order
$body = $mime->get();
$headers = $mime->headers($headers);
$host = "localhost"; // all scripts must use localhost
$username = "signup@cityhoppers.com.ng"; //  your email address (same as webmail username)
// $username = "info@".$domainName; //  your email address (same as webmail username)

$password = "Signup@CityHoppers1234$"; // your password (same as webmail password)

$smtp = Mail::factory('smtp', array ('host' => $host, 'auth' => true,
			'username' => $username,'password' => $password,'socket_options' => array('ssl' => array('verify_peer_name' => false, 'allow_self_signed' => true))));

$mail = $smtp->send($to, $headers, $body);
$isErr=PEAR::isError($mail);

if ($isErr) :
	$fail.='<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Error 601:</h3> <p>Unable to connect to send message</p></div>';
else:
// $fail.='<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button> <p>Your message had been successfully sent.<br/>Thanks!</p></div>';
endif;