<?php

require_once "Mail.php"; // PEAR Mail package
require_once ('Mail/mime.php'); // PEAR Mail_Mime packge
// $Site['siteProtocol'].$Site['domainName']."/resend?e=$posts->email"


$userrecord= userInfo($posts->dataRecoverEmail);
	$theSitePath = "$siteProtocol"."$domainName";
	$theLink = "$theSitePath/reset?k=$recKey";
	$theMessage="Dear $userrecord->firstname $userrecord->lastname
	You recently request for password reset on your cityhoppers account!\n\nTo complete your password reset process, we request that you Click or copy the link below open on a browser.\n\n\t$theLink\n\n\tNote that the link is active for just only 24 hours.\n\nThank You,\n\nThe ".ucfirst($domainName)." team.".PHP_EOL;

$divElements='<div class="row">
	<div class="container">
		<div class="panel panel-success col-md-6 col-md-offset-3">
			<div class="panel-heading text-center"><h2 class="prodTitle"><img src="'.$Site['siteProtocol'].$Site['domainName'].'/site/media/i/logo.png" style="height: 70px;"></h2></div>
			<div class="panel-body">
				<h5>Dear '.$userrecord->firstname.'</h5>
				<p>
					You recently request for password reset on your cityhoppers account!
				</p>
				<p>
					To complete your password reset process, we request that you Click or copy the link below open on a browser. <br/>
					<a href="'.$theLink.'">'.$theLink.'</a>
					<br/>
				    Note that the link is active for just only 24 hours.
				</p>
				<p>
					Thank You,<br/>
					The '.ucfirst($domainName).' team.
				</p>
			</div>
		</div>
	</div>
</div>';


$from = "signup@cityhoppers.com.ng"; //enter your email address
// $to = "info@".$domainName; //enter the email address of the contact your sending to
$to = $posts->dataRecoverEmail; //enter the email address of the contact your sending to
$subject =  "Password Recovery request from ".ucfirst($domainName); // subject of your email

$headers = array ('From' => $from,'To' => $to, 'Subject' => $subject);

$text = "Sender : Signup@Cityhoppers\n\nMessage: $theMessage".PHP_EOL; // text versions of email.
$html = '<html>
	      <head>
	      	<title>Subscription</title>
	      	<link rel="stylesheet" href="https://cityhoppers.com.ng/lib/common/bootstrap/css/bootstrap.min.css" />
			<link rel="stylesheet" href="https://cityhoppers.com.ng/lib/common/font-awesome/css/font-awesome.min.css">
			<link rel="stylesheet" href="https://cityhoppers.com.ng/lib/common/css/style.css" type="text/css" />
			<style>
			</style>
	      </head>
      	  <body>
      	  	'.$divElements.'
			<script src="https://cityhoppers.com.ng/lib/common/js/jquery-3.3.1.js"></script>
			<script src="https://cityhoppers.com.ng/lib/common/bootstrap/js/bootstrap.min.js"></script>
			<script src="https://cityhoppers.com.ng/lib/common/js/script.js"></script>
      	  </body>
      </html>'; // html versions of email.

$crlf = "\n";

$mime = new Mail_mime($crlf);
$mime->setTXTBody($text);
$mime->setHTMLBody($html);

//do not ever try to call these lines in reverse order
$body = $mime->get();
$headers = $mime->headers($headers);
$host = "localhost"; // all scripts must use localhost
$username = "signup@cityhoppers.com.ng"; //  your email address (same as webmail username)
// $username = "info@".$domainName; //  your email address (same as webmail username)

$password = "Signup@CityHoppers1234$"; // your password (same as webmail password)

$smtp = Mail::factory('smtp', array ('host' => $host, 'auth' => true,
			'username' => $username,'password' => $password,'socket_options' => array('ssl' => array('verify_peer_name' => false, 'allow_self_signed' => true))));

$mail = $smtp->send($to, $headers, $body);
$isErr=PEAR::isError($mail);

if ($isErr) :
	$fail.='<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Error 601:</h3> <p>Unable to connect to send message</p></div>';
else:
	$fail.='<div class="alert alert-primary alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button> A password reset link had been sent to your email which expires in 24 hours from now.</div>';
endif;



/*
$theSubject = "Password Recovery request from ".ucfirst($domainName);
$headers = "From: <info@$domainName>" . $eol;
$headers .= "Organization: $companyName" . $eol;
$headers .= "MIME-Version: 1.0" . $eol;
$headers .= "Content-Transfer-Encoding: 7bit" . $eol;
if (mail($posts->dataRecoverEmail, $theSubject, $theMessage, $headers)) {
	$fail='<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button> A password reset link had been sent to your email which expires in 24 hours from now.</div>';
}else{
	$fail='<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button> Unable to send password reset link to your email contact support.</div>';
}*/