<?php global $sitePage;

$err=0;
$fail='';
$posteds=new stdClass();

if ( in_array($sitePage, array("contact")) and ($requestMethod == 'POST') ) :
	$posteds =(object)$Site['post'];
	if ( empty($posteds->send) ):
		$err++;
		$fail .= '<p>Invalid form request!</p>';
	endif;
	if ( empty($posteds->names) ):
		$err++;
		$fail .= '<p>Kindly enter your name!</p>';
	endif;
	if ( empty($posteds->email) or !checkEmail($posteds->email)):
		$err++;
		$fail .= '<p>Kindly enter a valid email!</p>';
	endif;
	if ( empty($posteds->message) ):
		$err++;
		$fail .= '<p>Kindly enter a message!</p>';
	endif;
	if ( empty($posteds->subject) ):
		$posteds->subject= 'Comment';
	endif;
	if($err==0):
	    $eol = "\r\n";
		$theSitePath = $siteProtocol.$domainName;
		$theMessage="Sender Name: ".$posteds->names.(empty($posteds->phone? "": "\n\nTelephone: ".$posteds->phone))."\n\nMessage: ".$posteds->message.PHP_EOL;
		$theSubject = $posteds->subject;

		$headers = "From: <".$posteds->email.">" . $eol;
		$headers .= "Organization: City Hoppers Transport Services" . $eol;
		$headers .= "MIME-Version: 1.0" . $eol;
		$headers .= "Content-Transfer-Encoding: 7bit" . $eol;
		if (mail("<info@".$domainName.">", $theSubject, $theMessage, $headers)) :
			$fail='<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button> <p>Your message had been successfully sent.<br/>Thanks!</p></div>';
		else:
			$fail='<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Error 601:</h3> <p>Unable to connect to send message</p></div>';
		endif;
// echo "<script>alert(1);</script>";
	else:
		$fail='<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Message Sending Failed:</h3> '.$fail.'</div>';
	endif;
endif;

$smarty->assign("posts", $posteds)->assign("msg", $fail);