<?php global $sitePage;$posts= (object)$Site["post"];
$servers=(object)$Site["server"];
// Do discounting here and @ pscurl on both guest ahd admin end
$sessions= (object)$Site["session"];
if( !empty(bookinTokenExists1($sessions->tempToken)) and !empty($tempBookings->search) and !empty($tempBookings->vehicle) and !empty($tempBookings->userdata) ){
	if ($posts->triggers=='makePayment') {
		// Triggers paystack Payment Gateway

		/*if( empty($posts->terms) or $posts->terms!='1'):
			$fail='<div class="alert alert-danger alert-dismissible" role="alert" style="position: absolute; z-index: 1100; vertical-align: middle; align-self: center; width: 70% !important; top: 140px; margin-left: 15%;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Error Messages</h3> '.$fail.'</div>';
		endif;*/
		if ($tempBookings->userdata->payment=='ps') {
			$curl = curl_init();

			$email = $tempBookings->userdata->email[0];
			// factor in the discount but ask boss first
			$amount = $tempBookings->userdata->total*100;  //the amount in kobo. This value is actually NGN 300

			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://api.paystack.co/transaction/initialize",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_CUSTOMREQUEST => "POST",
			  CURLOPT_POSTFIELDS => json_encode([
			    'amount'=>$amount,
			    'email'=>$email,
			  ]),
			  CURLOPT_HTTPHEADER => [
			    "authorization: Bearer sk_live_132af3c2eb03df6a59ea188231a14c4014492869", //replace this with your own test key  sk_test_3f6245c379132ff5fe57e0c0bdc59cb4489a5426 sk_test_97faafb8e67bf660a85db8e8531f2215ebb907ec
			    "content-type: application/json",
			    "cache-control: no-cache"
			  ],
			));

			$response = curl_exec($curl);
			$err = curl_error($curl);

			if(!empty($err) and $err){
			  // there was an error contacting the Paystack API
			  error_log('Curl returned error: ' . $err);
				$fail.='<p>'.'Curl returned error: ' . $err.'</p>';
			}else{
				$tranx = json_decode($response, true);

				if(!$tranx->status){
				  // there was an error from the API
				  // print_r('API returned error: ' . $tranx['message']);
				  $fail.='<p>'.'API returned error: ' . $tranx['message'].'</p>';
				}

				// comment out this line if you want to redirect the user to the payment page
				// print_r($tranx);
				// error_log(json_encode($tranx ));
				// Added by Me
				$ezDb->query("INSERT INTO `paystack_hits1` (`data_intransit`,`token`) VALUES ('".json_encode($tranx)."','$sessions->tempToken');");
				// End Added By me
				// redirect to page so User can pay
				// uncomment this line to allow the user redirect to the payment page
				header('Location: ' . $tranx['data']['authorization_url']);
				/*End Payshack Payment*/
			}
		}
	}
}
