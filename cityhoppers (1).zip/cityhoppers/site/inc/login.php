<?php global $sitePage;
$posts= (object)$Site["post"];
$servers=(object)$Site["server"];

// All for Booking and Payment

$fail='';
$err=0;
$sessions= (object)$Site["session"];
if( !empty(bookinTokenExists1($sessions->tempToken)) ){
	$tempBookings=$ezDb->get_row("SELECT * FROM `temp_booking1` WHERE `token`='$sessions->tempToken';");
	$tempBookings->search=json_decode($tempBookings->search);
	$tempBookings->vehicle=json_decode($tempBookings->vehicle);
	$tempBookings->userdata=json_decode($tempBookings->userdata);
	if(!empty($tempBookings->search) and !empty($tempBookings->vehicle)){
		require_once "save_client_data.php";
		require_once "billing-payment.php";
		$smarty->assign('booked','booked')->assign('tempBookings', $tempBookings)->assign('msg',$fail)->assign('userData',$tempBookings->userdata);
	}else{
		redirect('select_vehicle_tripNseat');
	}
}

// End All for Booking and Payment