<?php
ob_start();
$command = basename(__FILE__);
date_default_timezone_set('Africa/Lagos');
require_once "../../config.php";

require_once "../../$libraries/functions.php";
require_once "../../$libraries/ezsql/ez_sql_core.php";
require_once "../../$libraries/ezsql/ez_sql_mysql.php";
require_once "../../../db_config.php";

$Site["session"]=$_SESSION;
$Site["cookie"]=$_COOKIE;
$Site["post"]=$_POST;
$Site["get"]=$_GET;
$Site["files"]=$_FILES;
$Site["server"]=$_SERVER;

$ret=null;
$posts=(object) $Site["post"];
if(!empty($posts->evt)){
	if($posts->evt=='getTo'):
		$ret=getDestinations($posts->tripType, $posts->travelFrom);
	elseif($posts->evt=='getDates'):
		$ret= getTiming($posts->tripType, $posts->travelFrom, $posts->travelTo);
	elseif($posts->evt=='ticketDetails'):
		$ret=getTicketDetails($posts->ticketID);
	elseif( in_array($posts->evt, array('roundTrip', 'oneWay') ) ):
		$ret=getSources($posts->tripType);
	elseif( in_array($posts->evt, array('roundTrip1', 'oneWay1') ) ):
		$ret=getSources1($posts->tripType);
	elseif($posts->evt=='getTo1'):
		$ret=getDestinations1($posts->tripType, $posts->travelFrom);
	elseif($posts->evt=='getDates1'):
		$ret= getTiming1($posts->tripType, $posts->travelFrom, $posts->travelTo);
	endif;
}

/*Return back to requester*/
if( in_array($posts->evt, array('roundTrip', 'getTo', 'oneWay', 'getDates', 'ticketDetails','roundTrip1', 'getTo1', 'oneWay1', 'getDates1') ) ){
	$ret=json_encode($ret);
}

echo $ret;