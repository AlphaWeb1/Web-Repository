<?php
ob_start();
$command = basename(__FILE__);
date_default_timezone_set('Africa/Lagos');
require_once "../../../config.php";

require_once "../../../$libraries/functions.php";
require_once "../../../$libraries/ezsql/ez_sql_core.php";
require_once "../../../$libraries/ezsql/ez_sql_mysql.php";
require_once "../../../../db_config.php";
foreach ($myGlobals as $key => $value) {
    $Site["$key"] = $value;
}
$Site["session"]=$_SESSION;
$Site["cookie"]=$_COOKIE;
$Site["post"]=$_POST;
$Site["get"]=$_GET;
$Site["files"]=$_FILES;
$Site["server"]=$_SERVER;

/*// Authentication Starts Here

if( !empty($Site["session"]["User"]["admin"]["Token"]) and sessionExists($Site["session"]["User"]["admin"]["Token"])==true ):
    // error_log($sitePage);
    if( !empty($Site["session"]["User"]["client"]["Token"]) and sessionExists($Site["session"]["User"]["client"]["Token"])==true ):
        unset($Site["session"]["User"]);
        unset($Site["session"]['Site']["Page"]);
        $_SESSION=$Site["session"];
        redirect( $Site['siteProtocol'].$Site['domainName']."/admin?e=".base64_encode( ("".$Site['siteProtocol'].$Site['domainName']."/".$Site['getURI'])."") );
    endif;
    /*Restrict Un authorized Admin*/
   /* if(!in_array($Site["session"]["User"]["userinfo"]->userrole, array("level0","level1","level2","level3"))):
        unset($Site["session"]["User"]);
        unset($Site["session"]['Site']["Page"]);
        $_SESSION=$Site["session"];
        redirect( $Site['siteProtocol'].$Site['domainName']."/admin?e=".base64_encode( ("".$Site['siteProtocol'].$Site['domainName']."/".$Site['getURI'])."") );
    endif;*/
 // Authentication Suspended*/

    //Your checkings starts here
    $ret=null;
    $posts=(object) $Site["post"];
    $gets=(object)$Site["get"];
    $sessions=(object)$Site["session"];

    $sitePage=null;
    // if( !empty($posts->sp) or !empty($gets->sp)){
    // 	$sitePage=(!empty($posts->sp)? $posts->sp: $gets->sp);
    // }

    if(!empty($posts->evt)){
        if($posts->evt=='getTo'):
            $ret=getDestinations($posts->tripType, $posts->travelFrom);
        elseif($posts->evt=='getDates'):
            $ret= getTiming($posts->tripType, $posts->travelFrom, $posts->travelTo);
        elseif( in_array($posts->evt, array('roundTrip', 'oneWay') ) ):
            $ret=getSources($posts->tripType);
        elseif($posts->evt=='viewManifest'):
            $ret=getManifest($posts->manifestId);
        elseif( in_array($posts->evt, array('roundTrip1', 'oneWay1') ) ):
            $ret=getSources1($posts->tripType);
        elseif($posts->evt=='getTo1'):
            $ret=getDestinations1($posts->tripType, $posts->travelFrom);
        elseif($posts->evt=='getDates1'):
            $ret= getTiming1($posts->tripType, $posts->travelFrom, $posts->travelTo);
        elseif($posts->evt=='viewManifest1'):
            $ret=getManifest1($posts->manifestId);
        endif;
    }


    // if($sitePage=="security" and !empty($posts->sd)){
    // 	if( $data=$ezDb->get_row("SELECT `password`,`username` FROM `".$siteName."_users` WHERE (FROM_base64(`username`)='".$posts->sd['username']."' OR FROM_base64(`email`)='".$posts->sd['username']."') AND `userType`='lawyer' AND `verified`='1';") ){
    //     	if( $data->password==sha1(md5(base64_encode($posts->sd['password']))) ){
    //     		$Site["session"]['Site']["User"]["security2"]=true;
    //     		$_SESSION=$Site["session"];
    //     		generateSecurityToken();
    //     		$response='success';
    //     	}else{
    //     		unset($Site["session"]['Site']["User"]["security2"]);
    //     		$_SESSION=$Site["session"];
    //     		$ret='Invalid username or password';
    //     		nullifySecurityToken();
    //     	}
    //     }else{
    // 		unset($Site["session"]['Site']["User"]["security2"]);
    // 		$_SESSION=$Site["session"];
    //     	$ret='Invalid username or password';
    //     	nullifySecurityToken();
    //     }
    // }elseif( in_array($sitePage, array("profile")) and !empty($posts->csd) ){
    //     if( $posts->csd['type']=="country" ){
    //         $ret= json_encode( getStates($posts->csd['data']) );
    //     }elseif( $posts->csd['type']=="state" ){
    //         $ret= json_encode( getCities($posts->csd['data']) );
    //     }
    // }

    /*Return back to requester*/
    if( in_array($posts->evt, array('viewManifest', 'roundTrip', 'oneWay', 'getTo', 'getDates', 'viewManifest1', 'roundTrip1', 'getTo1', 'oneWay1', 'getDates1')) ){
        $ret=json_encode($ret);
    }

    if ( !empty($ret) ) {
    	echo $ret;
    }
/* // Authentication Continues
else:
    redirect( $Site['siteProtocol'].$Site['domainName']."/admin?e=".base64_encode( ("".$Site['siteProtocol'].$Site['domainName']."/".$Site['getURI']) ) );
endif;
// Authentication Ends*/