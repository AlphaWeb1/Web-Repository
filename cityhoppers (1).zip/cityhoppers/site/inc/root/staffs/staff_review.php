<?php

$fail='';
$err=0;
$revID="rv".date("Ymdhis").getToken(3);
// error_log(json_encode($posts));
if(!empty($posts->triggers) and $posts->triggers=='newreview'){
	if( empty($posts->reviewid) ):
		$err++;
		$fail.='<p>Invalid review id</p>';
	endif;
	if( empty($posts->title) ):
		$err++;
		$fail.='<p>Kindly enter review title</p>';
	endif;
	if( !empty($posts->reviewtype) and !in_array($posts->reviewtype, array("incident", "accident")) ):
		$err++;
		$fail.='<p>Kindly select a valid review type</p>';
	endif;
	if( empty($posts->content) ):
		$err++;
		$fail.='<p>kindly enter review content</p>';
	endif;
	if( empty($ezDb->get_var("SELECT `username` FROM `userprofile` WHERE `username`='$posts->staffid' AND `usertype` IN('driver','admin')")) ):
		$err++;
		$fail.='<p>Selected staff does not exists</p>';
	endif;
	if($err==0):
		$posts->reviewtype=(empty($posts->reviewtype)? 'default': $posts->reviewtype);
		$posts->content=testInput($posts->content);
		$ezDb->query("INSERT INTO `staffreview` (`reviewid`, `staffid`, `title`, `content`, `dateadded`, `reviewtype`, `addedby`) VALUES ('$posts->reviewid','$posts->staffid','$posts->title','$posts->content', '$dateNow', '$posts->reviewtype', '$user');");
		$fail='<div class="alert alert-success alert-dismissible" role="alert" style="position: absolute; z-index: 1100; vertical-align: middle; align-self: center; width: 70% !important; top: 140px; margin-left: 15%;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Messages</h3> <p>Review added successfully!<br/> Check out review id:'.$posts->reviewid.'</p></div>';
	else:
		$fail='<div class="alert alert-danger alert-dismissible" role="alert" style="position: absolute; z-index: 1100; vertical-align: middle; align-self: center; width: 70% !important; top: 140px; margin-left: 15%;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Error Messages</h3> '.$fail.'</div>';
	endif;
}
$reviews=$ezDb->get_results("SELECT * FROM `staffreview` ORDER BY `dateadded` DESC;");
if(!empty($reviews)){
	foreach ($reviews as $value) {
		$value->staff=$ezDb->get_row("SELECT `username`, `firstname`, `lastname`, `middlename`, `email`, `phone`, `usertype` FROM `userprofile` WHERE `usertype` IN('driver','admin') AND `username`='$value->staffid';");
	}
}
$staffs=$ezDb->get_results("SELECT * FROM `userprofile` WHERE `usertype` IN('driver','admin') ORDER BY `dateadded` DESC;");

$smarty->assign('staffs', $staffs)->assign('reviews', $reviews)->assign('revID', $revID)->assign('err', $fail)->assign('gets',$gets);