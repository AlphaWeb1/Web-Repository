<?php

$transactions=$ezDb->get_results("SELECT * FROM `payment1` WHERE `paidby`='$user' ORDER BY `transdate` DESC;");
$smarty->assign('transactions', $transactions);