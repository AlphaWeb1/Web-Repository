<?php
if(!in_array($Site["session"]["User"]["userinfo"]->userrole, array("level0", "level1"))):
	redirect("./my-account/transactions");
endif;

$fail='';
$err=0;
if(!empty($posts->triggers) and $posts->triggers=='schaduleSetting'){
	if( empty($posts->source) ):
		$err++;
		$fail.='<p>Kindly Enter Departure From</p>';
	endif;
	if( empty($posts->destination) ):
		$err++;
		$fail.='<p>Kindly Enter Arrival Destination</p>';
	endif;
	if( !in_array($posts->discountStat, array("0","1")) ):
		$err++;
		$fail.='<p>Choose Vaid Discount Status</p>';
	endif;
	if( empty($posts->price) or $posts->price<1000.00 ):
		$err++;
		$fail.='<p>Price Has To Be In Thousands</p>';
	endif;
	if( $posts->discount<0 or $posts->discount>100 ):
		$err++;
		$fail.='<p>Discount Must Be In The Range Of 0% To 100%</p>';
	endif;
	if($err==0):
		$settings=getSettings();
		//{"source":"Lagos (Ajah)","destination":"Abuja","price":"9000","discount":"0","discountStat":"1"}
		unset($posts->triggers);
		$emptyschedules=$ezDb->get_results("SELECT * FROM `tripschedules1` WHERE `chosenseats`=''");
		if(!empty($emptyschedules) and is_array($emptyschedules)):
			foreach($emptyschedules as $empsched):
				if ($empsched->source==$settings->schedule->source and $ezDb->get_var("SELECT `chosenseats` FROM `tripschedules1` WHERE `token`='$empsched->token'")==''):
					$ezDb->query("UPDATE `tripschedules1` SET `source`='$posts->source',`destination`='$posts->destination',`unitfee`='$posts->price',`discount`='$posts->discount' WHERE `token`='$empsched->token'");
				elseif($empsched->destination==$settings->schedule->source and $ezDb->get_var("SELECT `chosenseats` FROM `tripschedules1` WHERE `token`='$empsched->token'")==''):
					$ezDb->query("UPDATE `tripschedules1` SET `source`='$posts->destination',`destination`='$posts->source',`unitfee`='$posts->price',`discount`='$posts->discount' WHERE `token`='$empsched->token'");
				endif;
			endforeach;
		endif;
		$schedsetting=json_encode($posts);
		if (empty($settings) and !is_object($settings)) {
			$query="INSERT INTO `settings` (`schedule`,`updated`) VALUES ('$schedsetting','$dateNow');";
		}else{
			$query="UPDATE `settings` SET `schedule`='$schedsetting';";
		}
		$ezDb->query($query);

		$fail='<div class="alert alert-success alert-dismissible" role="alert" style="position: absolute; z-index: 1100; vertical-align: middle; align-self: center; width: 70% !important; top: 140px; margin-left: 15%;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Messages</h3> <p>Schedule Settings Had Been Updated Successfully!</p></div>';
	else:
		$fail='<div class="alert alert-danger alert-dismissible" role="alert" style="position: absolute; z-index: 1100; vertical-align: middle; align-self: center; width: 70% !important; top: 140px; margin-left: 15%;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Error Messages</h3> '.$fail.'</div>';
	endif;
}
if(!empty($posts->triggers) and $posts->triggers=='bannerSetting'){
	$extensions = array("image/jpg","image/png","image/jpe","image/jpeg","image/tiff","image/webp","image/jp2","image/gif");
	$targetDir = 'site/media/i/settings/';
	if( empty($posts->title) ):
		$err++;
		$fail.='<p>Enter banner\'s title</p>';
	endif;
	if( !in_array($posts->On, array("0","1")) ):
		$err++;
		$fail.='<p>Select a valid visible option</p>';
	endif;
	if( empty($files->bannerImg['tmp_name'])):
		$posts->bannerImg='site/media/i/all/blueblack2.jpg';
	elseif (!in_array(strtolower($mime=getMime($files->bannerImg['tmp_name'])), $extensions)):
    	$fail .= '<p>Kindly upload a valid banner</p><p>This is not an image file. Only JPG, JPEG, PNG, JPE, WEBP, JP2, or Animated GIF file is allowed.</p>';
        $err++;
    endif;

	if($err==0):
		$settings=getSettings();
		// Create Folders and Upload Image
		if (!file_exists($targetDir)):
	        mkdir($targetDir, 0777, true);
	    endif;
	    if( !empty($files->bannerImg['tmp_name'])){
		    $targetFile = $targetDir ."banner.png";
		    if (file_exists($targetFile)) {
		    	unlink($targetFile);
		    }
		    if(move_uploaded_file($files->bannerImg["tmp_name"], $targetFile)){
		    	$posts->bannerImg=$targetFile;
		    }
		}
	    // Save to Database
		$query="";
		unset($posts->triggers);
		$banner=json_encode($posts);
		if (empty($settings) and !is_object($settings)) {
			$query="INSERT INTO `settings` (`banner`,`updated`) VALUES ('$banner','$dateNow');";
		}else{
			$query="UPDATE `settings` SET `banner`='$banner';";
		}
		$ezDb->query($query);

		$fail='<div class="alert alert-success alert-dismissible" role="alert" style="position: absolute; z-index: 1100; vertical-align: middle; align-self: center; width: 70% !important; top: 140px; margin-left: 15%;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Messages</h3> <p>Banner Settings Had Been Updated Successfully!</p></div>';
	else:
		$fail='<div class="alert alert-danger alert-dismissible" role="alert" style="position: absolute; z-index: 1100; vertical-align: middle; align-self: center; width: 70% !important; top: 140px; margin-left: 15%;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Error Messages</h3> '.$fail.'</div>';
	endif;
}


$settings=getSettings();

$smarty->assign('settings', $settings);