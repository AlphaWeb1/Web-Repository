<?php

if (!empty($gets->trigg) and $gets->trigg=='confirm' and !empty($gets->hireId) and !empty("SELECT `token` FROM `hiring` WHERE `token`='$gets->hireId' AND `responsestatus`=0;")) {
	$ezDb->query("UPDATE `hiring` SET `responsestatus`=1 WHERE `token`='$gets->hireId';");
	$fail='<div class="alert alert-success alert-dismissible" role="alert" style="position: absolute; z-index: 1100; vertical-align: middle; align-self: center; width: 70% !important; top: 140px; margin-left: 15%;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Success!</h3> <p>Hiring request had been successfully confirmed</p></div>';
}

$rentals=$ezDb->get_results("SELECT * FROM `hiring` ORDER BY `daterequested` DESC;");
if (!empty($rentals)) {
	foreach ($rentals as $rental) {
		$rental->contacts=json_decode($rental->contacts);
		$rental->otherInfo=json_decode($rental->otherInfo);
	}
}
$smarty->assign('rentals', $rentals);