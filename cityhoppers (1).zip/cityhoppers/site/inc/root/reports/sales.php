<?php

$sales= new stdClass;
$sales->daily['Total']=$ezDb->get_row("SELECT IFNULL(SUM(`noOfPerson`),'0') AS `count`, IFNULL(SUM(`totalFee`),'0.00') AS `amount` FROM `booking1` WHERE DATEDIFF('$dateNow', `bookingDate`)=0");
$sales->daily['Online']=$ezDb->get_row("SELECT IFNULL(SUM(`noOfPerson`),'0') AS `count`, IFNULL(SUM(`totalFee`),'0.00') AS `amount` FROM `booking1` WHERE `bookedBy`='guest' AND DATEDIFF('$dateNow', `bookingDate`)=0");
$sales->daily['Manual']=$ezDb->get_row("SELECT IFNULL(SUM(`noOfPerson`),'0') AS `count`, IFNULL(SUM(`totalFee`),'0.00') AS `amount` FROM `booking1` WHERE `bookedBy`='admin' AND DATEDIFF('$dateNow', `bookingDate`)=0");

$sales->weekly['Total']=$ezDb->get_row("SELECT IFNULL(SUM(`noOfPerson`),'0') AS `count`, IFNULL(SUM(`totalFee`),'0.00') AS `amount` FROM `booking1` WHERE TIMESTAMPDIFF(WEEK, '$dateNow', `bookingDate`)=0");
$sales->weekly['Online']=$ezDb->get_row("SELECT IFNULL(SUM(`noOfPerson`),'0') AS `count`, IFNULL(SUM(`totalFee`),'0.00') AS `amount` FROM `booking1` WHERE `bookedBy`='guest' AND TIMESTAMPDIFF(WEEK, '$dateNow', `bookingDate`)=0");
$sales->weekly['Manual']=$ezDb->get_row("SELECT IFNULL(SUM(`noOfPerson`),'0') AS `count`, IFNULL(SUM(`totalFee`),'0.00') AS `amount` FROM `booking1` WHERE `bookedBy`='admin' AND TIMESTAMPDIFF(WEEK, '$dateNow', `bookingDate`)=0");

$sales->monthly['Total']=$ezDb->get_row("SELECT IFNULL(SUM(`noOfPerson`),'0') AS `count`, IFNULL(SUM(`totalFee`),'0.00') AS `amount` FROM `booking1` WHERE TIMESTAMPDIFF(MONTH, '$dateNow', `bookingDate`)=0");
$sales->monthly['Online']=$ezDb->get_row("SELECT IFNULL(SUM(`noOfPerson`),'0') AS `count`, IFNULL(SUM(`totalFee`),'0.00') AS `amount` FROM `booking1` WHERE `bookedBy`='guest' AND TIMESTAMPDIFF(MONTH, '$dateNow', `bookingDate`)=0");
$sales->monthly['Manual']=$ezDb->get_row("SELECT IFNULL(SUM(`noOfPerson`),'0') AS `count`, IFNULL(SUM(`totalFee`),'0.00') AS `amount` FROM `booking1` WHERE `bookedBy`='admin' AND TIMESTAMPDIFF(MONTH, '$dateNow', `bookingDate`)=0");

$smarty->assign('sales', $sales);