<?php

if (!empty( ticketExists1($gets->ticket)) ) {
	$bookings=$ezDb->get_row("SELECT * FROM `booking1` WHERE `ticketNo`='$gets->ticket';");
	$bookings->bookingInfo=json_decode($bookings->bookingInfo);

	$tempBookings=$ezDb->get_row("SELECT * FROM `temp_booking1` WHERE `token`='$bookings->bookingtoken';");
	$tempBookings->search=json_decode($tempBookings->search);
	$tempBookings->vehicle=json_decode($tempBookings->vehicle);
	$tempBookings->userdata=json_decode($tempBookings->userdata);
	$tempBookings->bookingID=$gets->ticket;

	$smarty->assign('booked','booked')->assign('tempBookings', $tempBookings)->assign('userData',$tempBookings->userdata)->assign('bookings',$bookings);
}else{
	redirect("../ticket");
}