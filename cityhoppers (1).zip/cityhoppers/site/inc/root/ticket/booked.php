<?php

$sessions= (object)$Site["session"];

$fail='';
$err=0;
if( empty(bookinTokenExists1($sessions->tempToken)) and $err==0){
	redirect("./booking");
}

if( !empty(bookinTokenExists1($sessions->tempToken)) ){
	$tempBookings=$ezDb->get_row("SELECT * FROM `temp_booking1` WHERE `token`='$sessions->tempToken';");
	$tempBookings->search=json_decode($tempBookings->search);
	$tempBookings->vehicle=json_decode($tempBookings->vehicle);
	$tempBookings->userdata=json_decode($tempBookings->userdata);
	if(!empty($tempBookings->search) and !empty($tempBookings->vehicle)){
		require_once "save_client_data.php";
		// require_once "billing-payment.php";
		$smarty->assign('booked','booked')->assign('tempBookings', $tempBookings)->assign('fail',$fail)->assign('userData',$tempBookings->userdata);
	}else{
		redirect('./booking');
	}
}

// error_log($fail);
// error_log($fail);

$smarty->assign('tempBookings', $tempBookings)->assign('err',$fail)->assign('userData',$tempBookings->userdata);
// error_log(bookinTokenExists($sessions->tempToken));