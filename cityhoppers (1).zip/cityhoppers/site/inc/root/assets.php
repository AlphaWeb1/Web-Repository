<?php

if(!in_array($Site["session"]["User"]["userinfo"]->userrole, array("level0","level1"))):
	redirect("./my-account/transactions");
endif;
