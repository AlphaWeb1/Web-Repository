<?php

if(!in_array($Site["session"]["User"]["userinfo"]->userrole, array("level0","level1"))):
	redirect("./my-account/transactions");
endif;

$fail='';
$err=0;
if(!empty($posts->triggers) and $posts->triggers=='newstaff'){
	$extensions = array("image/jpg","image/png","image/jpe","image/jpeg","image/tiff","image/webp","image/jp2");
	$extensions1 = array("application/msword", "application/pdf", "application/rtf");
	$targetDir = 'site/media/userdata/';
	if( empty($posts->firstname) ):
		$err++;
		$fail.='<p>Enter first name please</p>';
	endif;
	if( empty($posts->lastname) ):
		$err++;
		$fail.='<p>Enter last name please</p>';
	endif;
	if( empty($posts->email) or !checkEmail($posts->email)):
		$err++;
		$fail.='<p>Enter a valid email please</p>';
	endif;
	if( empty($posts->phone) ):
		$err++;
		$fail.='<p>Enter phone number please</p>';
	endif;
	if( empty($posts->usertype) or !in_array($posts->usertype, array("driver","admin","cashier", "attedant"))):
		$err++;
		$fail.='<p>Choose a valid user type please</p>';
	endif;
	if( empty($posts->userrole) or !in_array($posts->userrole, array("level1","level2","level3", "level4"))):
		$err++;
		$fail.='<p>Choose a valid user role please</p>';
	endif;
	if( empty($posts->active)):
		$posts->active='0';
	endif;
	if( empty($posts->gender) or !in_array($posts->gender, array("female","male"))):
		$err++;
		$fail.='<p>Enter firstname please</p>';
	endif;
	if( empty($posts->password)):
		$err++;
		$fail.='<p>Kindly enter or generate a password, password field cannot be empty</p>';
	endif;
	if (!in_array(strtolower($mime1=getMime($_FILES['staffPhoto']['tmp_name'])), $extensions)):
    	$fail .= '<p>Kindly upload a valid profile picture</p><p>This is not an image file. Only JPG, JPEG, PNG, JPE, WEBP, or JP2 file is allowed.</p>';
        $err++;
    endif;
	if (!in_array(strtolower($mime2=getMime($_FILES['resume']['tmp_name'])), $extensions1)):
    	$fail .= '<p>Kindly upload a valid CV/Resume</p><p>This is not an image file. Only PDF or MS Word file is allowed.</p>';
        $err++;
    endif;

	if($err==0):
		$staffid="sid-".date("Ymd_his-").getToken(3);
		// generate token for staff id
		// insert into database
		if (!file_exists($targetDir."ppics/")):
	        mkdir($targetDir."ppics/", 0777, true);
	    endif;
	    if (!file_exists($targetDir."pdoc/")):
	        mkdir($targetDir."pdoc/", 0777, true);
	    endif;
	    $newName = $staffid.'_.png';
	    $newName1= $staffid.'_.'.(explode("/", $mime2)[1]);
    	$targetFile = $targetDir ."ppics/". $newName;
    	$targetFile1 = $targetDir ."pdoc/". $newName1;
    	@move_uploaded_file($_FILES["staffPhoto"]["tmp_name"], $targetFile);
    	@move_uploaded_file($_FILES["resume"]["tmp_name"], $targetFile1);
    	$profiledocs=json_encode(array("profile"=>$targetFile, "resume"=>$targetFile));
    	
		$emergencycontacts=json_encode(array($posts->emergency1, $posts->emergency2));
		
		$ezDb->query("INSERT INTO `userprofile` (`email`, `firstname`, `middlename`, `lastname`, `gender`, `username`, `password`, `userrole`, `usertype`, `emergencycontacts`,`profiledocs`, `datehired`, `datefired`, `phone`, `address1`,`address2`,`state`,`city`,`country`,`active`,`dateadded`,`addedby`,`verified`) VALUES 
			('$posts->email','$posts->firstname','$posts->middlename','$posts->lastname','$posts->gender','$staffid', to_base64('$posts->password'), '$posts->userrole', '$posts->usertype', '$emergencycontacts', '$profiledocs', '$posts->datehired', '$posts->datefired', '$posts->phone', '$posts->address1', '$posts->address2', '$posts->state', '$posts->city', '$posts->country', '$posts->active', '$dateNow', '$user', '1');");
		$fail='<div class="alert alert-success alert-dismissible" role="alert" style="position: absolute; z-index: 1100; vertical-align: middle; align-self: center; width: 70% !important; top: 140px; margin-left: 15%;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Messages</h3> <p>Staff added successfully!<br/> Check out staff id:'.$staffid.'</p></div>';
	else:
		$fail='<div class="alert alert-danger alert-dismissible" role="alert" style="position: absolute; z-index: 1100; vertical-align: middle; align-self: center; width: 70% !important; top: 140px; margin-left: 15%;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Error Messages</h3> '.$fail.'</div>';
	endif;
}


$staffs=$ezDb->get_results("SELECT * FROM `userprofile` WHERE `usertype` IN('driver','admin') AND `userrole` NOT IN('level0') ORDER BY `dateadded` DESC;");

$smarty->assign('staffs', $staffs)->assign('err', $fail);