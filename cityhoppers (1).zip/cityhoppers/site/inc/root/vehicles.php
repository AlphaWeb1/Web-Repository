<?php
if(!in_array($Site["session"]["User"]["userinfo"]->userrole, array("level0", "level1", "level2"))):
	redirect("./my-account/transactions");
endif;

$fail='';
$err=0;
if(!empty($posts->triggers) and $posts->triggers=='newvehicle'){
	if( empty($posts->vehiclename) ):
		$err++;
		$fail.='<p>Enter a vehicle model</p>';
	endif;
	if( empty($posts->platenumber) ):
		$err++;
		$fail.='<p>Enter a plate number</p>';
	endif;
	if( empty($posts->capacity) or !is_numeric($posts->capacity) or $posts->capacity<1):
		$err++;
		$fail.='<p>Enter a valid vehicle capacity</p>';
	endif;
	if( empty($posts->driver) or empty($ezDb->get_var("SELECT `username` FROM `userprofile` WHERE `username`='$posts->driver'")) ):
		$err++;
		$fail.='<p>Select a valid capacity</p>';
	endif;
	if( empty($posts->type) or !in_array($posts->type, array('big','small')) ):
		$err++;
		$fail.='<p>Select a valid vehicle type</p>';
	endif;
	error_log(json_encode($posts));
	if($err==0):
		$vhid=("vehicle0".$ezDb->get_var("SELECT (`id`+1) FROM `vehicles` ORDER BY `id` DESC LIMIT 1;"));
		
		$ezDb->query("INSERT INTO `vehicles` (`vehicleid`, `model`, `plateno`, `capacity`, `driversid`, `addedby`, `dateadded`, `description`, `type`) VALUES ('$vhid','$posts->vehiclename','$posts->platenumber','$posts->capacity','$posts->driver','$user ', '$dateNow', '$posts->description', '$posts->type');");
		$fail='<div class="alert alert-success alert-dismissible" role="alert" style="position: absolute; z-index: 1100; vertical-align: middle; align-self: center; width: 70% !important; top: 140px; margin-left: 15%;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Messages</h3> <p>Vehicle added successfully!<br/> Check out vehicle id:'.$vhid.'</p></div>';
	else:
		$fail='<div class="alert alert-danger alert-dismissible" role="alert" style="position: absolute; z-index: 1100; vertical-align: middle; align-self: center; width: 70% !important; top: 140px; margin-left: 15%;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Error Messages</h3> '.$fail.'</div>';
	endif;
}


$vehicles=$ezDb->get_results("SELECT * FROM `vehicles` ORDER BY `dateadded` DESC;");
$drivers=$ezDb->get_results("SELECT * FROM `userprofile` WHERE `usertype`='driver' ORDER BY `dateadded` DESC;");

$smarty->assign('vehicles', $vehicles)->assign('drivers', $drivers)->assign('fail', $fail);