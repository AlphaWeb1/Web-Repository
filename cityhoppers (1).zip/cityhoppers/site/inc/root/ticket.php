<?php
// $_SESSION['tempToken']='GRwt6bvxrhrJsZ3';
$fail='';
$err=0;

if(!empty($posts->triggers) and $posts->triggers=='bookTicket'){
	if( !in_array($posts->tripType, array('0','1')) ):
		$err++;
		$fail.='<p>Invalid Ticket Type</p>';
	endif;
	$tripDetails=getSourcesAndDestination1($posts->tripType, $posts->travelFrom, $posts->travelTo);
	if( empty($posts->travelFrom) or empty($tripDetails) ):
		$err++;
		$fail.='<p>Invalid Trip Selection: check your Traveling From and Traveling To</p>';
	endif;
	if( $posts->tripType=='0' and (!empty( $posts->retDate ) or empty( $posts->deptDate )) ):
		$err++;
		$fail.='<p>Invalid Date Selection: One Way Trip is empty or Return Date is selected</p>';
	endif;
	if( $posts->tripType=='1' and (empty( $posts->retDate ) or empty( $posts->deptDate )) ):
		$err++;
		$fail.='<p>Invalid Date Selection: check Round Trip departure and return date</p>';
	endif;
	if( checkDepartureORReturnTime1( $posts->deptDate )<1 ):
		$err++;
		$fail.='<p>Invalid Date Selection: Departure date does not exist or outdated<br/> It has to be 30 minutes difference</p>';
	endif;
	if( $posts->tripType=='1' and ( dateDifference(date("Y-m-d H:i:s", strtotime($posts->deptDate)), date("Y-m-d H:i:s", strtotime($posts->retDate)))->d<1) ):
		$err++;
		$fail.='<p>Invalid Date Selection: Return date does not exist or outdated<br/> It has to be a day difference to the departure date</p>';
	endif;
	$depD=date("Y-m-d H:i:s", strtotime($posts->deptDate));
	if($ezDb->get_var("SELECT DATEDIFF('$depD', '$dateNow' )") < 0 ):
		$err++;
		$fail.='<p>Invalid date Selection: You are not allowed to select past date for departure</p>';
	endif;
	if($posts->tripType=='1'):
		$retD=date("Y-m-d H:i:s", strtotime($posts->retDate));
		if($ezDb->get_var("SELECT DATEDIFF('$retD', '$dateNow')") < 1 ):
			$err++;
			$fail.='<p>Invalid date Selection: You are not allowed to select past date for return</p>';
		endif;
	endif;
	
	if($err==0):
		$bookInfo=new stdClass;
		do{
			$token=getToken(15);
		}while($ezDb->get_var("SELECT `token` FROM `temp_booking1` WHERE `token`='$token';"));
		$bookInfo->tripType=($posts->tripType==1?'Round Trip':'One Way');
		$bookInfo->deptDate=date("Y-m-d H:i:s", strtotime($posts->deptDate) );
		if($posts->tripType==1){
			$bookInfo->retDate=date("Y-m-d H:i:s", strtotime($posts->retDate) );
		}
		$bookInfo->travelFrom=$posts->travelFrom;
		$bookInfo->travelTo=$posts->travelTo;
		$bookInfo->passenger=$posts->passenger;
		$bookInfo->bookedBy=$user;

		$Site["session"]['tempToken']=$token;
		$_SESSION=$Site["session"];
		$sessions= (object)$Site["session"];

		// integration of username
		// $curUser=( !empty($Site["session"]["User"]["Username"])? $Site["session"]["User"]["Username"]);

		$search=json_encode($bookInfo);
		$ezDb->query("INSERT INTO `temp_booking1` (`token`, `ipaddress`, `user`, `search`, `dateadded`) VALUES ('$token', '$servers->REMOTE_ADDR', 'guest', '$search', '$dateNow');");
		$fail='<div class="alert alert-success alert-dismissible" role="alert" style="position: absolute; z-index: 1100; vertical-align: middle; align-self: center; width: 70% !important; top: 140px; margin-left: 15%;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Success!</h3></div>';
		$fail='';
	else:
		$fail='<div class="alert alert-danger alert-dismissible" role="alert" style="position: absolute; z-index: 1100; vertical-align: middle; align-self: center; width: 70% !important; top: 140px; margin-left: 15%;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Error Messages</h3> '.$fail.'</div>';
	endif;
}

$tickets=$ezDb->get_results("SELECT `b`.`id`, `b`.`client`, `b`.`bookedBy`, `b`.`bookingtoken`, `b`.`ticketNo`, `b`.`bookingInfo`, `b`.`bookingDate`, `b`.`billingId`, `b`.`noOfPerson`, `b`.`totalFee`, `tb`.`token`, `tb`.`ipaddress`, `tb`.`user`, `tb`.`search`,  `tb`.`vehicle`,  `tb`.`userdata`, `tb`.`dateadded`, `tb`.`status` FROM `temp_booking1` AS `tb`, `booking1` AS `b` WHERE `tb`.`token`=`b`.`bookingtoken` AND (`tb`.`status`='1' OR `tb`.`status`='2') ORDER BY `b`.`id` DESC;");
if (!empty($tickets)) {
	foreach ($tickets as  $value) {
		$value->bookingInfo=json_decode($value->bookingInfo);
		$value->search=json_decode($value->search);
		$value->vehicle=json_decode($value->vehicle);
		$value->userdata=json_decode($value->userdata);
	}
}


$smarty->assign('tickets', $tickets)->assign("fail",$fail);