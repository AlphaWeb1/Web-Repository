<?php
if(!in_array($Site["session"]["User"]["userinfo"]->userrole, array("level0", "level1", "level2"))):
	redirect("./my-account/transactions");
endif;

$schedID="schid".date("Ymdhis").getToken(2);

if(!empty($posts->triggers) and $posts->triggers=='newsched'){
	if( empty($posts->schedid) or $ezDb->get_var("SELECT `token` FROM `tripschedules1` WHERE `token`='$posts->schedid'")):
		$err++;
		$fail.='<p>Schedule ID is either empty or already exist</p>';
	endif;
	if( empty($posts->unitfee) or $posts->unitfee<1000.00):
		$err++;
		$fail.='<p>Enter a valid price, price cannot be lower that thousands</p>';
	endif;
	if( $posts->discount<0 or $posts->discount>100):
		$err++;
		$fail.='<p>Enter a valid discount, discount must be in the range of 0 to 100%</p>';
	endif;
	if( empty($posts->capacity) ):
		$err++;
		$fail.='<p>Enter a valid capacity, capacity must be greater than zero</p>';
	endif;
	if( !in_array($posts->type, array("0","1")) ):
		$err++;
		$fail.='<p>Select a valid trip type</p>';
	endif;
	if( $posts->type=='1'):
		$posts->return=date("Y-m-d H:i:s", strtotime($posts->return) );
		$posts->departure=date("Y-m-d H:i:s", strtotime($posts->departure) );
		// error_log("$posts->departure $posts->return");
		if($ezDb->get_var("SELECT TIMESTAMPDIFF(HOUR,'$dateNow', '$posts->departure')")<2 or $ezDb->get_var("SELECT DATEDIFF('$posts->return', '$dateNow')")<1):
			$err++;
			$fail.='<p>Either the return date or departure date is invalid<br/> departure date should be more thatn two hours later than now. While,<br/> return date must be a day later than now</p>';
		endif;
		if($ezDb->get_var("SELECT DATEDIFF('$posts->return', '$posts->departure')")<1):
			$err++;
			$fail.='<p>Departure date cannot be overhead of return date<br/> and also, the date interval between departure and return date must be a day different</p>';
		endif;

		if( !empty($scheid=$ezDb->get_var("SELECT `token` FROM `tripschedules1` WHERE `vehicleid`='$posts->vehicleid' AND `departure`='$posts->return';"))):
			$err++;
			$fail.='<p>This schedules already exist for this vehicle: '.$posts->vehicleid.' with schedule id: '.$scheid.'</p>';
		endif;
	else:
		$posts->return='0000-00-00 00:00:00';
		$posts->departure=date("Y-m-d H:i:s", strtotime($posts->departure) );
		if($ezDb->get_var("SELECT TIMESTAMPDIFF(HOUR,'$dateNow', '$posts->departure')")<2):
			$err++;
			$fail.='<p>The selected departure date is invalid, the date must be two hours ahead</p>';
		endif;
		if(!empty($ezDb->get_var("SELECT `chosenseats` FROM `tripschedules1` WHERE `token`='$posts->schedid'"))):
			$err++;
			$fail.='<p>This schedule cannot be added for there are ongoing tickets currently registered for departure</p>';
		endif;
		if( !empty($scheid=$ezDb->get_var("SELECT `token` FROM `tripschedules1` WHERE `vehicleid`='$posts->vehicleid' AND `departure`='$posts->departure';"))):
			$err++;
			$fail.='<p>This schedules already exist for this vehicle: '.$posts->vehicleid.' with schedule id: '.$scheid.'</p>';
		endif;
	endif;
	if( empty($posts->source) or empty($posts->destination)):
		$err++;
		$fail.='<p>Departure or Arrial terminal cannot be empty</p>';
	endif;
	if( !empty($posts->source) and $posts->source==$posts->destination):
		$err++;
		$fail.='<p>Departure cannot be the same as Arrial terminal</p>';
	endif;
	if( empty($ezDb->get_var("SELECT `vehicleid` FROM `vehicles` WHERE `vehicleid`='$posts->vehicleid';"))):
		$err++;
		$fail.='<p>Invalid vehicle is selected</p>';
	endif;
	// if( !empty($ezDb->get_var("SELECT `vehicleid` FROM `tripschadule` WHERE `vehicleid`='$posts->vehicleid';"))):
	// 	$err++;
	// 	$fail.='<p>This vehicle had already been added to schedule ensure that the selected vehicle is new</p>';
	// endif;//Enable me When Project is completed


	if($err==0):
		// $schedID=$posts->schedid;
		// generate token for schedule id
		// insert into database
		
        error_log('message');
		$ezDb->query("INSERT INTO `tripschedules1` (`vehicleid`, `token`, `source`, `destination`, `departure`, `discount`, `unitfee`, `capacity`, `addedby`, `dateadded`, `datemodified`) VALUES ('$posts->vehicleid', '$posts->schedid', '$posts->source', '$posts->destination', '$posts->departure', '$posts->discount', '$posts->unitfee', '$posts->capacity', '$user', '$dateNow', '$dateNow');");
		if( $posts->type=='1'):
			$ezDb->query("INSERT INTO `tripschedules1` (`vehicleid`, `token`, `source`, `destination`, `departure`, `discount`, `unitfee`, `capacity`, `addedby`, `dateadded`, `datemodified`) VALUES ('$posts->vehicleid', 'ret-$posts->schedid', '$posts->destination', '$posts->source', '$posts->return', '$posts->discount', '$posts->unitfee', '$posts->capacity', '$user', '$dateNow', '$dateNow');");
		endif;
		/*Run a Two Weeks Routine for a new vehicle added ti a schedule Schadule*/
		runTwoWeeksUpfront1($posts, $user);//Enable me When Project is completed
		/*End the Run Two Weeks Stuff*/
		$fail='<div class="alert alert-success alert-dismissible" role="alert" style="position: absolute; z-index: 1100; vertical-align: middle; align-self: center; width: 70% !important; top: 140px; margin-left: 15%;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Messages</h3> <p>Schedule added successfully!<br/> Check out schedule id&quot;'.$posts->schedid.'&quot; and its instances</p></div>';
	else:
		$fail='<div class="alert alert-danger alert-dismissible" role="alert" style="position: absolute; z-index: 1100; vertical-align: middle; align-self: center; width: 70% !important; top: 140px; margin-left: 15%;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Error Messages</h3> '.$fail.'</div>';
	endif;
}

if(!empty($posts->triggers) and $posts->triggers=='updatesched'){
	if( empty($posts->schedid1) or empty($ezDb->get_var("SELECT `token` FROM `tripschedules1` WHERE `token`='$posts->schedid1'"))):
		$err++;
		$fail.='<p>This schedule id is either empty or does not exist</p>';
	endif;
	if( empty($posts->unitfee1) or $posts->unitfee1<1000.00):
		$err++;
		$fail.='<p>Enter a valid price, price cannot be lower that thousands</p>';
	endif;
	if( $posts->discount1<0 or $posts->discount1>100):
		$err++;
		$fail.='<p>Enter a valid discount, discount must be in the range of 0 to 100%</p>';
	endif;
	if( empty($posts->capacity1) ):
		$err++;
		$fail.='<p>Enter a valid capacity, capacity must be greater than zero</p>';
	endif;
	// if( !in_array($posts->type1, array("0","1")) ):
	// 	$err++;
	// 	$fail.='<p>Select a valid trip type</p>';
	// endif;
	$posts->departure1=date("Y-m-d H:i:s", strtotime($posts->departure1) );
	if($ezDb->get_var("SELECT TIMESTAMPDIFF(HOUR,'$dateNow', '$posts->departure1')")<2):
		$err++;
		$fail.='<p>The selected departure date is invalid, the date must be two hours ahead</p>';
	endif;
	if( !empty($scheid=$ezDb->get_var("SELECT `token` FROM `tripschedules1` WHERE `vehicleid`='$posts->vehicleid1' AND `departure`='$posts->departure1' AND `token`!='$posts->schedid1';"))):
		$err++;
		$fail.='<p>There is alread a schedule of this vehicle: '.$posts->vehicleid.' assigned to the selected departure date: '.$posts->departure1.' order than this</p>';
	endif;
	if( empty($posts->source1) or empty($posts->destination1)):
		$err++;
		$fail.='<p>Departure or Arrial terminal cannot be empty</p>';
	endif;
	if( !empty($posts->source1) and $posts->source==$posts->destination1):
		$err++;
		$fail.='<p>Departure cannot be thesame as Arrial terminal</p>';
	endif;
	if( empty($ezDb->get_var("SELECT `vehicleid` FROM `vehicles` WHERE `vehicleid`='$posts->vehicleid1';"))):
		$err++;
		$fail.='<p>Invalid vehicle is selected</p>';
	endif;
	error_log(json_encode($gets));
	if($err==0):
		$ezDb->query("UPDATE `tripschedules1` SET `source`='$posts->source1', `destination`='$posts->destination1', `departure`='$posts->departure1', `discount`='$posts->discount1', `unitfee`='$posts->unitfee1', `capacity`='$posts->capacity1', `addedby`='$user', `datemodified`='$dateNow' WHERE `token`='$posts->schedid1';");
		$fail='<div class="alert alert-success alert-dismissible" role="alert" style="position: absolute; z-index: 1100; vertical-align: middle; align-self: center; width: 70% !important; top: 140px; margin-left: 15%;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Messages</h3> <p>Schedule updated successfully!<br/> Check out schedule id:'.$posts->schedid1.'</p></div>';
	else:
		$fail='<div class="alert alert-danger alert-dismissible" role="alert" style="position: absolute; z-index: 1100; vertical-align: middle; align-self: center; width: 70% !important; top: 140px; margin-left: 15%;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Error Messages</h3> '.$fail.'</div>';
	endif;
}
//%Y-%m-%dT%H:%i:%s
$schedules=$ezDb->get_results("SELECT `token`, `id`, DATE_FORMAT(`departure`, '%Y-%m-%dT%H:%i:%s') AS `departure`, `vehicleid`, `source`, `destination`, `chosenseats`, `discount`, `unitfee`, `capacity`, `addedby`, `dateadded`, `datemodified`, `enabled` FROM `tripschedules1` ORDER BY `departure` ASC, `id` DESC;");
if(!empty($schedules)){
	foreach ($schedules as $value) {
		$value->vehicleDetails=$ezDb->get_row("SELECT * FROM `vehicles` WHERE `vehicleid`='$value->vehicleid';");
		$suffix=explode("-", $value->token);
		$suffix=(count($suffix)==2? $suffix[1]: "null");
		
		if(strpos($value->token, "ret-")!==FALSE or !empty($ezDb->get_var("SELECT `token` FROM `tripschedules1` WHERE `token`=CONCAT('ret-','$value->token');"))){
			$value->type='1';
		}else{
			$value->type='0';
		}
		//error_log(strpos($value->token, "ret-")."  $suffix $value->type");
	}
}

$departures=$ezDb->get_col("SELECT DISTINCT `source` FROM `tripschedules1` ORDER BY `datemodified` DESC;");
$arrivals=$ezDb->get_col("SELECT DISTINCT `destination` FROM `tripschedules1` ORDER BY `datemodified` DESC;");
$vehicles=$ezDb->get_results("SELECT * FROM `vehicles` ORDER BY `dateadded` DESC;");
$smarty->assign('schedules', $schedules)->assign('schedID', $schedID)->assign('departures', $departures)->assign('arrivals', $arrivals)->assign('vehicles', $vehicles)->assign('err', $fail)->assign('gets',$gets);