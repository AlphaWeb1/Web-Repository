<?php

$notifications=new stdClass();
// Do Update All Marked as read 
// Do Update Single Marked as read

$gets=(object) $Site['get'];
	// error_log(json_encode($gets));
if( !empty($gets->ticket) and !empty($gets->evt) and $gets->evt=='read' and !empty($ezDb->get_var("SELECT `token` FROM `temp_booking` WHERE `token`='$gets->ticket' AND `status`='1'")) ){
	error_log("message");
	$ezDb->query("UPDATE `temp_booking` SET `status`='2' WHERE `token`='$gets->ticket' AND `status`='1'");
	$fail='<div class="alert alert-success alert-dismissible" role="alert" style="position: absolute; z-index: 1100; vertical-align: middle; align-self: center; width: 70% !important; top: 140px; margin-left: 15%;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Messages</h3> <p>Ticket status had been successfully updated!</p></div>';
}

$notifications->bookings=$ezDb->get_results("SELECT `b`.`id`, `b`.`client`, `b`.`bookedBy`, `b`.`bookingtoken`, `b`.`ticketNo`, `b`.`bookingInfo`, `b`.`bookingDate`, `b`.`billingId`, `b`.`noOfPerson`, `b`.`totalFee`,
 `tb`.`token`, `tb`.`ipaddress`, `tb`.`user`, `tb`.`search`,  `tb`.`vehicle`,  `tb`.`userdata`, `tb`.`dateadded`, `tb`.`status` FROM `temp_booking` AS `tb`, `booking` AS `b` WHERE `tb`.`token`=`b`.`bookingtoken` AND `tb`.`status`='1';");
if (!empty($notifications->bookings)) {
	foreach ($notifications->bookings as $key=> $value) {
		$notifications->bookings[$key]->bookingInfo=json_decode($notifications->bookings[$key]->bookingInfo);
		$notifications->bookings[$key]->search=json_decode($notifications->bookings[$key]->search);
		$notifications->bookings[$key]->vehicle=json_decode($notifications->bookings[$key]->vehicle);
		$notifications->bookings[$key]->userdata=json_decode($notifications->bookings[$key]->userdata);
	}
}

$smarty->assign('notifications', $notifications)->assign("err",$fail);