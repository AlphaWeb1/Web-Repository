<?php

if(!in_array($Site["session"]["User"]["userinfo"]->userrole, array("level0","level1"))):
	redirect("./my-account/transactions");
endif;

$vehicles->today['TotalSchedules']=$ezDb->get_var("SELECT IFNULL(COUNT(`token`),'0') FROM `tripschedules1` WHERE DATEDIFF('$dateNow', `departure`)=0 ");
$vehicles->today['TotalSchedulesReserved']=$ezDb->get_var("SELECT IFNULL(COUNT(`token`),'0') FROM `tripschedules1` WHERE DATEDIFF('$dateNow', `departure`)=0 AND `chosenseats`!=''");
$vehicles->today['TotalSchedulesUnReserved']=$ezDb->get_var("SELECT IFNULL(COUNT(`token`),'0')  FROM `tripschedules1` WHERE DATEDIFF('$dateNow', `departure`)=0 AND (`chosenseats`='' OR `chosenseats` IS NULL)");

$vehicles->today['TotalVehicleSchedules']=$ezDb->get_results("SELECT IFNULL(COUNT(`token`),'0') AS `tripcount`, `vehicleid`  FROM `tripschedules1` WHERE DATEDIFF('$dateNow', `departure`)=0 GROUP BY `vehicleid`");
$vehicles->today['TotalVehicleReserved']=$ezDb->get_results("SELECT IFNULL(COUNT(`token`),'0') AS `tripcount`, `vehicleid`  FROM `tripschedules1` WHERE DATEDIFF('$dateNow', `departure`)=0 AND `chosenseats`!='' GROUP BY `vehicleid`");
$vehicles->today['TotalVehicleUnReserved']=$ezDb->get_results("SELECT IFNULL(COUNT(`token`),'0') AS `tripcount`, `vehicleid`  FROM `tripschedules1` WHERE DATEDIFF('$dateNow', `departure`)=0 AND (`chosenseats`='' OR `chosenseats` IS NULL)  GROUP BY `vehicleid`");

$vehicles->thisweek['TotalSchedules']=$ezDb->get_var("SELECT IFNULL(COUNT(`token`),'0') FROM `tripschedules1` WHERE TIMESTAMPDIFF(WEEK, '$dateNow', `departure`)=0");
$vehicles->thisweek['TotalSchedulesReserved']=$ezDb->get_var("SELECT IFNULL(COUNT(`token`),'0') FROM `tripschedules1` WHERE TIMESTAMPDIFF(WEEK, '$dateNow', `departure`)=0 AND `chosenseats`!=''");
$vehicles->thisweek['TotalSchedulesUnReserved']=$ezDb->get_var("SELECT IFNULL(COUNT(`token`),'0')  FROM `tripschedules1` WHERE TIMESTAMPDIFF(WEEK, '$dateNow', `departure`)=0 AND (`chosenseats`='' OR `chosenseats` IS NULL)");

$vehicles->thisweek['TotalVehicleSchedules']=$ezDb->get_results("SELECT IFNULL(COUNT(`token`),'0') AS `tripcount`, `vehicleid`  FROM `tripschedules1` WHERE TIMESTAMPDIFF(WEEK, '$dateNow', `departure`)=0 GROUP BY `vehicleid`");
$vehicles->thisweek['TotalVehicleReserved']=$ezDb->get_results("SELECT IFNULL(COUNT(`token`),'0') AS `tripcount`, `vehicleid`  FROM `tripschedules1` WHERE TIMESTAMPDIFF(WEEK, '$dateNow', `departure`)=0 AND `chosenseats`!='' GROUP BY `vehicleid`");
$vehicles->thisweek['TotalVehicleUnReserved']=$ezDb->get_results("SELECT IFNULL(COUNT(`token`),'0') AS `tripcount`, `vehicleid`  FROM `tripschedules1` WHERE TIMESTAMPDIFF(WEEK, '$dateNow', `departure`)=0 AND (`chosenseats`='' OR `chosenseats` IS NULL) GROUP BY `vehicleid`");

$vehicles->thismonth['TotalSchedules']=$ezDb->get_var("SELECT IFNULL(COUNT(`token`),'0') FROM `tripschedules1` WHERE TIMESTAMPDIFF(MONTH, '$dateNow', `departure`)=0 ");
$vehicles->thismonth['TotalSchedulesReserved']=$ezDb->get_var("SELECT IFNULL(COUNT(`token`),'0') FROM `tripschedules1` WHERE TIMESTAMPDIFF(MONTH, '$dateNow', `departure`)=0 AND `chosenseats`!=''");
$vehicles->thismonth['TotalSchedulesUnReserved']=$ezDb->get_var("SELECT IFNULL(COUNT(`token`),'0')  FROM `tripschedules1` WHERE TIMESTAMPDIFF(MONTH, '$dateNow', `departure`)=0 AND (`chosenseats`='' OR `chosenseats` IS NULL)");

$vehicles->thismonth['TotalVehicleSchedules']=$ezDb->get_results("SELECT IFNULL(COUNT(`token`),'0') AS `tripcount`, `vehicleid`  FROM `tripschedules1` WHERE TIMESTAMPDIFF(MONTH, '$dateNow', `departure`)=0 GROUP BY `vehicleid`");
$vehicles->thismonth['TotalVehicleReserved']=$ezDb->get_results("SELECT IFNULL(COUNT(`token`),'0') AS `tripcount`, `vehicleid`  FROM `tripschedules1` WHERE TIMESTAMPDIFF(MONTH, '$dateNow', `departure`)=0 AND `chosenseats`!='' GROUP BY `vehicleid`");
$vehicles->thismonth['TotalVehicleUnReserved']=$ezDb->get_results("SELECT IFNULL(COUNT(`token`),'0') AS `tripcount`, `vehicleid`  FROM `tripschedules1` WHERE TIMESTAMPDIFF(MONTH, '$dateNow', `departure`)=0 AND (`chosenseats`='' OR `chosenseats` IS NULL) GROUP BY `vehicleid`");


$smarty->assign('vehicles', $vehicles);