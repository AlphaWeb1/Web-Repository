<?php

// if(!empty($posts->triggers) and $posts->triggers=='search'){

// }

$manifests=$ezDb->get_results("SELECT *, IF( DATEDIFF('$dateNow', `return`)=0, true, false ) AS `returnSt`, IF( DATEDIFF('$dateNow', `departure`)=0, true, false ) AS `departureSt` FROM `tripschedules` WHERE (DATEDIFF('$dateNow', `return`)=0 OR DATEDIFF('$dateNow', `departure`)=0) AND (`chosenSeats` !='' OR `chosenSeats1`!='') ORDER BY `datemodified` DESC;");
// error_log("SELECT *, IF( TIMESTAMPDIFF(DAY, '$dateNow', `return`)=0, true, false ) AS `returnSt`, IF( TIMESTAMPDIFF(DAY, '$dateNow', `departure`)=0, true, false ) AS `departureSt` FROM `tripschedules` WHERE (TIMESTAMPDIFF(DAY, '$dateNow', `return`)=0 OR TIMESTAMPDIFF(DAY, '$dateNow', `departure`)=0) AND (`chosenSeats` !='' OR `chosenSeats1`!='') ORDER BY `datemodified` DESC;");
/*Get the content below form jqueryajax out*/
if(! empty($manifests)){
	foreach($manifests as $manifest){
		$manifest->bookedLists=$ezDb->get_results("SELECT `bk`.`bookinginfo`, `bk`.`bookingDate`, `bk`.`ticketNo`, `bk`.`client`, `bk`.`bookedBy`, `bk`.`noOfPerson`, `bk`.`totalFee`, `tb`.`search`, `tb`.`vehicle`, `tb`.`userdata`, `tb`.`ipaddress`, `tb`.`dateadded`, `tb`.`status`  FROM `booking` AS `bk`, `temp_booking` AS `tb` WHERE `bk`.`bookingtoken`=`tb`.`token` AND (`tb`.`status`='1' OR `tb`.`status`='2') AND `tb`.`vehicle` LIKE '%\"$manifest->token\"%'");
		$manifest->totalTickets=0;
		$manifest->sumTotal=0.00;
		if(!empty($manifest->bookedLists )){
			foreach ($manifest->bookedLists as  $mbl) {
				$ttT=json_decode($mbl->vehicle);
				$ttS=json_decode($mbl->search);
				// Fix Calc

				$manifest->totalTickets+=count($ttT->seats);
					$manifest->sumTotal+=($mbl->totalFee);
				// if($mbl->vehicle->returnDate==$manifest->return and $manifest->returnSt==true){
				// 	$manifest->totalTickets+=count($ttT->seats);
				// 	$manifest->sumTotal+=($mbl->totalFee/2);
				// 	error_log('message');
				// }elseif($mbl->vehicle->departureDate==$manifest->departure and $manifest->departureSt==true){
				// 	$manifest->totalTickets+=count($ttT->seats);
				// 	if($ttS->tripType=='Round Trip'){
				// 		$manifest->sumTotal+=($mbl->totalFee/2);
				// 	}else{
				// 		$manifest->sumTotal+=$mbl->totalFee;
				// 	}
				// 	error_log('message1');
				// }else{
				// 	error_log('message2');
				// }
			}
		}
		$manifest->drivernVehicleDetails=$ezDb->get_row("SELECT DISTINCT `title`, `firstname`, `middlename`, `lastname`, `phone`, `email`, `username`, `model`, `plateno`, `capacity`, `type` FROM `userprofile`, `vehicles` WHERE `userprofile`.`username`=`vehicles`.`driversid` AND `vehicleid`='$manifest->vehicleid'");
		$manifest->bookedSeat=count(json_decode(($manifest->returnSt==true?$manifest->chosenSeats1:$manifest->chosenSeats)));
		$manifest->vacantSeat= $manifest->capacity - $manifest->bookedSeat;
	}
}
$smarty->assign('manifests', $manifests);