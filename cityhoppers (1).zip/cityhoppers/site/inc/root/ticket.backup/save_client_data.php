<?php global $smarty;


if( !empty(bookinTokenExists($sessions->tempToken)) and !empty($tempBookings->search) and !empty($tempBookings->vehicle) ){

	$userData=new stdClass();
	if ($posts->triggers=='saveUserData') {
		$extensions = array("image/jpg","image/png","image/jpe","image/jpeg","image/tiff","image/webp","image/jp2");
		$targetDir = 'site/media/userdata/paymentproof/';
		for($x=0; $x<$tempBookings->search->passenger; $x++):
			if( empty($posts->firstName[$x]) or is_numeric($posts->firstName[$x]) ):
				$err++;
				$fail.='<p>Kindly enter your first name of passenger </p>';
			endif;
			if( empty($posts->lastName[$x]) or is_numeric($posts->lastName[$x]) ):
				$err++;
				$fail.='<p>Kindly enter your last name</p>';
			endif;
			if( empty($posts->gender[$x]) or !in_array($posts->gender[$x], array("female","male")) ):
				$err++;
				$fail.='<p>Kindly select your gender</p>';
			endif;
			if( empty($posts->phoneNo[$x]) ):
				$err++;
				$fail.='<p>Kindly enter a valid phone number</p>';
			endif;
			if( empty($posts->email[$x]) or !checkEmail($posts->email[$x]) ):
				$err++;
				$fail.='<p>Kindly enter a valid email</p>';
			endif;
			if( empty($posts->nokName[$x]) or is_numeric($posts->nokName[$x]) ):
				$err++;
				$fail.='<p>Kindly enter a valid name for Next of Kin</p>';
			endif;
			if( empty($posts->phoneNo[$x]) ):
				$err++;
				$fail.='<p>Kindly enter a valid phone number for Next of Kin</p>';
			endif;
		endfor;
		if( empty($posts->posTrans) ):
			$err++;
			$fail.='<p>Kindly select a valid payment method</p>';
		else:
			$posts->payment='pos';
		endif;
		if(!in_array($posts->uploadOption, array("uploadPhoto", "takePhoto"))):
			$fail .= '<p>Select a valid receipt upload option allowed.</p>';
	        $err++;
		endif;
		if (!in_array(strtolower(getMime($_FILES['pProof']['tmp_name'])), $extensions)):
	    	$fail .= '<p>Kindly scan and upload POS payment receipt</p><p>This is not an image file. Only JPG, JPEG, PNG, JPE, WEBP, or JP2 file is allowed.</p>';
	        $err++;
	    endif;
		// if(){
			
		// }

		if($err==0):
		// error_log("0");
			if (!file_exists("$targetDir")):
		        mkdir("$targetDir", 0777, true);
		    endif;
			unset($posts->triggers);
			// error_log(json_encode());
    		$newName = $tempBookings->token.'_.png';
    		$targetFile = $targetDir . $newName;
		    if (move_uploaded_file($_FILES["pProof"]["tmp_name"], $targetFile)):
		    	$userData=$posts;
				$userData->unitfee= $tempBookings->vehicle->unitfee;
				$userData->quantity= $tempBookings->search->passenger;
				$userData->total=$tempBookings->vehicle->grandTotal;
				$userData->paidBy=$user;
				$tempBookings->userdata=$userData;
				$tranx=new stdClass;
				$tranx->status=true;
				$tranx->message="Admin Ticket Booking";
				$tranx->data=(object) array("url"=>"https://cityhoppers.com.ng/root/ticket","reference"=>"pos_$posts->posTrans", "status"=>"success");
				// error_log(json_encode($tempBookings->userdata));
				// {"status":true,"message":"Authorization URL created","data":{"authorization_url":"https://checkout.paystack.com/tujg18hdsj5erjq","access_code":"tujg18hdsj5erjq","reference":"ukvxngeyei"}}
				$ezDb->query("UPDATE `temp_booking` SET `userdata`='".json_encode($userData)."' WHERE `token`='$sessions->tempToken';");
				// $ezDb->query("INSERT INTO `paystack_hits` (`data_intransit`,`token`,``) VALUES ('".json_encode($tranx)."','$sessions->tempToken');");


	            $clientUn=$tempBookings->userdata->email[0];

	            $ezDb->query("UPDATE `temp_booking` SET `status`=true, `user`='$clientUn' WHERE `token`='$sessions->tempToken';");
	            do{
	              $token=getToken(10);
	            }while($ezDb->get_var("SELECT `ticketNo` FROM `booking` WHERE `ticketNo`='$sessions->tempToken';"));
	            $bookingInfo=new stdClass();
	            $bookingInfo->vehicleDetails=$tempBookings->vehicle;
	            $bookingInfo->userdata=$tempBookings->userdata;
	            $bookingInfo->dateAdded=$tempBookings->dateadded;
	            $bookingInfo->ipaddress=$tempBookings->ipaddress;
	            $bookingInfo->bookedBy=$user;
	            $bookingInfo->status=1;
	            // Add the discount to bookingInfo

	            // Log Booking
	            $ezDb->query("INSERT INTO `booking` (`client`, `bookedBy`, `bookingtoken`, `ticketNo`, `bookingInfo`, `bookingDate`, `noOfPerson`, `totalFee`) VALUES ('$clientUn', 'admin', '". $tempBookings->token."', '$token', '".json_encode($bookingInfo)."', '$dateNow','".$tempBookings->search->passenger."', '".$tempBookings->userdata->total."');");

	            // log Payment
	            $tempBookings->bookingID=$token;
	            $ezDb->query("INSERT INTO `payment` (`transid`, `ticketid`, `amount`, `transdate`, `paymenttype`, `paidby`, `paymentstatus`) VALUES ('".$tranx->data->reference."','$token','".$tempBookings->userdata->total."','$dateNow','".$tempBookings->userdata->payment."','$user','".($tranx->data->status=='success'?'1':'0')."');");
	            $bookings=$ezDb->get_row("SELECT * FROM `booking` WHERE `bookingtoken`='$sessions->tempToken';");

	            for( $i=0; $i< count($tempBookings->userdata->email); $i++ ):
	              $divElements=setDivElement($bookings, $tempBookings, $i);
	              require_once 'send_mail_to_clients.php';
	            endfor;

				$smarty->assign("Bstatus"."success");
				unset($Site["session"]['tempToken']);
		        $_SESSION=$Site["session"];
		        $sessions= (object)$Site["session"];
				$fail='<div class="alert alert-success alert-dismissible" role="alert" style="position: absolute; z-index: 9999; vertical-align: middle; align-self: center; width: 70% !important; top: 140px; margin-left: 15%;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Success!</h3> <p>Ticket had been successfully booked check the ticket list</p></div>';
				$smarty->assign('tranx',$tranx)->assign('bookings',$bookings);
		    else:
		    	$fail='<div class="alert alert-success alert-dismissible" role="alert" style="position: absolute; z-index: 9999; vertical-align: middle; align-self: center; width: 70% !important; top: 140px; margin-left: 15%;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><p> An error has occured: unable to upload proof.</p></div>';
		    endif;		
		else:
			$fail='<div class="alert alert-danger alert-dismissible" role="alert" style="position: absolute; z-index: 9999; vertical-align: middle; align-self: center; width: 70% !important; top: 140px; margin-left: 15%;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Error Messages</h3> '.$fail.'</div>';
		endif;
		$smarty->assign('fail',$fail);
		// error_log($fail);
	}
}

