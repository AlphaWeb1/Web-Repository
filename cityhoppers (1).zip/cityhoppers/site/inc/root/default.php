<?php

$defaults=new stdClass();
// error_log("schid".date("Ymdhis").round(microtime(true)).getToken(2));
optimizeTempBookings();
// error_log("SELECT `search`, `vehicle` FROM `temp_booking` WHERE `status`='0' AND DATEDIFF('$dateNow',`dateadded`)>1");
// $ezDb->query("DELETE FROM `temp_booking` WHERE ((``) OR ()) AND `status`='0' AND `vehicle`=''");

$defaults->not['booking']=$ezDb->get_var("SELECT COUNT(`id`) FROM `temp_booking1`  WHERE `status`='1';");
$defaults->not['rentals']=$ezDb->get_var("SELECT COUNT(`id`) FROM `hiring`  WHERE `responsestatus`='0';");

$chartStats=new stdClass;
// Incomes
$chartStats->incomeRate['manual']=$ezDb->get_var("SELECT SUM(`amount`) FROM `payment1` WHERE `paymentstatus`='1' AND `paymenttype`='pos'");
$chartStats->incomeRate['online']=$ezDb->get_var("SELECT SUM(`amount`) FROM `payment1` WHERE `paymentstatus`='1' AND `paymenttype`!='pos'");
$chartStats->incomeRate['all']=$ezDb->get_var("SELECT SUM(`amount`) FROM `payment1` WHERE `paymentstatus`='1'");

$chartStats->incomeRate['thismonth']=$ezDb->get_var("SELECT SUM(`amount`) FROM `payment1` WHERE `paymentstatus`='1' AND ABS(MONTH('$dateNow')-MONTH(`transdate`))=0;");
$chartStats->incomeRate['lastmonth']=$ezDb->get_var("SELECT SUM(`amount`) FROM `payment1` WHERE `paymentstatus`='1' AND ABS(MONTH('$dateNow')-MONTH(`transdate`))=1;");
$chartStats->incomeRate['twomonths']=$ezDb->get_var("SELECT SUM(`amount`) FROM `payment1` WHERE `paymentstatus`='1' AND ABS(MONTH('$dateNow')-MONTH(`transdate`))=2;");
$chartStats->incomeRate['threemonths']=$ezDb->get_var("SELECT SUM(`amount`) FROM `payment1` WHERE `paymentstatus`='1' AND ABS(MONTH('$dateNow')-MONTH(`transdate`))=3;");
$chartStats->incomeRate['fourmonth']=$ezDb->get_var("SELECT SUM(`amount`) FROM `payment1` WHERE `paymentstatus`='1' AND ABS(MONTH('$dateNow')-MONTH(`transdate`))=4;");
$chartStats->incomeRate['fivemonth']=$ezDb->get_var("SELECT SUM(`amount`) FROM `payment1` WHERE `paymentstatus`='1' AND ABS(MONTH('$dateNow')-MONTH(`transdate`))=5;");

$chartStats->dailyIncome['today']=$ezDb->get_var("SELECT SUM(`amount`) FROM `payment1` WHERE `paymentstatus`='1' AND DATEDIFF('$dateNow', `transdate`)=0;");
$chartStats->dailyIncome['yesterday']=$ezDb->get_var("SELECT SUM(`amount`) FROM `payment1` WHERE `paymentstatus`='1' AND DATEDIFF('$dateNow', `transdate`)=1;");
$chartStats->dailyIncome['twodays']=$ezDb->get_var("SELECT SUM(`amount`) FROM `payment1` WHERE `paymentstatus`='1' AND DATEDIFF('$dateNow', `transdate`)=2;");
$chartStats->dailyIncome['threedays']=$ezDb->get_var("SELECT SUM(`amount`) FROM `payment1` WHERE `paymentstatus`='1' AND DATEDIFF('$dateNow', `transdate`)=3;");
$chartStats->dailyIncome['fourdays']=$ezDb->get_var("SELECT SUM(`amount`) FROM `payment1` WHERE `paymentstatus`='1' AND DATEDIFF('$dateNow', `transdate`)=4;");
$chartStats->dailyIncome['fivedays']=$ezDb->get_var("SELECT SUM(`amount`) FROM `payment1` WHERE `paymentstatus`='1' AND DATEDIFF('$dateNow', `transdate`)=5;");

$chartStats->incomeRate['thismonth']=empty($chartStats->incomeRate['thismonth'])?'0':$chartStats->incomeRate['thismonth'];
$chartStats->incomeRate['lastmonth']=empty($chartStats->incomeRate['lastmonth'])?'0':$chartStats->incomeRate['lastmonth'];
$chartStats->incomeRate['twomonths']=empty($chartStats->incomeRate['twomonths'])?'0':$chartStats->incomeRate['twomonths'];
$chartStats->incomeRate['threemonths']=empty($chartStats->incomeRate['threemonths'])?'0':$chartStats->incomeRate['threemonths'];
$chartStats->incomeRate['fourmonth']=empty($chartStats->incomeRate['fourmonth'])?'0':$chartStats->incomeRate['fourmonth'];
$chartStats->incomeRate['fivemonth']=empty($chartStats->incomeRate['fivemonth'])?'0':$chartStats->incomeRate['fivemonth'];

$chartStats->dailyIncome['today']=empty($chartStats->dailyIncome['today'])?'0':$chartStats->dailyIncome['today'];
$chartStats->dailyIncome['yesterday']=empty($chartStats->dailyIncome['yesterday'])?'0':$chartStats->dailyIncome['yesterday'];
$chartStats->dailyIncome['twodays']=empty($chartStats->dailyIncome['twodays'])?'0':$chartStats->dailyIncome['twodays'];
$chartStats->dailyIncome['threedays']=empty($chartStats->dailyIncome['threedays'])?'0':$chartStats->dailyIncome['threedays'];
$chartStats->dailyIncome['fourdays']=empty($chartStats->dailyIncome['fourdays'])?'0':$chartStats->dailyIncome['fourdays'];
$chartStats->dailyIncome['fivedays']=empty($chartStats->dailyIncome['fivedays'])?'0':$chartStats->dailyIncome['fivedays'];

$chartStats->incomeTotal=$ezDb->get_var("SELECT SUM(`amount`) FROM `payment1`");
// Vehicles
$chartStats->vehicles=$ezDb->get_results("SELECT * FROM `vehicles`;");
foreach ($chartStats->vehicles as $key => $value) {
	$chartStats->vehicles[$key]->engagement=$ezDb->get_var("SELECT COUNT(`token`) FROM `tripschedules1` WHERE `vehicleid`='$value->vehicleid';");
}

$settings=getSettings();

$chartStats->tripType['roundtrip']=$ezDb->get_var("SELECT COUNT(`token`) FROM `tripschedules1` WHERE `destination`='".$settings->schedule->source."';");
$chartStats->tripType['oneway']=$ezDb->get_var("SELECT COUNT(`token`) FROM `tripschedules1` WHERE `source`='".$settings->schedule->source."';");

// $chartStats->incomeRate['twoyearback']=$ezDb->get_var("SELECT SUM(`amount`) FROM `payment` WHERE `paymentstatus`='1' AND TIMESTAMPDIFF(YEAR,`transdate`,'$dateNow')=2;");

// check nd run schedule routine here

$smarty->assign('defaults', $defaults)->assign('chartStats', $chartStats);