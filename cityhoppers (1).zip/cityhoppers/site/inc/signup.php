<?php

if (!empty($Site['get']['email'])) {
	$smarty->assign('email', $Site['get']['email']);
}

if(!empty($posts->signup) and $posts->signup=='signup' and $sitePage=='signup'):

	if( empty($posts->firstname) ):
		$fail.='<p>Invalid First Name: first name is not entered</p>';
		$err++;
	endif;
	if( empty($posts->lastname) ):
		$fail.='<p>Invalid Last Name: last name is not entered</p>';
		$err++;
	endif;
	if( empty($posts->terms) or $posts->terms!='1'):
		$fail.='<p>Terms Is Required: you have to agree with website operative terms & policy</p>';
		$err++;
	endif;
	if( $posts->getlatest!="1" ):
		$posts->getlatest="0";
	endif;
	if( empty($posts->email) or !checkEmail($posts->email)):
		$fail.='<p>Invalid Email: not a valid email</p>';
		$err++;
	endif;
	if( !empty($posts->email) and strpos(strtolower($posts->email), 'dollartouch.com.ng')>-1):
		$fail.='<p>Invalid Email: this kind of email is not allowed</p>';
		$err++;
	endif;
	if( !empty($posts->email) and !empty($ezDb->get_var("SELECT `email` FROM `userprofile` WHERE `email`='".strtolower(trim($posts->email))."';"))):
		$fail.='<p>Invalid Email: there is an account with this email, kindly reqest for a password reset if you owns the email</p>';
		$err++;
	endif;
	if( empty($posts->password) ):
		$fail.='<p>Invalid Password: empty password is not allowed</p>';
		$err++;
	endif;
	//$specialChars = preg_match('@[^\w]@', $password);
	if( !empty($posts->password) and ( strlen($posts->password) < 8 or !preg_match('@[A-Z]@', $posts->password)  or !preg_match('@[0-9]@', $posts->password) or !preg_match('@[a-z]@',$posts->password) ) ):
		$fail.='<p>Invalid Password: password should be at least 8 characters in length and should include at least one upper case letter, one number</p>';
		$err++;
	endif;

	if( !empty($posts->phone) and checkPhone($posts->phone)!==true):
		$fail.='<p>Invalid Phone Number: not a valid phone</p>';
		$err++;
	endif;
	if($err==0):
		$tokened="client".date("YmdHis").getToken('2').$ezDb->get_var("SELECT IF(`id`=NULL,'1',(`id`+1)) FROM `userprofile` WHERE `usertype`='client' ORDER BY `id` DESC LIMIT 1;");
		$ezDb->query("INSERT INTO `userprofile` (`email`, `firstname`, `lastname`, `password`, `username`, `phone`, `terms`, `active`, `dateadded`, `usertype`, `userrole`, `verified`) VALUES ('".strtolower($posts->email)."', '$posts->firstname', '$posts->lastname', '".base64_encode($posts->password)."', '".strtolower($tokened)."', '$posts->phone', '$posts->terms', '1', '$dateNow', 'client', 'level1', '0');");

		$confirmkey=date("YmdHis").getToken('5').$ezDb->get_var("SELECT IF(`id`=NULL,'1',(`id`+1)) FROM `keys` ORDER BY `id` DESC LIMIT 1;");
		$ezDb->query("INSERT INTO `keys` (`email`, `key`, `expiredon`) VALUES ('".strtolower($posts->email)."', '$confirmkey', DATE_ADD('$dateNow', INTERVAL 2 DAY))");
		require_once 'mail_signup.php';
		$fail='<div class="alert alert-primary alert-dismissible" role="alert">
					 <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h3>Messages</h3><p>Your Cityhoppers account was successfully created, and a verification link had been sent to your email</p>
					<p>Kindly visit your email to verify OR Click on <a href="'.$Site['siteProtocol'].$Site['domainName']."/resend?e=$posts->email".'" class=" btn-link">Resend</a> if you are not receiving any confirmation link</p>
				</div>';
	else:
		$fail='<div class="alert alert-danger text-justify">
					<i class="fa fa-warning"></i> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h3>Error Messages</h3><div class="alert alert-danger alert-dismissible" role="alert"> '.$fail.'</div>
				</div>';
	endif;
	// error_log($fail);
endif;