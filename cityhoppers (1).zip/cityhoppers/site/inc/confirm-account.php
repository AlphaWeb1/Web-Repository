<?php global $sitePage, $smarty, $ezDb, $requestMethod, $Site, $siteName, $domainName;

$newPass=null; $confPass=null;
$key=useIfSent('k');
$err=0;
$fail='';
$now=date("Y-m-d H:i:s");
$posteds=new stdClass();
if( empty($key) or empty($ezDb->get_var("SELECT `email` FROM `".$siteName."_users` WHERE `token`='$key' AND `token`!='' AND `verified`=false")) ):
	redirect("home");
elseif( $detail =$ezDb->get_row("SELECT `userType`,`username`,`email`, TIMESTAMPDIFF(SECOND, `regDate`, '$now') AS `keyage` FROM `".$siteName."_users` WHERE `token`='$key' AND `verified`=false ") ):
	if ($detail->keyage > 48*60*60):
		$fail.='<p>The link you request for has expired. Contact Administrator</p>'
		.'<p>Click &quot;<strong>Cancel Account</strong>&quot; to destroy your account OR &quot;<strong>Request New Link</strong>&quot; to get new confirmation link <br/> <a class="btn btn-danger" href="'."$siteProtocol$domainName/confirm-account?k=$key&e=cancel".'">Cancel Account</a> <a class="btn btn-dark" href="'."$siteProtocol$domainName/confirm-account?k=$key&e=renew".'">Request New Link</a></p>';
		$key=null;
		$err++;
		/*Do something big*/
		$evt=useIfSent("e");
		if( !empty($evt) and $evt=="cancel" ):
			$ezDb->query("DELETE FROM `".$siteName."_userprofile` WHERE `username`='$detail->username'");
			$ezDb->query("UPDATE `".$siteName."_users` SET `username`='', `password`='', `userType`='', `token`='', `terms`=false, `verified`=false  WHERE `username`='$detail->username'");
			$fail='<div class="alert alert-info alert-dismissible" role="alert"><p>Your request to cancel account is successfull! you can return to signup to start all over.</p></div>';
			$err=0;
		elseif( !empty($evt) and $evt=="renew" ):
			do {
				$regToken = getToken(50);
			} while ($regToken == $ezDb->get_var("SELECT `token` FROM `".$siteName."_users` WHERE `token`='$regToken'"));
			$ezDb->query("UPDATE `".$siteName."_users` SET `token`='$regToken', `regDate`='$now' WHERE `username`='$detail->username'");
			$eol = "\r\n";
			$theSitePath = $siteProtocol."$domainName";
			$theLink = "$theSitePath/confirm-account?k=$regToken";
			$theMessage="Dear LawCon Subscriber\n\nYou recently request for a new confirmation link to your account!\n\n\n\tEmail: ".base64_decode($detail->email)."\n\n\tUsername: ".base64_decode($detail->username)."\n\n\nKindy visit the link below to activate your account.\n\n$theLink\n\nThank You,\n\n\n" . ucfirst($domainName) . " Signup Confirmation Request.".PHP_EOL;
			$theSubject = "Signup confirmation request from signup@$domainName";

			$headers = "From: <signup@$domainName>" . $eol;
			$headers .= "Organization: LawCon Legal Platform " . $eol;
			$headers .= "MIME-Version: 1.0" . $eol;
			$headers .= "Content-Transfer-Encoding: 7bit" . $eol;
			if (mail(base64_decode($detail->email), $theSubject, $theMessage, $headers)) :
				$fail='<div class="alert alert-info alert-dismissible" role="alert"><p>Your confirmation link had been renewed and resent to your mail which will expire in the next 48hrs.<br/> Kindly visit your mail to verify your confirmation link before the expiration time.</p></div>';
			else:
				$fail='<div class="alert alert-warning alert-dismissible" role="alert"><p>Your confirmation link had been renewed. <br/>The system is unable to send a confirmation link due to mail server error. Ensure that you contact our support with detail of ownership so that it can be verified for you to be able to operateon your account.</p></div>';
			endif;
			$err=0;
		endif;
		$smarty->assign("expr","expired");
	else:
		if ( in_array($sitePage, array("confirm-account")) and ($requestMethod == 'POST') ) :
			$posteds=(object)$Site['post'];
			$posteds->dataEmail=strtolower($posteds->dataEmail);
			if( empty(trim($posteds->dataEmail)) or !checkEmail($posteds->dataEmail) ):
				$err++;
				$fail.='<p>Email field cannot be empty</p>';
			endif;
			if( base64_encode($posteds->dataEmail)!=$detail->email):
				$err++;
				$fail.='<p>Invalid Email: The entered email doest not match confirmation path check your mail box for  the right path!</p>';
			endif;
			if( $err ==0 ):
				$ezDb->query("INSERT INTO `".$siteName."_accounts` (`user`) VALUES('$detail->username')");
				$ezDb->query("UPDATE `".$siteName."_users` SET `token`='', `verified`=true, `active`=".($detail->userType=='lawyer'?'false':'true')." WHERE `username`='$detail->username'");
				$fail.=' <p>Your confirmation request is now successfull proceed to login from the link below:<br/><a href="'.$siteProtocol."$domainName/".($detail->userType=='lawyer'?'lawyer':'login').'" class="btn btn-primary btn-xs">Proceed to Login</a></p>';
				$fail='<div class="alert alert-success alert-dismissible" role="alert"> '.$fail.'</div>';
				$smarty->assign("expr","expired");
			endif;
		endif;
	endif;

endif;

if( $err >0 ):
	$fail='<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button> '.$fail.'</div>';
endif;

$smarty->assign("fail", $fail)->assign("posteds", $posteds);