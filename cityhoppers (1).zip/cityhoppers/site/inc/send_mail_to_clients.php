<?php

require_once "Mail.php"; // PEAR Mail package
require_once ('Mail/mime.php'); // PEAR Mail_Mime packge


$from = "info@cityhoppers.com.ng"; //enter your email address
// $to = "info@".$domainName; //enter the email address of the contact your sending to
$to = $tempBookings->userdata->email[$i]; //enter the email address of the contact your sending to
$subject = $posteds->subject; // subject of your email

$headers = array ('From' => $from,'To' => $to, 'Subject' => $subject);

$text = "Sender : Booking@City Hopper\n\nMessage: ".$themessage.PHP_EOL; // text versions of email.
$html = '<html>
	      <head>
	      	<title>Ticket Booking</title>
	      	<link rel="stylesheet" href="http://cityhoppers.com.ng/lib/common/bootstrap/css/bootstrap.min.css" />
			<link rel="stylesheet" href="http://cityhoppers.com.ng/lib/common/font-awesome/css/font-awesome.min.css">
			<link rel="stylesheet" href="http://cityhoppers.com.ng/lib/common/css/style.css" type="text/css" />
			<style>
			/*Invoicing Styles*/
			.card#printMe{
				margin-top: 150px !important;
			}
			.card#printMe .card-header{
				background: #58468c !important;
				color: #fff !important;
			}
			.card#printMe .card-body .table-responsive .table tr th{
				background: #58468c !important;
			    color: #fff !important;
			    text-align: justify !important;
			    font-size: 11px;
    			word-wrap: break-word;
			}
			</style>
	      </head>
      	  <body>
      	  	'.$divElements.'
			<script src="http://cityhoppers.com.ng/lib/common/js/jquery-3.3.1.js"></script>
			<script src="http://cityhoppers.com.ng/lib/common/bootstrap/js/bootstrap.min.js"></script>
			<script src="http://cityhoppers.com.ng/lib/common/js/script.js"></script>
      	  </body>
      </html>'; // html versions of email.

$crlf = "\n";

$mime = new Mail_mime($crlf);
$mime->setTXTBody($text);
$mime->setHTMLBody($html);

//do not ever try to call these lines in reverse order
$body = $mime->get();
$headers = $mime->headers($headers);
$host = "localhost"; // all scripts must use localhost
$username = "info@cityhoppers.com.ng"; //  your email address (same as webmail username)
// $username = "info@".$domainName; //  your email address (same as webmail username)
$password = "__nE5x6%2^}B"; // your password (same as webmail password)

$smtp = Mail::factory('smtp', array ('host' => $host, 'auth' => true,
'username' => $username,'password' => $password));

$mail = $smtp->send($to, $headers, $body);

if (PEAR::isError($mail)) :

$fail.='<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Error 601:</h3> <p>Unable to connect to send message</p></div>';
else:
// $fail.='<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button> <p>Your message had been successfully sent.<br/>Thanks!</p></div>';
endif;