<?php global $sitePage;

$err=0;
$fail='';
$posteds=new stdClass();

if ( empty($Site["session"]['Site']["User"]) ) {
	if ( $requestMethod == 'POST' ) :
		$posteds =(object) $Site['post'];
		if ( !empty($posteds->newsletter) ):
			if ( empty($posteds->email) or !checkEmail($posteds->email) ):
				$err++;
				$fail .= '<p>Kindly enter a valid email!<p>';
			endif;

			if($err==0):

			    $eol = "\r\n";
				$theSitePath = $siteProtocol.$domainName;
				$theMessage= "<h3>Kin Royal</h3><br/><br/>Your subscription request for our daily newsletter had been successfully confirmed.<br/><br/>If you this request appears to be off your awareness, kindly click on the link below unsubscribe.<br/><br/><a href='$theSitePath/unsubscribe?sec=nl' target='__blank'>Unscubscribe</a>.<br/><br/>Thanks!".PHP_EOL;
				$theSubject = "Newsletter subscription from info@$domainName";
				error_log($theMessage);
				$posteds->email=strtolower($posteds->email);
				$mailExists=$ezDb->get_var("SELECT `email` FROM `".$siteName."_users` WHERE FROM_base64(`email`)='$posteds->email';");
				if(!empty($mailExists)){
					$ezDb->query("UPDATE `".$siteName."_users` SET `newsletter`=true WHERE `email`=TO_base64('$posteds->email')");
				}else{
					$ezDb->query("INSERT INTO `".$siteName."_users` (`email`,`newsletter`) VALUES (TO_base64('$posteds->email'),true)");
				}

				$headers = "From: <$posteds->email>" . $eol;
				$headers .= "Organization: Kin Rolay" . $eol;
				$headers .= "MIME-Version: 1.0" . $eol;
				$headers .= "Content-type: text/html; charset=iso-8859-1" . $eol;
				$headers .= "Content-Transfer-Encoding: 7bit" . $eol;
				if (mail("<info@$domainName>", $theSubject, $theMessage, $headers)) :
					$fail='<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button> <p>Your subscription request for our daily newsletter had been successfully confirmed.<br/>We\'ve sent you an email with a link just in case you decide to deactivate your request.<br/>Thanks!</p></div>';
				else:
					$fail='<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button> <p>Unable to connect to mail server</p></div>';
				endif;
			else:
				$fail='<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button> '.$fail.'</div>';
			endif;

			$smarty->assign("posts", $posteds)->assign("msg2", $fail);
		endif;
	endif;
}