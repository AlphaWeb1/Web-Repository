<?php

$sTempl= (!empty($Site['get']['s'])? $Site['get']['s']: "");

$pTempl= (!empty($Site['get']['p'])? $Site['get']['p']: "");

$smarty->assign('pTempl', $pTempl)->assign('sTempl', $sTempl);