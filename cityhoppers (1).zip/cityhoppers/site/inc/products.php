<?php global $sitePage;

$pageSect= (!empty($Site['get']['s'])? $Site['get']['s']: "");

$pagePart= (!empty($Site['get']['p'])? $Site['get']['p']: "");

$smarty->assign('pPart', $pagePart)->assign('pSect', $pageSect);