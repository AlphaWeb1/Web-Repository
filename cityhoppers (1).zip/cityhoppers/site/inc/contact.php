<?php global $sitePage;

require_once "Mail.php"; // PEAR Mail package
require_once ('Mail/mime.php'); // PEAR Mail_Mime packge

$err=0;
$fail='';
$posteds=new stdClass();

if ( in_array($sitePage, array("contact")) and ($requestMethod == 'POST') ) :
	$posteds =(object)$Site['post'];
	if ( empty($posteds->send) ):
		$err++;
		$fail .= '<p>Invalid form request!</p>';
	endif;
	if ( empty($posteds->names) ):
		$posteds->names="empty";
	endif;
	if ( empty($posteds->email) or !checkEmail($posteds->email)):
		$err++;
		$fail .= '<p>Kindly enter a valid email!</p>';
	endif;
	if ( empty($posteds->message) ):
		$err++;
		$fail .= '<p>Kindly enter a message!</p>';
	endif;
	if ( empty($posteds->subject) ):
		$posteds->subject= 'Comment';
	endif;
	if($err==0):
			$from = $posteds->email; //enter your email address
			// $to = "info@".$domainName; //enter the email address of the contact your sending to
			$to = "contact@cityhoppers.com.ng"; //enter the email address of the contact your sending to
			$subject = $posteds->subject; // subject of your email

			$headers = array ('From' => $from,'To' => $to, 'Subject' => $subject);

			$text = "Sender Name: ".$posteds->names.(empty($posteds->phone)? "": "\n\nTelephone: ".$posteds->phone)."\n\nMessage: ".$posteds->message.PHP_EOL; // text versions of email.
			$html = "<html><body>Name: ".$posteds->names." <br> Email: ".$from.(empty($posteds->phone)? "": "<br> Telephone: ".$posteds->phone)." <br> Message: ".$posteds->message." <br></body></html>"; // html versions of email.

			$crlf = "\n";

			$mime = new Mail_mime($crlf);
			$mime->setTXTBody($text);
			$mime->setHTMLBody($html);

			//do not ever try to call these lines in reverse order
			$body = $mime->get();
			$headers = $mime->headers($headers);
			$host = "localhost"; // all scripts must use localhost
			$username = "contact@cityhoppers.com.ng"; //  your email address (same as webmail username)
			// $username = "info@".$domainName; //  your email address (same as webmail username)
			$password = "L^Di8#KC5ogg"; // your password (same as webmail password)

			$smtp = Mail::factory('smtp', array ('host' => $host, 'auth' => true,
			'username' => $username,'password' => $password));

			$mail = $smtp->send($to, $headers, $body);

		if (PEAR::isError($mail)) :
			$fail='<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Error 601:</h3> <p>Unable to connect to send message</p></div>';
		else:
			$fail='<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button> <p>Your message had been successfully sent.<br/>Thanks!</p></div>';
		endif;
	else:
		$fail='<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Message Sending Failed:</h3> '.$fail.'</div>';
	endif;
endif;

$smarty->assign("posts", $posteds)->assign("msg", $fail);