<?php

ob_start();
$command = basename(__FILE__);
date_default_timezone_set('Africa/Lagos');

require_once "../../../config.php";
require_once "../../../$libraries/functions.php";
require_once "../../../$libraries/ezsql/ez_sql_core.php";
require_once "../../../$libraries/ezsql/ez_sql_mysql.php";
require_once "../../../../db_config.php";
foreach ($myGlobals as $key => $value) {
    $Site["$key"] = $value;
}
$Site["session"]=$_SESSION;
$Site["cookie"]=$_COOKIE;
$Site["post"]=$_POST;
$Site["get"]=$_GET;
$response=null;
//Your checkings starts here
$posts=(object)$Site["post"];
$gets=(object)$Site["get"];
$sessions=(object)$Site["session"];

$sitePage=null;
if( !empty($posts->sp) or !empty($gets->sp)){
	$sitePage=(!empty($posts->sp)? $posts->sp: $gets->sp);
}

if($sitePage=="security" and !empty($posts->sd)){
	if( $data=$ezDb->get_row("SELECT `password`,`username` FROM `".$siteName."_users` WHERE (`username`='".$posts->sd['username']."' OR `email`='".$posts->sd['username']."') AND `usertype`='client' AND `verified`='1';") ){
    	if( $data->password==sha1(md5(base64_encode($posts->sd['password']))) ){
    		$Site["session"]["User"]["security2"]=true;
    		$_SESSION=$Site["session"];
    		generateSecurityToken();
    		$response='success';
    	}else{
    		unset($Site["session"]["User"]["security2"]);
    		$_SESSION=$Site["session"];
    		$response='Invalid username or password';
    		nullifySecurityToken();
    	}
    }else{
		unset($Site["session"]["User"]["security2"]);
		$_SESSION=$Site["session"];
    	$response='Invalid username or password';
    	nullifySecurityToken();
    }
}elseif( in_array($sitePage, array("profile")) and !empty($posts->csd) ){
    if( $posts->csd['type']=="country" ){
        $response= json_encode( getStates($posts->csd['data']) );
    }elseif( $posts->csd['type']=="state" ){
        $response= json_encode( getCities($posts->csd['data']) );
    }
}


if(!empty($posts->evt)){
    if($posts->evt=='getTo'):
        $response=getDestinations($posts->tripType, $posts->travelFrom);
    elseif($posts->evt=='getDates'):
        $response= getTiming($posts->tripType, $posts->travelFrom, $posts->travelTo);
    elseif( in_array($posts->evt, array('roundTrip', 'oneWay') ) ):
        $response=getSources($posts->tripType);
    elseif($posts->evt=='viewManifest'):
        $response=getManifest($posts->manifestId);
    elseif( in_array($posts->evt, array('roundTrip1', 'oneWay1') ) ):
        $response=getSources1($posts->tripType);
    elseif($posts->evt=='getTo1'):
        $response=getDestinations1($posts->tripType, $posts->travelFrom);
    elseif($posts->evt=='getDates1'):
        $response= getTiming1($posts->tripType, $posts->travelFrom, $posts->travelTo);
    elseif($posts->evt=='viewManifest1'):
        $response=getManifest1($posts->manifestId);
    endif;
}

/*Return back to requester*/
if( in_array($posts->evt, array('viewManifest', 'roundTrip', 'oneWay', 'getTo', 'getDates', 'viewManifest1', 'roundTrip1', 'getTo1', 'oneWay1', 'getDates1')) ){
    $response=json_encode($response);
}

if ( !empty($response) ) {
	echo $response;
}