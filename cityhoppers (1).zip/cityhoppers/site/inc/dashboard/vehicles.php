<?php

$vehicles=$ezDb->get_results("SELECT * FROM `vehicles` ORDER BY `dateadded` DESC;");
// $drivers=$ezDb->get_results("SELECT * FROM `userprofile` WHERE `usertype`='driver' ORDER BY `dateadded` DESC;");

$smarty->assign('vehicles', $vehicles);