<?php

if(!empty($posts->triggers) and $posts->triggers=='hiringIn'){
	// error_log(json_encode($posts));
	if( empty($posts->firstname)):
		$err++;
		$fail.='<p>Kindly enter First name</p>';
	endif;
	if( empty($posts->lastname)):
		$err++;
		$fail.='<p>Kindly enter Last name</p>';
	endif;
	if( empty($posts->email) and empty(checkEmail($posts->email)) ):
		// $err++;
		// $fail.='<p>Kindly enter valid email</p>';
		$posts->email=$Site["session"]["User"]["userinfo"]->email;
	endif;
	if( empty($posts->phonenumber) or !is_numeric($posts->phonenumber)):
		$err++;
		$fail.='<p>Kindly phone number</p>';
	endif;
	if( empty($posts->departurepoint)):
		$err++;
		$fail.='<p>Kindly enter departure point</p>';
	endif;
	if( empty($posts->destination)):
		$err++;
		$fail.='<p>Kindly enter destination</p>';
	endif;
	if( !in_array($posts->type, array(0,1))):
		$err++;
		$fail.='<p>Kindly select a valid trip</p>';
	endif;
	if( empty($posts->passenger) or $posts->passenger<1):
		$err++;
		$fail.='<p>Kindly enter vaild number of passenger</p>';
	endif;
	if( empty($posts->days) or $posts->days<1):
		$err++;
		$fail.='<p>Kindly enter vaild number of days</p>';
	endif;
	error_log($ezDb->get_var("SELECT DATEDIFF( '$posts->dateneeded', '$dateNow');"));
	if( empty($posts->dateneeded) or $ezDb->get_var("SELECT DATEDIFF( '$posts->dateneeded', '$dateNow');")<1):
		$err++;
		$fail.='<p>Kindly enter vaild needed date</p>';
	endif;
	if( empty($posts->address)):
		$err++;
		$fail.='<p>Kindly enter address</p>';
	endif;
	if( empty($posts->state)):
		$err++;
		$fail.='<p>Kindly enter state</p>';
	endif;
	if( empty($posts->city)):
		$err++;
		$fail.='<p>Kindly enter city</p>';
	endif;

	if($err==0):
		do{
			$token=getToken(15);
		}while($ezDb->get_var("SELECT `token` FROM `hiring` WHERE `token`='$token';"));
		//do the savings
		$userDetail=new stdClass;
		$userDetail->firstname=$posts->firstname;
		$userDetail->lastname=$posts->lastname;
		$userDetail->phone=$posts->phonenumber;
		$userDetail->email=$posts->email;
		$userDetail->address=$posts->address;
		$userDetail->city=$posts->city;
		$userDetail->state=$posts->state;

		$posts->dateneeded=date("Y-m-d H:i:s", strtotime($posts->dateneeded) );

		$others=new stdClass;
		$others->passenger=$posts->passenger;
		$others->days=$posts->days;
		$curUser=$Site["session"]["User"]["userinfo"]->email;
		$ezDb->query("INSERT INTO `hiring` (`token`, `hiredby`, `contacts`, `type`, `departure`, `destination`, `dateneeded`, `responsestatus`, `daterequested`, `otherInfo`) VALUES ('$token', '$curUser', '".json_encode($userDetail)."', '$post->type', '$posts->departurepoint', '$posts->destination', '$posts->dateneeded', '0', '$dateNow', '".json_encode($others)."');");
		$fail='<div class="alert alert-success alert-dismissible" role="alert" style="position: absolute; z-index: 1100; vertical-align: middle; align-self: center; width: 70% !important; top: 140px; margin-left: 15%;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Success!</h3> <p>Hiring request had been successfully sent</p></div>';
	else:
		$fail='<div class="alert alert-danger alert-dismissible" role="alert" style="position: absolute; z-index: 1100; vertical-align: middle; align-self: center; width: 70% !important; top: 140px; margin-left: 15%;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Error Messages</h3> '.$fail.'</div>';
	endif;
}