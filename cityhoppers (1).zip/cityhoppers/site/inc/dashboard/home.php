<?php global $sitePage, $Site, $ezDb, $siteName, $smarty;

if(bookinTokenExists1($sessions->tempToken)){
	$ezDb->query("UPDATE `userprofile` SET `temptoken`='$sessions->tempToken' WHERE `email`='".$Site["session"]["User"]["userinfo"]->email."' AND `usertype`='client'");
	$ezDb->query("UPDATE `temp_booking1` SET  `user`='".$Site["session"]["User"]["userinfo"]->email."' WHERE `token`='$sessions->tempToken';");
	redirect("booking");
}

