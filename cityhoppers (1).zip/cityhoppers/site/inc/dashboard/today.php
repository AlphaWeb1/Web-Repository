<?php

$allSchedules=$ezDb->get_results("SELECT * FROM `tripschedules1` WHERE DATEDIFF(`departure`, '$dateNow')=0 ORDER BY `departure` ASC;");
$smarty->assign('allSchedules', $allSchedules);