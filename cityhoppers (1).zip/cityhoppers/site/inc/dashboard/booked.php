<?php

$sessions->tempToken=$Site["session"]["User"]["userinfo"]->temptoken;
if( empty(bookinTokenExists1($sessions->tempToken)) and $err==0 ){
	redirect("book");
}
$tempBookings=$ezDb->get_row("SELECT * FROM `temp_booking1` WHERE `token`='$sessions->tempToken';");
$tempBookings->search=json_decode($tempBookings->search);
$tempBookings->vehicle=json_decode($tempBookings->vehicle);
$tempBookings->userdata=json_decode($tempBookings->userdata);
if(!empty($tempBookings->search) and !empty($tempBookings->vehicle)){
	require_once "save_client_data.php";
	require_once "billing-payment.php";
	$smarty->assign('booked','booked')->assign('tempBookings', $tempBookings)->assign('msg',$fail)->assign('userData',$tempBookings->userdata);
}else{ 
	redirect('booking');
}