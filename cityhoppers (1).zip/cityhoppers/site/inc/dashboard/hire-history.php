<?php

$curUser=$Site["session"]["User"]["userinfo"]->email;
$rentals=$ezDb->get_results("SELECT * FROM `hiring` WHERE `hiredby`='$curUser' ORDER BY `daterequested` DESC;");
if (!empty($rentals)) {
	foreach ($rentals as $rental) {
		$rental->contacts=json_decode($rental->contacts);
		$rental->otherInfo=json_decode($rental->otherInfo);
	}
}
$smarty->assign('rentals', $rentals);