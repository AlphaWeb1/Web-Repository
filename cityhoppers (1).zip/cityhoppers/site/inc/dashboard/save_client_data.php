<?php global $sitePage;

// All for Booking and Payment
$sessions->tempToken=$Site["session"]["User"]["userinfo"]->temptoken;
if( empty(bookinTokenExists1($sessions->tempToken)) and $err==0 ){
	redirect("book");
}

if( !empty(bookinTokenExists1($sessions->tempToken)) and !empty($tempBookings->search) and !empty($tempBookings->vehicle) ){

	$userData=new stdClass();
	if ($posts->triggers=='saveUserData') {
		for($x=0; $x<$tempBookings->search->passenger; $x++):
			if( empty($posts->firstName[$x]) or is_numeric($posts->firstName[$x]) ):
				$err++;
				$fail.='<p>Kindly enter your first name of passenger </p>';
			endif;
			if( empty($posts->lastName[$x]) or is_numeric($posts->lastName[$x]) ):
				$err++;
				$fail.='<p>Kindly enter your last name</p>';
			endif;
			if( empty($posts->gender[$x]) or !in_array($posts->gender[$x], array("female","male")) ):
				$err++;
				$fail.='<p>Kindly select your gender</p>';
			endif;
			if( empty($posts->phoneNo[$x]) ):
				$err++;
				$fail.='<p>Kindly enter a valid phone number</p>';
			endif;
			if( empty($posts->email[$x]) or !checkEmail($posts->email[$x]) ):
				$err++;
				$fail.='<p>Kindly enter a valid email</p>';
			endif;
			if( empty($posts->nokName[$x]) or is_numeric($posts->nokName[$x]) ):
				$err++;
				$fail.='<p>Kindly enter a valid name for Next of Kin</p>';
			endif;
			if( empty($posts->phoneNo[$x]) ):
				$err++;
				$fail.='<p>Kindly enter a valid phone number for Next of Kin</p>';
			endif;
		endfor;
		if( empty($posts->payment) or !in_array($posts->payment, array("ps")) ):
			$err++;
			$fail.='<p>Kindly select a valid payment method</p>';
		endif;
		if( empty($posts->terms) or $posts->terms!='1'):
			$fail.='<p>Notice: you must agree to the Cityhopper\'s ticket reservation terms and policy</p>';
			$err++;
		endif;

		if($err==0):
			unset($posts->triggers);
			// error_log(json_encode());
			$userData=$posts;
			// $userData->firstName=$posts->firstName;
			// $userData->initial=$posts->initial;
			// $userData->lastName=$posts->lastName;
			// $userData->phoneNo=$posts->phoneNo;
			// $userData->email=$posts->email;
			// $userData->gender=$posts->gender;
			// $userData->payment=$posts->payment;
			// $userData->nokName=$posts->nokName;
			// $userData->nokPhone=$posts->nokPhone;
			$userData->unitfee= $tempBookings->vehicle->unitfee;
			$userData->quantity= $tempBookings->search->passenger;
			$userData->total=$tempBookings->vehicle->grandTotal;
			$userData->discount=json_decode(getSettings("schedule"))->discount;
			$tempBookings->userdata=$userData;
			// error_log(json_encode($tempBookings->userdata));
			$ezDb->query("UPDATE `temp_booking1` SET `userdata`='".json_encode($userData)."' WHERE `token`='$sessions->tempToken';");
			$fail='<div class="alert alert-success alert-dismissible" role="alert" style="position: absolute; z-index: 1100; vertical-align: middle; align-self: center; width: 70% !important; top: 140px; margin-left: 15%;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Success!</h3> <p>Now Scroll down to click on the payment gateway displayed below to pake payment</p></div>';
			$fail='';
		else:
			$fail='<div class="alert alert-danger alert-dismissible" role="alert" style="position: absolute; z-index: 1100; vertical-align: middle; align-self: center; width: 70% !important; top: 140px; margin-left: 15%;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Error Messages</h3> '.$fail.'</div>';
		endif;
	}
}