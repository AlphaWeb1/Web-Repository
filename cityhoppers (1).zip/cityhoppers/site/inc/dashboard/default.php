<?php

$counts=new stdClass();
$curUser=$Site["session"]["User"]["userinfo"]->email;
$counts->tickets=$ezDb->get_var("SELECT COUNT(`b`.`ticketNo`) FROM `temp_booking1` AS `tb`, `booking1` AS `b` WHERE `tb`.`user`='$curUser' AND `tb`.`token`=`b`.`bookingtoken` AND `tb`.`status`='1'");
$counts->hires=$ezDb->get_var("SELECT COUNT(`token`) FROM `hiring` WHERE `hiredby`='$curUser' AND `responsestatus`='0' ORDER BY `daterequested` DESC;");
$counts->schedules=$ezDb->get_var("SELECT COUNT(`token`) FROM `tripschedules1` WHERE DATEDIFF(`departure`, '$dateNow')=0");
$smarty->assign('counts', $counts);