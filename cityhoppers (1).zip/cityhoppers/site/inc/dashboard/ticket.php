<?php


$tickets=$ezDb->get_results("SELECT `b`.`id`, `b`.`client`, `b`.`bookedBy`, `b`.`bookingtoken`, `b`.`ticketNo`, `b`.`bookingInfo`, `b`.`bookingDate`, `b`.`billingId`, `b`.`noOfPerson`, `b`.`totalFee`, `tb`.`token`, `tb`.`ipaddress`, `tb`.`user`, `tb`.`search`,  `tb`.`vehicle`,  `tb`.`userdata`, `tb`.`dateadded`, `tb`.`status` FROM `temp_booking1` AS `tb`, `booking1` AS `b` WHERE `tb`.`user`='".$Site["session"]["User"]["userinfo"]->email."' AND `tb`.`token`=`b`.`bookingtoken` AND (`tb`.`status`='1' OR `tb`.`status`='2') ORDER BY `b`.`id` DESC;");
if(!empty($tickets)){
	foreach ($tickets as  $value) {
		$value->bookingInfo=json_decode($value->bookingInfo);
		$value->search=json_decode($value->search);
		$value->vehicle=json_decode($value->vehicle);
		$value->userdata=json_decode($value->userdata);
	}
}


$smarty->assign('tickets', $tickets)->assign("fail",$fail);