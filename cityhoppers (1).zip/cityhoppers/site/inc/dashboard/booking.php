<?php

$sessions->tempToken=$Site["session"]["User"]["userinfo"]->temptoken;
if( empty(bookinTokenExists1($sessions->tempToken)) and $err==0 ){
	redirect("book");
}
if (!empty($gets->eventTrig) and $gets->eventTrig=='cancel') {
	$ezDb->query("UPDATE `userprofile` SET `temptoken`='' WHERE `email`='".$Site["session"]["User"]["userinfo"]->email."' AND `usertype`='client'");
	$theBookings=$ezDb->get_row("SELECT * FROM `temp_booking1` WHERE `token`='$sessions->tempToken';");
	$theBookings->search=json_decode($theBookings->search);
	$theBookings->vehicle=json_decode($theBookings->vehicle);
	if(!empty($theBookings->search) and !empty($theBookings->vehicle)){
		if(!empty($theBookings->vehicle->departureID)){
			$tripschee=$ezDb->get_row("SELECT * FROM `tripschedules1` WHERE `token`='".$theBookings->vehicle->departureID."'");
			$tripschee->chosenseats=json_decode($tripsched->chosenseats);
			if (!empty($theBookings->vehicle->seats) and is_array($theBookings->vehicle->seats)) {
				foreach ($theBookings->vehicle->seats as $value) {
					unset($tripschee->chosenseats[$value]);
				}
			}
			$tripschee->chosenseats=json_encode($tripschee->chosenseats);
			$ezDb->query("UPDATE `tripschedules1` SET `chosenseats`='$tripschee->chosenseats' WHERE `token`='".$theBookings->vehicle->departureID."'");
		}
		if(!empty($theBookings->vehicle->returnID)){
			$tripschee=$ezDb->get_row("SELECT * FROM `tripschedules1` WHERE `token`='".$theBookings->vehicle->returnID."'");
			$tripschee->chosenseats=json_decode($tripsched->chosenseats);
			if (!empty($theBookings->vehicle->seats1) and is_array($theBookings->vehicle->seats1)) {
				foreach ($theBookings->vehicle->seats1 as $value) {
					unset($tripschee->chosenseats[$value]);
				}
			}
			$tripschee->chosenseats=json_encode($tripschee->chosenseats);
			$ezDb->query("UPDATE `tripschedules1` SET `chosenseats`='$tripschee->chosenseats' WHERE `token`='".$theBookings->vehicle->returnID."'");
		}
	}
	$ezDb->query("DELETE FROM `temp_booking1` WHERE `token`='$sessions->tempToken'");
	unset($Site["session"]['tempToken']);
    $_SESSION=$Site["session"];
    $sessions= (object)$Site["session"];
    redirect('book');
}

if ($posts->triggers=='bookSeat') {
	// error_log('1');
	/*Verification for Departure Vehicle*/
	if( empty($posts->vehicleid) or empty($ezDb->get_var("SELECT `token` FROM `tripschedules1` WHERE `token`='$posts->tag'")) ):
		$err++;
		$fail.='<p>Kindly select a departure vehicle</p>';
	endif;
	$foundSeat=foundSeat($posts->seat);
	if( empty($foundSeat) ):
		// error_log('3');
		$err++;
		$fail.='<p>Kindly select a valid seat number</p>';
	endif;
	$tempBookings=$ezDb->get_row("SELECT * FROM `temp_booking1` WHERE `token`='$sessions->tempToken';");
	if(!empty($tempBookings)):
		$tempBookings->search=json_decode($tempBookings->search);
	endif;
	$tripsched=$ezDb->get_row("SELECT * FROM `tripschedules1` WHERE `token`='$posts->tag'");
	$tripsched->chosenseats=json_decode($tripsched->chosenseats);
	if(!is_array($tripsched->chosenseats)):
		$tripsched->chosenseats=array();
	endif;
	foreach($foundSeat as $fS):
		if(in_array($fS, $tripsched->chosenseats)):
			$err++;
			$fail.="<p>Seat {$fS} had already been chosen, choose another seat number</p>";
			break;
		endif;
		array_push($tripsched->chosenseats, $fS);
	endforeach;

	if(count($foundSeat)!=$tempBookings->search->passenger):
		$err++;
		$fail.='<p>You have to select the total of '.$tempBookings->search->passenger.' seats departure trip</p>';
	endif;
	/*Verification for Round Trip Deails*/
	$tripsched1=$ezDb->get_row("SELECT * FROM `tripschedules1` WHERE `token`='$posts->tag1'");
	if( $tempBookings->search->tripType=='Round Trip' ):
		if( empty($posts->vehicleid) or empty($ezDb->get_var("SELECT `token` FROM `tripschedules1` WHERE `token`='$posts->tag1'"))):
			$err++;
			$fail.='<p>Kindly select a return trip vehicle</p>';
		endif;
		$foundSeat1=foundSeat($posts->seat1);
		if( empty($foundSeat1) ):
			// error_log('3-1');
			$err++;
			$fail.='<p>Kindly select a valid seat number for return trip</p>';
		endif;
		$tripsched1->chosenseats=json_decode($tripsched1->chosenseats);
		if(!is_array($tripsched1->chosenseats)):
			$tripsched1->chosenseats=array();
		endif;
		foreach($foundSeat1 as $fS1):
			if(in_array($fS1, $tripsched1->chosenseats)):
				$err++;
				$fail.="<p>Seat {$fS1} had already been chosen, choose another seat number</p>";
				break;
			endif;
			array_push($tripsched1->chosenseats, $fS1);
		endforeach;
		if(count($foundSeat1)!=$tempBookings->search->passenger):
			$err++;
			$fail.='<p>You have to select the total of '.$tempBookings->search->passenger.' seats for return trip</p>';
		endif;
	endif;

	if($err==0):
		// error_log('2');
		// error_log(json_encode($posts)."\n".json_encode($foundSeat));
		$vehicleDetail=new stdClass();
		$vehicleDetail->seats=$foundSeat;
		$vehicleDetail->unitfee=$tripsched->unitfee;
		$vehicleDetail->departureID=$posts->tag;
		$vehicleDetail->departureDate=$tripsched->departure;
		$vehicleDetail->vehicleid=trim(str_replace("\n", "", $posts->vehicleid));
		$vehicleDetail->grandTotal=count($vehicleDetail->seats) * $vehicleDetail->unitfee;
		$tripsched->chosenseats=optimizeJSON($tripsched->chosenseats);
		// str_replace('""', '', $tripsched->chosenseats);
		// $tripsched->chosenseats=rtrim($tripsched->chosenseats,'"');
		// $tripsched->chosenseats=ltrim($tripsched->chosenseats,'"');

		$ezDb->query("UPDATE `tripschedules1` SET `chosenseats`='$tripsched->chosenseats' WHERE `token`='$posts->tag';");
		// Return Details
		if( $tempBookings->search->tripType=='Round Trip' ):
			$vehicleDetail->seats1=$foundSeat1;
			$vehicleDetail->unitfee1=$tripsched1->unitfee;
			$vehicleDetail->returnID=$posts->tag1;
			$vehicleDetail->returnDate=$tripsched1->departure;
			$vehicleDetail->vehicleid1=trim(str_replace("\n", "", $posts->vehicleid1));
			$vehicleDetail->grandTotal+=(count($vehicleDetail->seats1) * $vehicleDetail->unitfee1);
			// $ezDb->query("UPDATE `tripschedules1` SET `chosenseats`='".json_encode($tripsched1->chosenseats)."' WHERE `token`='$posts->tag1';");
			$tripsched1->chosenseats=optimizeJSON($tripsched1->chosenseats);
			$ezDb->query("UPDATE `tripschedules1` SET `chosenseats`='$tripsched1->chosenseats' WHERE `token`='$posts->tag1';");
		endif;

		$ezDb->query("UPDATE `temp_booking1` SET `vehicle`='".json_encode($vehicleDetail)."' WHERE `token`='$sessions->tempToken';");
		redirect("booked");
	else:
		$fail='<div class="alert alert-danger alert-dismissible" role="alert" style="position: absolute; z-index: 1100; vertical-align: middle; align-self: center; width: 70% !important; top: 140px; margin-left: 15%;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Error Messages</h3> '.$fail.'</div>';
	endif;
}



$tempBookings=$ezDb->get_row("SELECT * FROM `temp_booking1` WHERE `token`='$sessions->tempToken';");
if(!empty($tempBookings->vehicle)){
	$tempBookings->vehicle=json_decode($tempBookings->vehicle);
	if (is_object($tempBookings->vehicle)) {
		redirect("booked");
	}
}
if(!empty($tempBookings) and !empty($tempBookings->search)){
	$tempBookings->source=json_decode($tempBookings->search);
}else{
	$ezDb->query("UPDATE `userprofile` SET `temptoken`='' WHERE `email`='".$Site["session"]["User"]["userinfo"]->email."' AND `usertype`='client'");
	$ezDb->query("DELETE FROM `temp_booking1` WHERE `token`='$sessions->tempToken';");
}
$vehicles=new stdClass();
$vehicles->departures=$ezDb->get_results("SELECT DISTINCT `ts`.`token`, `ts`.`departure`, `ts`.`chosenseats`, `ts`.`capacity`, `ts`.`unitfee`, `ts`.`source`, `ts`.`destination`, `vc`.`vehicleid`, `vc`.`plateno`, `vc`.`model`, `vc`.`driversid`, `vc`.`type` FROM `tripschedules1` AS `ts`, `vehicles` AS `vc` WHERE `vc`.`vehicleid`=`ts`.`vehicleid` AND (TIMESTAMPDIFF(MINUTE,'$dateNow', `ts`.`departure`)>30 AND DATEDIFF(`ts`.`departure`,'".$tempBookings->source->deptDate."')=0)  AND `ts`.`source`='".$tempBookings->source->travelFrom."' AND `ts`.`destination`='".$tempBookings->source->travelTo."' ORDER BY `ts`.`departure` ASC;");
if( $tempBookings->source->tripType=='Round Trip' ){
	$vehicles->returns=$ezDb->get_results("SELECT DISTINCT `ts`.`token`, `ts`.`departure`, `ts`.`chosenseats`, `ts`.`capacity`, `ts`.`unitfee`, `ts`.`source`, `ts`.`destination`, `vc`.`vehicleid`, `vc`.`plateno`, `vc`.`model`, `vc`.`driversid`, `vc`.`type` FROM `tripschedules1` AS `ts`, `vehicles` AS `vc` WHERE `vc`.`vehicleid`=`ts`.`vehicleid` AND (TIMESTAMPDIFF(HOUR, '$dateNow', `ts`.`departure`)>23 AND DATEDIFF(`ts`.`departure`,'".$tempBookings->source->retDate."')=0) AND `ts`.`destination`='".$tempBookings->source->travelFrom."' AND `ts`.`source`='".$tempBookings->source->travelTo."' ORDER BY `ts`.`departure` ASC;");
}

$smarty->assign('tempBookings', $tempBookings)->assign('msg',$fail)->assign('vehicles', $vehicles);