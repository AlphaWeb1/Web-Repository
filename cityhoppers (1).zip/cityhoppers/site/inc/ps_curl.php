<?php global $sitePage;
$fail='';
$errr=0;
$sessions= (object)$Site["session"];
if( !empty(bookinTokenExists1($sessions->tempToken)) ){
  $tempBookings=$ezDb->get_row("SELECT * FROM `temp_booking1` WHERE `token`='$sessions->tempToken';");
  $tempBookings->search=json_decode($tempBookings->search);
  $tempBookings->vehicle=json_decode($tempBookings->vehicle);
  $tempBookings->userdata=json_decode($tempBookings->userdata);


  if( !empty($tempBookings->search) and !empty($tempBookings->vehicle) and !empty($tempBookings->userdata) ){
    if ($ezDb->get_var("SELECT `token` FROM `paystack_hits1` WHERE `token`='$sessions->tempToken' AND `data_received`='' AND `data_intransit` !='';")) {

      $curl = curl_init();
      $reference = isset($_GET['reference']) ? $_GET['reference'] : '';
      if(!$reference){
        // die('No reference supplied');
        // $fail.='<p>Error cannot verify payment: No reference supplied</p>';
        // $ezDb->query("UPDATE `paystack_hits` SET `data_received`='null', `status`='fail' WHERE `token`='$sessions->tempToken';");
        $tranx=$ezDb->get_var("SELECT `data_received` FROM `paystack_hits1` WHERE `token`='$sessions->tempToken';");
        $bookings=$ezDb->get_row("SELECT * FROM `booking` WHERE `bookingtoken`='$sessions->tempToken';");
      }else{
        curl_setopt_array($curl, array(
          CURLOPT_URL => "https://api.paystack.co/transaction/verify/" . rawurlencode($reference),
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_HTTPHEADER => [
            "accept: application/json",
            "authorization: Bearer sk_live_132af3c2eb03df6a59ea188231a14c4014492869", // sk_test_3f6245c379132ff5fe57e0c0bdc59cb4489a5426  sk_test_97faafb8e67bf660a85db8e8531f2215ebb907ec
            "cache-control: no-cache"
          ],
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        if($err){
          $errr++;
        	// there was an error contacting the Paystack API
          //die('Curl returned error: ' .$err );
          $fail.='<p>Curl returned error: '.$err.'</p>';
        }else{
          $tranx = json_decode($response);

          if(!$tranx->status){ 
            $errr++;
            // there was an error from the API
            // die('API returned error: ' .$tranx->message );
            $fail.='<p>API returned error: '.$tranx->message.'</p>';
          }

          if('success' == $tranx->data->status){

            // transaction was successful...
            // please check other things like whether you already gave value for this ref
            // if the email matches the customer who owns the product etc
            // Give value
            /*Update All necessary tables when done*/
            $curUser=( !empty($Site["session"]["User"]["client"]["Token"])? $Site["session"]["User"]["userinfo"]->email: "guest");
            if( !empty($Site["session"]["User"]["client"]["Token"]) and sessionExists($Site["session"]["User"]["client"]["Token"])==true ){
              $Site["get"]['booker']=$Site["session"]["User"]["userinfo"]->email;
            }
            $clientUn=!empty($Site["get"]['booker'])?$Site["get"]['booker']: $tempBookings->userdata->email[0];

            $ezDb->query("UPDATE `temp_booking1` SET `status`=true, `user`='$clientUn' WHERE `token`='$sessions->tempToken';");
            do{
              $token=getToken(10);
            }while($ezDb->get_var("SELECT `ticketNo` FROM `booking1` WHERE `ticketNo`='$sessions->tempToken';"));
            $bookingInfo=new stdClass();
            $bookingInfo->vehicleDetails=$tempBookings->vehicle;
            $bookingInfo->userdata=$tempBookings->userdata;
            $bookingInfo->dateAdded=$tempBookings->dateadded;
            $bookingInfo->ipaddress=$tempBookings->ipaddress;
            $bookingInfo->status=1;
            // Add the discount to bookingInfo
            // Log Booking
            $ezDb->query("INSERT INTO `booking1` (`client`, `bookedBy`, `bookingtoken`, `ticketNo`, `bookingInfo`, `bookingDate`, `noOfPerson`, `totalFee`) VALUES ('$clientUn','guest','". $tempBookings->token."','$token','".json_encode($bookingInfo)."','$dateNow','".$tempBookings->search->passenger."','".$tempBookings->userdata->total."');");

            // log Payment
            $tempBookings->bookingID=$token;
            $ezDb->query("INSERT INTO `payment1` (`transid`, `ticketid`, `amount`, `transdate`, `paymenttype`, `paidby`, `paymentstatus`) VALUES ('".$tranx->data->reference."','$token','".$tempBookings->userdata->total."','$dateNow','".$tempBookings->userdata->payment."','$clientUn','".($tranx->data->status=='success'?'1':'0')."');");
            $bookings=$ezDb->get_row("SELECT * FROM `booking1` WHERE `bookingtoken`='$sessions->tempToken';");

            for( $i=0; $i< count($tempBookings->userdata->email); $i++ ):
              $divElements=setDivElement($bookings, $tempBookings, $i);
              require_once 'send_mail_to_clients.php';
            endfor;

            $fail='<div class="alert alert-success alert-dismissible" role="alert" style="position: absolute; z-index: 1100; vertical-align: middle; align-self: center; width: 70% !important; top: 140px; margin-left: 15%;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Success!</h3> <p>Payment successfully made, each passengers should check their email for their tickets</p></div>';

            $ezDb->query("UPDATE `paystack_hits1` SET `data_received`='".(json_encode($tranx))."', `status`='".$tranx->data->status."' WHERE `token`='$sessions->tempToken';");
            unset($Site["session"]['tempToken']);
            $_SESSION=$Site["session"];
            $sessions= (object)$Site["session"];
            if( !empty($Site["session"]["User"]["client"]["Token"]) and sessionExists($Site["session"]["User"]["client"]["Token"])==true  and !empty($Site["session"]["User"]["userinfo"]->temptoken) ){
              $ezDb->query("UPDATE `userprofile` SET `temptoken`='' WHERE `email`='".$Site["session"]["User"]["userinfo"]->email."' AND `usertype`='client'");
              redirect($Site['siteProtocol'].$Site['domainName']."/dashboard/receipt?receiptID=$token" );
              return;
            }
          }
        }
        if($errr>0){
          $fail='<div class="alert alert-danger alert-dismissible" role="alert" style="position: absolute; z-index: 1100; vertical-align: middle; align-self: center; width: 70% !important; top: 140px; margin-left: 15%;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h3>Error Messages</h3> '.$fail.'</div>';
        }
      }
      $smarty->assign('booked','booked')->assign('tempBookings', $tempBookings)->assign('fail',$fail)->assign('userData',$tempBookings->userdata)->assign('tranx',$tranx)->assign('bookings',$bookings);
    }
  }
}