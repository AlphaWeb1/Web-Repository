<?php

require 'config.php';

class Db_connect {

    // Holds the database connection
    private $dbConnection;

    /**
     * Create's the connection to the database and stores it in the dbConnection
     */
    public function __construct() {
        $this->dbConnection = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

        if ($this->dbConnection->connect_error) {
            die('Connection error.');
        }
    }

    function add_users($mail, $pass, $username, $fname, $lname) {
        $sql = "SELECT `id` FROM `users` WHERE `username` = '$username' OR `email` = '$mail' ";
        $result = $this->dbConnection->query($sql);
        if ($result->num_rows > 0) {
            exit('Username or email already exist');
        }

        $query = <<<QUERY
      INSERT INTO `users`(`username`, `password`, `email`,`fname`,`lname`)
      VALUES ('{$username}', '{$pass}', '{$mail}', '{$fname}', '{$lname}')
QUERY;
        $result = $this->dbConnection->query($query);
        if ($result !== false) {
            $sql = "SELECT `id`,`username` FROM `users` WHERE `username` = '$username' ";
            $result = $this->dbConnection->query($sql);
            if ($result->num_rows > 0) {
                // output data of each row
                while ($row = $result->fetch_assoc()) {
                    $_SESSION['id'] = $row["id"];
                    $_SESSION['username'] = $row['username'];
                }
            }
            echo '1';
        } else {
            echo '0';
        }
    }

    function login($u, $p) {
        if ($sql = "SELECT `id`,`username` FROM `users` WHERE `username` = '$u' AND `password` = '$p' ") {
            $result = $this->dbConnection->query($sql);
            if ($result->num_rows > 0) {
                // output data of each row
                while ($row = $result->fetch_assoc()) {
                    $_SESSION['id'] = $row["id"];
                    $_SESSION['username'] = $row['username'];
                }
            }
            echo '1';
        } else {
            echo '0';
        }
    }

    function get_users() {
        $user = $_SESSION['username'];
        // $users = array();
        if ($sql = "SELECT * FROM `users` WHERE `username` != '$user' ") {
            $result = $this->dbConnection->query($sql);
            while ($row = $result->fetch_assoc()) {
                $users[] = $row;
            }
            return $users;
        } else {
            echo 'No user Available';
        }
    }
    

    function get_count(){
        $user = $_SESSION['username'];
        // here, do count number of sent and received files to be displayed on the dashboard
    }

}
