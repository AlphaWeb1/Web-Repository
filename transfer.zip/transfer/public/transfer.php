<?php require 'header.php'; ?>
<?php require 'dashheader.php'; ?>
<?php
require '../core/Db_connect.php';
$db = new Db_connect();
$users = $db->get_users();
?>
<form action="file_processor.php" method="post">
    <div id="transfer">
        <div class="col-md-5 col-md-offset-3" id="file">
            <div class="form-group">
                <input id="input-43" name="file" class="t" type="file">
            </div>
            <button type="button" class="btn btn-block btn-primary" id="next">Next</button>
        </div>

        <div id="send-to" class="col-md-5 col-md-offset-3">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h4 class="panel-title">Select User</h4>
                    <button type="button" id="back" class="btn btn-info btn-sm pull-right"><i class="fa fa-undo"></i> Back</button>
                </div>
                <div class="panel-body">
                    <?php foreach ($users as $key => $user): ?>
                        <div class="radio">
                            <input type="radio" name="recipient" id="radio<?php echo $key; ?>" value="<?php echo $user['username']; ?>" >
                            <label for="radio<?php echo $key; ?>">
                                <?php echo $user['fname'] . " " . $user['lname']; ?>
                            </label>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="panel-footer">
                    <button type="submit" class="btn btn-default btn-block"><i class="fa fa-cloud-upload" aria-hidden="true"></i> Upload</button>
                </div>
            </div>
        </div>
    </div>
</form>


<?php require 'dashfooter.php'; ?>
<?php require 'footer.php'; ?>