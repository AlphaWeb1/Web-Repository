<?php

// check if file is present in variable $_REQUEST['file'] and 
// user selected in variable $_REQUEST['recipient']
// if not return to transfer.php

if (isset($_REQUEST['file'], $_REQUEST['recipient'])) {
    require 'header.php';
    require 'dashheader.php';
    // now you can do whatever with the file
    //after successful insert, uncomment the view below
//    echo '<div id="status"><div class="col-md-5 col-md-offset-3" id="h">Transer Successful</div></div> ';
    
    require 'dashfooter.php';
    require 'footer.php';
} else {
    header("location:http://localhost/transfer/public/transfer.php");
}
