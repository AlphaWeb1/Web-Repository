<?php
session_start();
if (isset($_SESSION['username'])) {
    header('location:send.php');
    
}
?>
<?php require 'header.php'; ?>

<div class="col-md-6 col-md-offset-3">
    <div class="panel panel-primary">
        <div class="panel-heading">
            <h3 class="panel-title"><strong>Login Or Register</strong></h3>
        </div>
        <div class="panel-body">
            <div class="loginform">
                <form method="POST" id="login" class="form-horizontal">
                    <div class="form-group">
                        <label for="username" class="control-label col-xs-2">Username</label>
                        <div class="col-xs-9">
                            <input type="text" id="username" class="form-control" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="email" class="control-label col-xs-2">Password</label>
                        <div class="col-xs-9">
                            <input type="password" id="password" class="form-control" required>
                        </div>
                    </div>
                    <p id="hint" class="text-primary"></p>
                    <p class="text-danger">Don't have an account?<a id="to-reg" class="btn btn-link">Sign Up</a></p>
                    <button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-log-in"></span>&nbsp;&nbsp;Sign in</button>
                </form>
            </div>
            <div class="regform">
                <form method="POST" id="register" class="form-horizontal">
                    <div class="form-group">
                        <label for="fname" class="control-label col-xs-2">Firstname</label>
                        <div class="col-xs-9">
                            <input type="text" id="fname" class="form-control" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="lname" class="control-label col-xs-2">Lastname</label>
                        <div class="col-xs-9">
                            <input type="text" id="lname" class="form-control" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="email" class="control-label col-xs-2">Username</label>
                        <div class="col-xs-9">
                            <input type="text" id="user_name" class="form-control" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="email" class="control-label col-xs-2">Email</label>
                        <div class="col-xs-9">
                            <input type="email" id="mail" class="form-control" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="email" class="control-label col-xs-2">Password</label>
                        <div class="col-xs-9">
                            <input type="password" id="paswd" class="form-control" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="email" class="control-label col-xs-2">Password</label>
                        <div class="col-xs-9">
                            <input type="password" id="repaswd" class="form-control" required>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                    <p id="reg-hint" class="text-primary"></p>
                    <p class="text-danger">Already have an account?<a id="to-login" class="btn btn-link">Sign in</a></p>
                    <button type="submit" class="btn btn-primary">Sign Up</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php require 'footer.php'; ?>
</body>
</html>