
$(function () {

    $("form#register").submit(function () {
        var e = $("#mail").val(),
                u = $("#user_name").val(),
                fname = $("#fname").val(),
                lname = $("#lname").val(),
                p1 = $("#paswd").val(),
                p2 = $("#repaswd").val();

        if (p1 !== p2) {
            $("#reg-hint").html('<span class="glyphicon glyphicon-remove"></span>Password not match');
        } else {
            $.post('ajax/user.php', {mail: e, paswd: p1, user: u, f: fname, l: lname}, function (response) {
                if (response === '1') {
                    $(location).attr('href', 'send.php');
                } else {
                    alert(response);
                    $("#reg-hint").html('<p>' + response + '</p>');
                    $("#reg-hint").html('<p>Error Registering, please try again later.</p>');
                }
            });
        }
        return false;
    });

    $("form#login").submit(function () {
        var u = $("#username").val(),
                p = $("#password").val();
        $.post('ajax/user.php', {u: u, p: p}, function (response) {
            if (response === '1') {
                $(location).attr('href', 'send.php');
            } else {
                $("#hint").html('<p>Invalid Username or Password</p>');
            }
        });
        return false;
    });

    $("#next").click(function () {
        var file = $(".t").val();
        if (file == "") {
            alert("Place a file to upload");
            return false;
        } else {
            $("#file").fadeTo(1000, 0).hide();
            $("#send-to").fadeTo(1000, 1).show();
        }
    });

    $("#back").click(function () {
        $("#send-to").fadeTo(1000, 0).hide();
        $("#file").fadeTo(1000, 1).show();
    });

});