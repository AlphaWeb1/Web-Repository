<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'transfer');
define('DB_USER', 'root');
define('DB_PASS', '');