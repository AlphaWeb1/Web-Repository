	<script src="js/jquery.min.js"></script>
  <script type="text/javascript" src="scripts/chat.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/main.js"></script>
	
	<script>
	 $().ready(function(){
          $("#to-reg").click(function(){
            $(".loginform").fadeTo(1000, 0).hide();
            $(".regform").fadeTo(1000, 1).show();
          });
          $("#to-login").click(function(){
            $(".regform").fadeTo(1000, 0).hide();
            $(".loginform").fadeTo(1000, 1).show();
          });
        });
	</script>



