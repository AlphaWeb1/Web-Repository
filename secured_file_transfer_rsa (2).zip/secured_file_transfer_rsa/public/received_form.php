<?php
require '../core/Db_connect.php';
$db = new Db_connect();
$encrypted_path = "encrypted_files/";
$decrypted_path = "decrypted_files/";

if (!file_exists("$decrypted_path$user/")) {
    mkdir("$decrypted_path$user/");
}
$thf['file_addr']=$_SESSION['curr_file'];
if (isset($_REQUEST['decrypt'])) {
    $flid = explode("_", $_REQUEST['received_files'])[0];
    $thefile = $db->get_results("SELECT * FROM `file_transfer` WHERE `receiver` = '$user' AND `id`='$flid';");
    foreach ($thefile as $thf) {
        
    };
//    delete();
    $newname = explode( ".",basename($encrypted_path . $thf['temp_name']))[0] . ".txt";
    rename($encrypted_path . $thf['temp_name'],$encrypted_path .$newname);
    $byteFile1 = file_get_contents($encrypted_path . $newname);
//    echo $byteFile1;
    $result = file_put_contents("$decrypted_path$user/".$thf['file_addr'] , $byteFile1);
    $_SESSION['curr_file']=$thf['file_addr'];
    unlink($encrypted_path.$newname);
    $db->query_db("DELETE FROM `file_transfer` WHERE `receiver`='$user' AND `id`='$flid';");
    ?>
    <div class="row">
        <div class="col-md-5 col-md-offset-3">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h4 class="panel-title">Download Received File</h4>
                </div>
                <div class="panel-body">
                    <ul class="list-group list-group-item-success">
    <?php echo '<li><a href="' . $decrypted_path . $user . "/" . $thf['file_addr'] . '?h=' . $decrypted_path . $user . "/" . $thf['file_addr']. '">' . $thf['file_addr'] . '</a></li>'; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <?php
}
if (isset($_REQUEST['h'])) {
    $_SESSION['curr_file']='';
//    unlink($_REQUEST['h']);
    echo '<div class="alert alert-success">
                <a class="close" data-dismiss="alert">x</a><h4>Success</h4>
                Decrypted File is Successfully Downloaded!!!</div>';
}
$files = $db->get_received_files($user);
?>
<form action="received.php" method="post">
    <div id="receiveds">
        <div class="col-md-5 col-md-offset-3">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h4 class="panel-title">Select File Decrypt and Download</h4>
                </div>
                <div class="panel-body">
                    <select class="form-control input-sm" name="received_files">
                            <?php foreach ($files as $fl): ?>
                            <option id="radio<?php echo $fl['id']; ?>" value="<?php echo $fl['id'] . "_" . $fl['temp_name']; ?>" >
                            <?php echo $fl['file_addr'] . " Sent By:" . $fl['sender']; ?>
                            </option>
                            <?php endforeach; ?>
                    </select>
                </div>
                <div class="panel-footer">
                    <button type="submit" class="btn btn-default btn-block"  name="decrypt" value="decrypt_me"><i class="fa fa-download" aria-hidden="true"></i>Decrypt</button>
                </div>
            </div>
        </div>
    </div>
</form>
