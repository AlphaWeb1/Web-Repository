<div class="brand clearfix">
    <a href="#" class="logo">
        <!--<img src="img/logo.jpg" class="img-responsive" alt="">-->
        <h5>Secured Online File Transfer (RSA Cypher)</h5>
    </a>
    <span class="menu-btn"><i class="fa fa-bars"></i></span>
    <ul class="ts-profile-nav">
        <li class="ts-account">
            <a href="#"><img src="img/ts-avatar.jpg" class="ts-avatar hidden-side" alt=""> Account <i class="fa fa-angle-down hidden-side"></i></a>
            <ul>
                <li><a href="#"><?php 
session_start();
                echo $_SESSION['username'];?></a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </li>
    </ul>
</div>

<div class="ts-main-content">
    <nav class="ts-sidebar">
        <ul class="ts-sidebar-menu">
            <li class="ts-label">Menu</li>
            <li class="open"><a href="send.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="transfer.php"><i class="fa fa-desktop"></i> Transfer File</a></li>
            <li><a href="received.php"><i class="fa fa-table"></i> Received File</a></li>
            <li><a href="profile.php"><i class="fa fa-edit"></i> Profile</a></li>
            <li><a href="logs.php"><i class="fa fa-pie-chart"></i> Logs</a></li>
            <li><a href="logout.php"><i class="fa fa-sitemap"></i> Sign Out</a></li>
        </ul>
    </nav>

    <div class="content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="page-title">Secure File Transfer System (RSA)</h2>