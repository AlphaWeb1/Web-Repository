<?php
session_start();

require_once __DIR__ . '/../../core/Db_connect.php';
if(isset($_POST['mail'])){
	$mail = $_POST['mail'];
	$pass = $_POST['paswd'];
	$username = $_POST['user'];
	$fname = $_POST['f'];
	$lname = $_POST['l'];

	$chat = new Db_connect();
	$user = $chat->add_users($mail,$pass,$username,$fname,$lname);
}

if(isset($_POST['u'])){
	$u = $_POST['u'];
	$p = $_POST['p'];

	$chat = new Db_connect();
	$user = $chat->login($u,$p);
}
