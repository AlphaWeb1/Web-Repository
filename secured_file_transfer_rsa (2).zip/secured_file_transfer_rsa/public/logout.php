<?php
session_start();

if($_SESSION['username']!==null){
	session_unset(); 
	session_destroy();
}
session_destroy();

header('location:index.php');
