<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('location:index.php');
}

require_once __DIR__ . '/../core/Db_connect.php';
$chat = new Db_connect();
$users = $chat->get_users();
$counts = $chat->get_sender();
$recev = $chat->get_receiver();
foreach ($counts as $key=> $count){
}
foreach ($recev as $key=> $rece){
}
?>
<?php require 'header.php'; ?>
<?php require 'dashheader.php'; ?>

<div class="row">
    <div class="col-md-5 col-md-offset-1">
        <div class="panel panel-default">
            <div class="panel-body bk-primary text-light">
                <div class="stat-panel text-center">
                    <div class="stat-panel-number h1 "><?php echo $count['sid']; ?></div>
                    <div class="stat-panel-title text-uppercase">Sent Files</div>
                </div>
            </div>
            <a href="logs.php?p=send" class="panel-footer block-anchor" >sent</a>
        </div>
    </div>
    <div class="col-md-5">
        <div class="panel panel-default">
            <div class="panel-body bk-success text-light">
                <div class="stat-panel text-center">
                    <div class="stat-panel-number h1 "><?php echo $rece['sid']; ?></div>
                    <div class="stat-panel-title text-uppercase">Received Files</div>
                </div>
            </div>
            <a href="logs.php?p=received" class="panel-footer block-anchor" >Received</a>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="well">
            <h2 class="text-info">How it works</h2>
            <p>Infograph here</p>
        </div>
    </div>
</div>

<?php require 'dashfooter.php'; ?>

<!-- Loading Scripts -->
<?php require 'footer.php'; ?>

</body>

</html>