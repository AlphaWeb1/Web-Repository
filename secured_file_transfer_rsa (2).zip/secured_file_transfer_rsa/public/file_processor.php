<?php
session_start();
// check if file is present in variable $_REQUEST['file'] and 
// user selected in variable $_REQUEST['recipient']
// if not return to transfer.php

require_once __DIR__ . '/../phpseclib-php5-master/phpseclib/Crypt/RSA.php';
require_once __DIR__ . '/../core/Db_connect.php';
$db = new Db_connect();
$encrypted_path = "encrypted_files/";
$decrypted_path = "decrypted_files/";
if (isset($_FILES['file'], $_REQUEST['recipient'])) {

    require 'header.php';
    require 'dashheader.php';
    $source_file = basename($_FILES['file']["name"]);
    $newName= $db->save_sent_file($_SESSION['username'], $source_file, $_REQUEST['recipient']);
//    echo "$newName $encrypted_path";
    if ($newName!==0) {
        $byteFile = convert_to_byte($_FILES['file']);
        $result = file_put_contents("$encrypted_path$newName",$byteFile);
        if ($result==FALSE) {
            echo '<div class="alert alert-warning">
                <a class="close" data-dismiss="alert">x</a><h4>Error</h4>
                Error Encrypting and Transferring File!!!
            </div>';
        }
        echo '<div class="alert alert-success">
                <a class="close" data-dismiss="alert">x</a><h4>Success</h4>
                Encryption and Transer is Successful!!!</div>';
    }

    require 'dashfooter.php';
    require 'footer.php';
} else {
    header("location:transfer.php?x=0");
}

function convert_to_byte($param) {
    return file_get_contents($param["tmp_name"]);
}

function save_file_to_dir($sourceFile, $target) {
    if (file_exists($target)) {
        return false;
    }
    return file_put_contents($target, $sourceFile);
}
