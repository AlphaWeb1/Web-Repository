<?php /* Smarty version Smarty-3.0.8, created on 2017-09-21 15:03:27
         compiled from "./sites/templates/signup_page.html" */ ?>
<?php /*%%SmartyHeaderCode:54659c3b89f95add6-39783829%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6477d67490503f7f376ed8219f2cd4d7b938ecc4' => 
    array (
      0 => './sites/templates/signup_page.html',
      1 => 1505594718,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '54659c3b89f95add6-39783829',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<div id="content" class="row">
    <script type="text/javascript">
    $(document).on('change','#country, #state, #PME_data_nationality',function(){
        this.form.submit();
   });
    </script>
    <hr/><br class="well-sm"/><br class="well-sm"/>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-primary">
                <div class="panel-heading bg-info text-danger"><h3>---- <span class="glyphicon glyphicon-pencil"></span> Sign Up Details ----</h3></div>
                <form method="post" action="?p=signup_page#signup" enctype="multipart/form-data">
                    <div class="panel-body">
                        <h4>--Personal Profile--</h4><br/>
                        <label for="profile_pic">Profile Photo:</label><input type="file" class="form-control input-lg" required name="pic" id="profile_pic"/><br/>
                        <label for="firstname">First Name:</label><input type="text" class="form-control input-lg" required name="first" value="<?php echo $_smarty_tpl->getVariable('vars')->value['first'];?>
" id="firstname"/><br/>
                        <label for="othernames">Other Names:</label><input type="text" class="form-control input-lg" required name="others" value="<?php echo $_smarty_tpl->getVariable('vars')->value['others'];?>
" id="othernames"/><br/>
                        <label for="phone">Phone N<u>o</u>:</label><input type="tel" class="form-control input-lg" required name="phone" value="<?php echo $_smarty_tpl->getVariable('vars')->value['phone'];?>
" id="phone"/><br/>
                        <label for="email">Email:</label><input type="email" class="form-control input-lg" required name="email" value="<?php echo $_smarty_tpl->getVariable('vars')->value['email'];?>
" id="email"/><br/>
                        <label for="address">Residential Address:</label>
                        <textarea class="form-control input-lg" required rows="3" name="address" id="address"><?php echo $_smarty_tpl->getVariable('vars')->value['address'];?>
</textarea><br/>
                        <label for="gender">Gender:</label><select class="form-control input-lg" name="gender" required id="gender">
                            <option value="female" <?php if ($_smarty_tpl->getVariable('vars')->value['gender']=='female'){?> selected <?php }?>>Female</option>
                            <option value="male" <?php if ($_smarty_tpl->getVariable('vars')->value['gender']=='male'){?> selected <?php }?>>Male</option>
                        </select><hr/>
                        <label for="country">Country:</label><select class="form-control input-lg" name="country" required id="country">
                            <?php if (isset($_smarty_tpl->getVariable('countries',null,true,false)->value)&&count($_smarty_tpl->getVariable('countries')->value)>0){?>
                            <?php  $_smarty_tpl->tpl_vars['country'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('countries')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['country']->key => $_smarty_tpl->tpl_vars['country']->value){
?>
                            <option value="<?php echo $_smarty_tpl->getVariable('country')->value->name;?>
" <?php if ($_smarty_tpl->getVariable('selected')->value['country']==$_smarty_tpl->getVariable('country')->value->name){?> selected <?php }?>>
                                    <?php echo $_smarty_tpl->getVariable('country')->value->name;?>
</option>
                            <?php }} ?>
                            <?php }else{ ?><option value=""></option>
                            <?php }?>
                        </select><hr/>
                        <label for="state">State of Origin:</label><select class="form-control input-lg" name="state" required id="state">
                            <?php if (isset($_smarty_tpl->getVariable('states',null,true,false)->value)&&count($_smarty_tpl->getVariable('states')->value)>0){?>
                            <?php  $_smarty_tpl->tpl_vars['state'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('states')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['state']->key => $_smarty_tpl->tpl_vars['state']->value){
?>
                            <option value="<?php echo $_smarty_tpl->getVariable('state')->value->name;?>
" <?php if ($_smarty_tpl->getVariable('selected')->value['state']==$_smarty_tpl->getVariable('state')->value->name){?> selected <?php }?>>
                                    <?php echo $_smarty_tpl->getVariable('state')->value->name;?>
</option>
                            <?php }} ?>
                            <?php }else{ ?><option value=""></option>
                            <?php }?>
                        </select><hr/>
                        <label for="city">City :</label><select class="form-control input-lg" name="city" required id="city">
                            <?php if (isset($_smarty_tpl->getVariable('cities',null,true,false)->value)&&$_smarty_tpl->getVariable('cities')->value!=null){?>
                            <?php  $_smarty_tpl->tpl_vars['city'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('cities')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['city']->key => $_smarty_tpl->tpl_vars['city']->value){
?>
                            <option value="<?php echo $_smarty_tpl->getVariable('city')->value->name;?>
" <?php if ($_smarty_tpl->getVariable('selected')->value['city']==$_smarty_tpl->getVariable('city')->value->name){?> selected <?php }?>>
                                    <?php echo $_smarty_tpl->getVariable('city')->value->name;?>
</option>
                            <?php }} ?>
                            <?php }else{ ?><option value=""></option>
                            <?php }?>
                        </select><hr/>
                        <h4>--Security Profile--</h4><br/><input type="hidden" name="utype" value=""/>
                        <label for="username">User ID/ Username:</label><input type="text" class="form-control input-lg" required name="username" value="<?php echo $_smarty_tpl->getVariable('vars')->value['user'];?>
" id="username"/><br/>
                        <label for="password">Password:</label><input type="text" class="form-control input-lg" required name="pass" value="<?php echo $_smarty_tpl->getVariable('vars')->value['pass'];?>
" id="password"/><br/>
                        <label for="cpassword">Confirm Password:</label><input type="text" class="form-control input-lg" required name="cpass" value="<?php echo $_smarty_tpl->getVariable('vars')->value['cpass'];?>
" id="cpassword"/><br/>
                        <label for="imgcat">Signup As:</label><select class="form-control input-lg" name="utype" required id="imgcat">
                            <option value="0" <?php if ($_smarty_tpl->getVariable('vars')->value['type']=='0'){?> selected <?php }?>>Consult</option>
                            <option value="1" <?php if ($_smarty_tpl->getVariable('vars')->value['type']=='1'){?> selected <?php }?>>Medical Expert</option>
                        </select><hr/>
                    </div>
                    <div class="panel-footer center">
                        <a href="?p=home" class="btn btn-lg btn-info">-- <span class="glyphicon glyphicon-home"></span> Home --</a>
                        <button class="btn btn-lg btn-primary" name="signup" value="signup" type="submit">-- <span class="glyphicon glyphicon-registration-mark"></span> Sign-Up --</button>
                    </div>
                </form>
            </div>
            <br class="well-sm"/>
            <a name="signup"><div class="col-md-10 col-md-offset-1 text-center"><?php $_template = new Smarty_Internal_Template("msg_display.html", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?><br class="well-sm"/><hr/><br class="well-sm"/></div></a>
        </div>
    </div>
</div>

