<?php /* Smarty version Smarty-3.0.8, created on 2017-09-18 00:20:22
         compiled from "./sites/templates/documents.html" */ ?>
<?php /*%%SmartyHeaderCode:436059bef526d2ef00-09199791%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '58d9bdeaaac87175caa307738452eacd78fa3533' => 
    array (
      0 => './sites/templates/documents.html',
      1 => 1505685540,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '436059bef526d2ef00-09199791',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
