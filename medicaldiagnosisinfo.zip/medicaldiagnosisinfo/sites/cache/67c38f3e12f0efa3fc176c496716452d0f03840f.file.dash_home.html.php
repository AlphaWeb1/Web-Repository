<?php /* Smarty version Smarty-3.0.8, created on 2017-09-18 10:22:10
         compiled from "./sites/templates/dash_home.html" */ ?>
<?php /*%%SmartyHeaderCode:2348959bf8232a71451-35988497%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '67c38f3e12f0efa3fc176c496716452d0f03840f' => 
    array (
      0 => './sites/templates/dash_home.html',
      1 => 1505686787,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2348959bf8232a71451-35988497',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
