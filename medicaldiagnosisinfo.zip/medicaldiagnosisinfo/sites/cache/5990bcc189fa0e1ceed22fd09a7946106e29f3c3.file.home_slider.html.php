<?php /* Smarty version Smarty-3.0.8, created on 2017-09-24 13:33:11
         compiled from "./sites/templates/home_slider.html" */ ?>
<?php /*%%SmartyHeaderCode:1412259c797f7ebc475-55969692%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5990bcc189fa0e1ceed22fd09a7946106e29f3c3' => 
    array (
      0 => './sites/templates/home_slider.html',
      1 => 1506252759,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1412259c797f7ebc475-55969692',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<div class="col-md-10 col-md-offset-1">
    <section id="main">
        <div class="carousel">
            <div id="myCarousel" class="carousel slide" data-interval="4000">
                <ol class="carousel-indicators indicate">
                    <li data-slide-to="0" data-target="#myCarousel" class="active"></li>
                    <li data-slide-to="1" data-target="#myCarousel"></li>
                    <li data-slide-to="2" data-target="#myCarousel"></li>
                    <li data-slide-to="3" data-target="#myCarousel"></li>
                    <li data-slide-to="4" data-target="#myCarousel"></li>
                    <li data-slide-to="5" data-target="#myCarousel"></li>
                    <li data-slide-to="6" data-target="#myCarousel"></li>
                    <li data-slide-to="7" data-target="#myCarousel"></li>
                </ol>
                <div class="carousel-inner">
                    <div class="item active">
                        <img src="<?php echo $_smarty_tpl->getVariable('lib_dir')->value;?>
/i/slides/banner.jpg" alt="Blogs" class="carousel-image" 
                             style="width: 100%; height: 350px;"/>
                        <div class="carousel-caption">
                            <h4 class="title-slide"><span class="fa fa-info-circle"></span> Medical Information System</h4>
                            <p class="desc-slide">Have access to medical blogs</p>
                        </div>
                    </div>
                    <div class="item">
                        <img src="<?php echo $_smarty_tpl->getVariable('lib_dir')->value;?>
/i/slides/banner2.jpg" alt="Manage Blogs" class="carousel-image"
                             style="width: 100%; height: 350px;"/>
                        <div class="carousel-caption">
                            <h4 class="title-slide"><span class="fa fa-newspaper-o"></span> Medical Information System</h4>
                            <p class="desc-slide">Contribute to online blogging and research</p>
                        </div>
                    </div>
                    <div class="item">
                        <img src="<?php echo $_smarty_tpl->getVariable('lib_dir')->value;?>
/i/slides/banner3.jpg" alt="Medican Diagnosis" class="carousel-image"
                             style="width: 100%; height: 350px;"/>
                        <div class="carousel-caption">
                            <h4 class="title-slide"><span class="fa fa-hospital-o"></span> Medical Information System</h4>
                            <p class="desc-slide">Perform easy medical diagnosis</p>
                        </div>
                    </div>
                    <div class="item">
                        <img  src="<?php echo $_smarty_tpl->getVariable('lib_dir')->value;?>
/i/slides/banner4.jpg" alt="Medical Search" class="carousel-image"
                              style="width: 100%; height: 350px;"/>
                        <div class="carousel-caption">
                            <h4 class="title-slide"><span class="glyphicon glyphicon-search"></span> Medical Information System</h4>
                            <p class="desc-slide">Search for medical related information online</p>
                        </div>
                    </div>
                    <div class="item">
                        <img src="<?php echo $_smarty_tpl->getVariable('lib_dir')->value;?>
/i/slides/banner5.jpg" alt="Medical Documentation" class="carousel-image"
                             style="width: 100%; height: 350px;"/>
                        <div class="carousel-caption">
                            <h4 class="title-slide"><span class="glyphicon glyphicon-book"></span> Medical Information System</h4>
                            <p class="desc-slide">Have access to medical books</p>
                        </div>
                    </div>
                    <div class="item">
                        <img src="<?php echo $_smarty_tpl->getVariable('lib_dir')->value;?>
/i/slides/banner6.jpg" alt="Medical Documentation" class="carousel-image"
                             style="width: 100%; height: 350px;"/>
                        <div class="carousel-caption">
                            <h4 class="title-slide"><span class="fa fa-book"></span> Medical Information System</h4>
                            <p class="desc-slide">Provide support to online medical research by uploading of medical documentations</p>
                        </div>
                    </div>
                    <div class="item">
                        <img src="<?php echo $_smarty_tpl->getVariable('lib_dir')->value;?>
/i/slides/banner7.jpg" alt="First Aid" class="carousel-image"
                             style="width: 100%; height: 350px;"/>
                        <div class="carousel-caption">
                            <h4 class="title-slide"><span class="glyphicon glyphicon-book"></span> Medical Information System</h4>
                            <p class="desc-slide">Have access to the first aid knowledge in medicine</p>
                        </div>
                    </div>
                    <div class="item">
                        <img  src="<?php echo $_smarty_tpl->getVariable('lib_dir')->value;?>
/i/slides/banner8.jpg" alt="Medical Support" class="carousel-image"
                              style="width: 100%; height: 350px;"/>
                        <div class="carousel-caption">
                            <h4 class="title-slide"><span class="glyphicon glyphicon-open"></span> Medical Information System</h4>
                            <p class="desc-slide">Add Diagnosis procedure online for support of self diagnoses</p>
                        </div>
                    </div>
                </div>
                <a class="left carousel-control" data-slide="prev" href="#myCarousel"><span class=""></span></a>
                <a class="right carousel-control" data-slide="next" href="#myCarousel"><span class=""></span></a>

            </div>
        </div>
    </section>
    <br class="well-sm"/>
</div><!--end carousel-->                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     