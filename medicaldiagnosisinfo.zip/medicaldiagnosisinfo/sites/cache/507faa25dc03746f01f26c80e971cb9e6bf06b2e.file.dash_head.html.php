<?php /* Smarty version Smarty-3.0.8, created on 2017-09-18 10:32:51
         compiled from "./sites/templates/dash_head.html" */ ?>
<?php /*%%SmartyHeaderCode:2473759bf84b3533cb4-38854575%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '507faa25dc03746f01f26c80e971cb9e6bf06b2e' => 
    array (
      0 => './sites/templates/dash_head.html',
      1 => 1505723563,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2473759bf84b3533cb4-38854575',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<script type="text/javascript">
    function pic_upload(file_id,img_id){
    var preview="";
    $(file_id).change(function (){
       var type_allowed = "image/jpeg,image/jpg,image/png,image/gif";

    if (this.files && this.files[0]) {
    fr = new FileReader();
    fr.readAsDataURL(this.files[0]);
    fr.onload = function (e) {
        preview = e.target.result;
        type = preview.substring(5, preview.indexOf(";"));
        if (type_allowed.indexOf(type) < 0) {
            alert('Unsupported file type');
       } else {
            $(img_id).attr("src",preview);
        }
    }} 
    });
    }
</script>
<div class="btn-group">
 <?php if ($_smarty_tpl->getVariable('t')->value!='search'){?><li><a class="btn btn-danger navbar-btn btn-block" href="?p=dashboard&amp;t=search">
    <span class="glyphicon glyphicon-search"></span> Search</a></li><?php }?>
</div>
<div class="btn-group">
    <button type="button" class="btn dropdown-toggle navbar-btn" data-toggle="dropdown">
        <span class="glyphicon glyphicon-user"></span>
        <span class="caret"></span>
    </button>
    <ul class="dropdown-menu">
        <li class="text-capitalize text-primary"><strong><?php echo $_smarty_tpl->getVariable('user_names')->value;?>
</strong></li>
        <li><a href="?PME_sys_fl=0&PME_sys_fm=0&PME_sys_sfn[0]=0&p=dashboard&amp;t=profile&PME_sys_operation=PME_op_View&PME_sys_rec=<?php echo $_smarty_tpl->getVariable('uid')->value;?>
"><span class="glyphicon glyphicon-book"></span> My Profiles</a></li>
        <li><a href="?PME_sys_fl=0&PME_sys_fm=0&PME_sys_sfn[0]=0&p=dashboard&amp;t=security&PME_sys_operation=PME_op_View&PME_sys_rec=<?php echo $_smarty_tpl->getVariable('uid')->value;?>
"><span class="glyphicon glyphicon-lock"></span> Security Profile</a></li>
        <li><a href="?p=logout" class="bg-success"><span class="glyphicon glyphicon-log-out"></span> Logout.</a></li>
    </ul>
</div>