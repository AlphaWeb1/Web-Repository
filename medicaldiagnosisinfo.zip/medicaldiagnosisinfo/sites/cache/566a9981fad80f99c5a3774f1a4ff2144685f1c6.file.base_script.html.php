<?php /* Smarty version Smarty-3.0.8, created on 2017-08-29 07:30:46
         compiled from "./sites/templates/base_script.html" */ ?>
<?php /*%%SmartyHeaderCode:835259a4fc06287896-75983650%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '566a9981fad80f99c5a3774f1a4ff2144685f1c6' => 
    array (
      0 => './sites/templates/base_script.html',
      1 => 1501588464,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '835259a4fc06287896-75983650',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<!--<script type="text/javascript" src="public/sub_public/slick/slick.min.js"></script>-->
<script type="text/javascript" src="<?php echo $_smarty_tpl->getVariable('lib_dir')->value;?>
/<?php echo $_smarty_tpl->getVariable('public_dir')->value;?>
/libs/jquery/jquery2.1.3.min.js"></script>
<script type="text/javascript" src="<?php echo $_smarty_tpl->getVariable('lib_dir')->value;?>
/<?php echo $_smarty_tpl->getVariable('public_dir')->value;?>
/libs/jquery/jquery-ui.min.js"></script>
<!--<script type="text/javascript" src="-{$lib_dir}-/-{$public_dir}-/libs/jquery/jquery.plugin.js"></script>-->
<!--<script type="text/javascript" src="-{$lib_dir}-/-{$public_dir}-/libs/jquery/jquery.datepick.js"></script>-->
<script type="text/javascript" src="<?php echo $_smarty_tpl->getVariable('lib_dir')->value;?>
/<?php echo $_smarty_tpl->getVariable('public_dir')->value;?>
/libs/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo $_smarty_tpl->getVariable('lib_dir')->value;?>
/<?php echo $_smarty_tpl->getVariable('public_dir')->value;?>
/libs/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript" src="<?php echo $_smarty_tpl->getVariable('lib_dir')->value;?>
/<?php echo $_smarty_tpl->getVariable('public_dir')->value;?>
/js/script.js"></script>