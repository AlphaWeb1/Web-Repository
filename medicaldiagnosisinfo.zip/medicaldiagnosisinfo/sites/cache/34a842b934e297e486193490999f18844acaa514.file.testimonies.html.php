<?php /* Smarty version Smarty-3.0.8, created on 2017-09-17 20:56:59
         compiled from "./sites/templates/testimonies.html" */ ?>
<?php /*%%SmartyHeaderCode:1351559bec57b0d9933-95338533%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '34a842b934e297e486193490999f18844acaa514' => 
    array (
      0 => './sites/templates/testimonies.html',
      1 => 1505673084,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1351559bec57b0d9933-95338533',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>

