<?php /* Smarty version Smarty-3.0.8, created on 2017-09-19 23:06:12
         compiled from "./sites/templates/nav_controls.html" */ ?>
<?php /*%%SmartyHeaderCode:2567459c186c43528d4-68587832%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '314454125bcaa492d10f07234e0890902dbd4b8c' => 
    array (
      0 => './sites/templates/nav_controls.html',
      1 => 1502535880,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2567459c186c43528d4-68587832',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<input type="hidden" name="rl" value="<?php echo $_smarty_tpl->getVariable('nav_conts')->value['rl'];?>
">
<input type="hidden" name="pn" value="<?php echo $_smarty_tpl->getVariable('nav_conts')->value['pn'];?>
">
<input type="hidden" name="nxtrec" value="<?php echo $_smarty_tpl->getVariable('nav_conts')->value['nr'];?>
">
<input type="hidden" name="prerec" value="<?php echo $_smarty_tpl->getVariable('nav_conts')->value['pr'];?>
">
<button class="btn btn-success btn-sm" name="prev" <?php if ($_smarty_tpl->getVariable('nav_conts')->value['nr']==$_smarty_tpl->getVariable('nav_conts')->value['lmt']){?> disabled <?php }?>>&lt;</button>
<button class="btn btn-success btn-sm" name="prev_start" <?php if ($_smarty_tpl->getVariable('nav_conts')->value['nr']==$_smarty_tpl->getVariable('nav_conts')->value['lmt']){?> disabled <?php }?>>&lt;&lt;</button>
&nbsp;<span class="span-danger"><?php echo $_smarty_tpl->getVariable('nav_conts')->value['pn'];?>
</span>&nbsp;
<button class="btn btn-success btn-sm" name="next_end" <?php if ($_smarty_tpl->getVariable('nav_conts')->value['rl']<=$_smarty_tpl->getVariable('nav_conts')->value['lmt']){?> disabled <?php }?>>&gt;&gt;</button>
<button class="btn btn-success btn-sm" name="next" <?php if ($_smarty_tpl->getVariable('nav_conts')->value['rl']<=$_smarty_tpl->getVariable('nav_conts')->value['lmt']){?> disabled <?php }?>>&gt;</button> Record(s): <?php echo $_smarty_tpl->getVariable('nav_conts')->value['total'];?>
, Page(s): <?php echo $_smarty_tpl->getVariable('nav_conts')->value['pages'];?>
