<?php /* Smarty version Smarty-3.0.8, created on 2017-09-15 10:25:45
         compiled from "./sites/templates/page_title.html" */ ?>
<?php /*%%SmartyHeaderCode:923359bb8e898ff888-43583578%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '625493614524ea49791ad87be0929f8915c39c23' => 
    array (
      0 => './sites/templates/page_title.html',
      1 => 1505463804,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '923359bb8e898ff888-43583578',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<title>Medical Information Systems: <?php echo $_smarty_tpl->getVariable('title')->value;?>
</title>
<meta charset="UTF-8">
</head>
<body>

