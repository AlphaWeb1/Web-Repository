<?php /* Smarty version Smarty-3.0.8, created on 2017-09-21 23:46:17
         compiled from "./sites/templates/testimony_info.html" */ ?>
<?php /*%%SmartyHeaderCode:2412159c43329e898c8-99492209%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '035613348d0d1fb14abb3dec2e657f7602815239' => 
    array (
      0 => './sites/templates/testimony_info.html',
      1 => 1506018234,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2412159c43329e898c8-99492209',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<div class="row" id="ratings">
    <div class="col-md-10 col-md-offset-1">
        <div class="col-md-12"><div class="panel-heading bg-info"><h2>Testimonies</h2></div></div>
        <div class="panel ">
            <div class="panel-body text-justify">
            <?php if (isset($_smarty_tpl->getVariable('testi',null,true,false)->value)&&$_smarty_tpl->getVariable('testi')->value!=null){?> <?php  $_smarty_tpl->tpl_vars['recs'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('testi')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['recs']->key => $_smarty_tpl->tpl_vars['recs']->value){
?>
            <div class="panel col-lg-4 ">
            <br><div class="form-group text-center"><label for="blog_pix">
            <img class="img img-thumbnail" style="width:100px; heignt:100px;" id="b_img" src="<?php echo $_smarty_tpl->getVariable('lib_dir')->value;?>
/i/pr/<?php echo $_smarty_tpl->getVariable('recs')->value->profile_pic;?>
"/>
                </label></div>
            <div class="pme-main">
            <div class="form-group pme-row-0"><label class="control-label">Sender: </label><?php echo $_smarty_tpl->getVariable('recs')->value->firstname;?>
 <?php echo $_smarty_tpl->getVariable('recs')->value->othernames;?>

            </div>
            <div class="form-group pme-row-1"><label class="control-label">Heading: </label><?php echo $_smarty_tpl->getVariable('recs')->value->title;?>
</div>
            <div class="form-group pme-row-0"><label class="control-label">Comment: </label><div class="pme-value-0"><?php echo $_smarty_tpl->getVariable('recs')->value->content;?>
</div>
            </div>
            <div class="form-group pme-row-1"><label class="control-label">Date Sent: </label><?php echo $_smarty_tpl->getVariable('recs')->value->date_added;?>
</div>
            </div>
            </div>
           <div class="col-sm-12 form-group"><a href="?p=testimonies&PME_sys_operation=PME_op_List" class="btn btn-primary">
               <span class="fa fa-commenting"></span> More Comments...</a>
           </div>
            <?php }} ?>
            <?php }else{ ?><div class="col-md-8 col-md-offset-2 text-center"><?php $_template = new Smarty_Internal_Template("msg1_display.xhtml", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?></div><?php }?>
            </div><!--end panel-body-->
        </div>
    </div><!--end panel-->
</div><!--end row-->