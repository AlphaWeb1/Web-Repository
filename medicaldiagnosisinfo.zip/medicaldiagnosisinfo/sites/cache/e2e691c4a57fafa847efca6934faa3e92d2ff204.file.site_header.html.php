<?php /* Smarty version Smarty-3.0.8, created on 2017-09-17 14:24:52
         compiled from "./sites/templates/site_header.html" */ ?>
<?php /*%%SmartyHeaderCode:796459be6994582e57-38738892%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e2e691c4a57fafa847efca6934faa3e92d2ff204' => 
    array (
      0 => './sites/templates/site_header.html',
      1 => 1505651051,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '796459be6994582e57-38738892',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php $_template = new Smarty_Internal_Template("page_title.html", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?>
<div class="row">
    <div id="dash-top">
        <nav class="navbar bg-primary navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle btn-info collapsed" data-toggle="collapse" data-target="#collapse">
                        <span class="sr-only">Site Navigator</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <div class="navbar-brand logo-div">
                        <a href="?p=<?php if (isset($_smarty_tpl->getVariable('user',null,true,false)->value)){?>dashboard&t=home<?php }else{ ?>home<?php }?>"><b class="text-danger text-capitalize h1">Medical Information Systems</b></a>
                    </div><!--end navbar-brand-->
                </div><!--end navbar-header-->
                <div class="navbar-collapse collapse" id="collapse">
                    <div class="nav navbar-nav bg-primary navbar-right">
                        <?php if (isset($_smarty_tpl->getVariable('user',null,true,false)->value)){?>
                        <?php $_template = new Smarty_Internal_Template("dash_head.html", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?>
                        <?php }else{ ?>
                        <?php $_template = new Smarty_Internal_Template("home_head.html", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?>
                        <?php }?>    
                    </div>
                </div>
            </div><!--end container-->
        </nav><!--end nav-->
    </div><!--end dash-top-->
</div>

