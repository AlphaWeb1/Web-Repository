<?php /* Smarty version Smarty-3.0.8, created on 2017-09-19 17:46:32
         compiled from "./sites/templates/diagnosis.html" */ ?>
<?php /*%%SmartyHeaderCode:1458259c13bd88621d3-20983224%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f586ae11d45da64cb441a32e214f6dbbc95f0793' => 
    array (
      0 => './sites/templates/diagnosis.html',
      1 => 1505833975,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1458259c13bd88621d3-20983224',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
