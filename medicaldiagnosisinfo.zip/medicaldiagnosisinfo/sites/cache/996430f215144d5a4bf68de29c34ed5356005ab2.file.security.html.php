<?php /* Smarty version Smarty-3.0.8, created on 2017-09-16 22:43:30
         compiled from "./sites/templates/security.html" */ ?>
<?php /*%%SmartyHeaderCode:2569059bd8cf213bd40-06891012%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '996430f215144d5a4bf68de29c34ed5356005ab2' => 
    array (
      0 => './sites/templates/security.html',
      1 => 1502174597,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2569059bd8cf213bd40-06891012',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
