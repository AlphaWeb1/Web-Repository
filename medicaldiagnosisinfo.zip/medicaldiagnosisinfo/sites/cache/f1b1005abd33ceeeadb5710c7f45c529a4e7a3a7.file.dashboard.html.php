<?php /* Smarty version Smarty-3.0.8, created on 2017-09-16 23:09:04
         compiled from "./sites/templates/dashboard.html" */ ?>
<?php /*%%SmartyHeaderCode:2090859bd92f0770ad4-51507027%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f1b1005abd33ceeeadb5710c7f45c529a4e7a3a7' => 
    array (
      0 => './sites/templates/dashboard.html',
      1 => 1505596140,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2090859bd92f0770ad4-51507027',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<div id="content" class="row bg-primary head_break">
    <div class="col-sm-2 bg-info text-justify text-capitalize head_break" id="side-menu">
    <?php $_template = new Smarty_Internal_Template("dash_menu.html", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?>
    </div>
    <div class="col-sm-10 text-justify text-capitalize" style="background-color: #fff; color: #000;">