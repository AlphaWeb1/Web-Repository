<?php /* Smarty version Smarty-3.0.8, created on 2017-09-26 07:03:42
         compiled from "./sites/templates/dash_menu.html" */ ?>
<?php /*%%SmartyHeaderCode:2980959c9dfaee10601-92840872%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '92c0de35bc175690846f30e7900c3b7f05d29a3d' => 
    array (
      0 => './sites/templates/dash_menu.html',
      1 => 1506402218,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2980959c9dfaee10601-92840872',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<h4 class=""><u>&nbsp;</u></h4>
<div id="menu-nav">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false">
            <span class="sr-only"><!--{$Site.title}--> navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
    </div><!--end navbar-header-->

    <div class="collapse navbar-collapse" id="navbar-collapse" aria-expanded="false">
        <aside>
            <ul>
                <li>
                    <a href="?PME_sys_fl=0&PME_sys_fm=0&PME_sys_sfn[0]=0&p=dashboard&t=profile&PME_sys_operation=PME_op_View&PME_sys_rec=<?php echo $_smarty_tpl->getVariable('uid')->value;?>
">
                        <p>&nbsp;</p>
                        <h5><span class="fa fa-user"></span> Personal Profile</h5>
                    </a>
                </li>
                <li>
                    <a href="?PME_sys_fl=0&PME_sys_fm=0&PME_sys_sfn[0]=0&p=dashboard&amp;t=security&PME_sys_operation=PME_op_View&PME_sys_rec=<?php echo $_smarty_tpl->getVariable('uid')->value;?>
"><p>&nbsp;</p>
                        <h5><span class="fa fa-lock"></span> Security Profile</h5>
                    </a>
                </li>
                <li>
                    <a href="?p=dashboard&t=blogs"><p>&nbsp;</p>
                        <h5><span class="glyphicon glyphicon-edit"></span> Blogs.</h5>
                    </a>
                </li>
                <li>
                    <a href="?p=dashboard&t=search"><p>&nbsp;</p>
                        <h5><span class="fa fa-search"></span> Search</h5>
                    </a>
                </li>
                <li>
                    <a href="?p=dashboard&t=documents"><p>&nbsp;</p>
                        <h5><span class="fa fa-book"></span> Medical Documents &amp; Books</h5>
                    </a>
                </li>
                <li>
                    <a href="?p=dashboard&t=diagnose"><p>&nbsp;</p>
                        <h5><span class="fa fa-newspaper-o"></span> <span class="fa fa-ambulance"></span> Diagnose</h5>
                    </a>
                </li>
                <?php if ($_smarty_tpl->getVariable('tpe')->value==1){?><li>
                    <a href="?p=dashboard&t=diagnosis"><p>&nbsp;</p>
                        <h5><span class="fa fa-hospital-o"></span><span class="fa fa-user-md"></span> Manage Diagnosis</h5>
                    </a>
                </li><?php }?>
                <li>
                    <a href="?p=dashboard&t=testimonies"><p>&nbsp;</p>
                        <h5><span class="fa fa-feed"></span> Testimonies</h5>
                    </a>
                </li>
                <li>
                    <a href="?p=logout"><p>&nbsp;</p>
                        <h5><span class="fa fa-sign-out"></span> Sign Out</h5>
                    </a>
                </li>
                <li>  <p>&nbsp;</p>  <p>&nbsp;</p>
                </li>
            </ul>
        </aside>
    </div><!--end navbar-collapse-->
</div><!--end container-fluid-->