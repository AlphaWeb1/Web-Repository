<?php /* Smarty version Smarty-3.0.8, created on 2017-09-17 14:34:39
         compiled from "./sites/templates/blogs.html" */ ?>
<?php /*%%SmartyHeaderCode:3050159be6bdf4fc279-89625074%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd8d3036f0ceea10164ecc6f79d54eb4cd0305640' => 
    array (
      0 => './sites/templates/blogs.html',
      1 => 1505650014,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3050159be6bdf4fc279-89625074',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
