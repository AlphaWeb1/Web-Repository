<?php /* Smarty version Smarty-3.0.8, created on 2017-08-29 07:30:47
         compiled from "./sites/templates/msg_display.html" */ ?>
<?php /*%%SmartyHeaderCode:2552859a4fc0750c945-18170912%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2a30756e9f4e498bacc7a5e033e5d36f13beaf5c' => 
    array (
      0 => './sites/templates/msg_display.html',
      1 => 1501976935,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2552859a4fc0750c945-18170912',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (isset($_smarty_tpl->getVariable('msg',null,true,false)->value)){?>
<div>
<div class="alert alert-<?php echo $_smarty_tpl->getVariable('msg')->value['type'];?>
">
<?php if (isset($_smarty_tpl->getVariable('msg',null,true,false)->value['close'])&&$_smarty_tpl->getVariable('msg')->value['close']=='true'){?>
<a class="close" data-dismiss="alert">x</a>
<?php }?>
<?php if (isset($_smarty_tpl->getVariable('msg',null,true,false)->value['title'])){?>
<h4 class="alert-heading"><?php echo $_smarty_tpl->getVariable('msg')->value['title'];?>
</h4>
<?php }?>
<?php echo $_smarty_tpl->getVariable('msg')->value['content'];?>

<?php if (isset($_smarty_tpl->getVariable('msg',null,true,false)->value['btn_text'])){?>
<br/>
<a href="<?php echo $_smarty_tpl->getVariable('msg')->value['url'];?>
" class="btn btn-<?php echo $_smarty_tpl->getVariable('msg')->value['btn_type'];?>
 btn-<?php echo $_smarty_tpl->getVariable('msg')->value['size'];?>
"><?php echo $_smarty_tpl->getVariable('msg')->value['btn_text'];?>
</a>
<?php }?>
</div>
</div>
<?php }?>