<?php /* Smarty version Smarty-3.0.8, created on 2017-09-16 12:27:22
         compiled from "./sites/templates/dash_main.html" */ ?>
<?php /*%%SmartyHeaderCode:3073859bcfc8aeced74-86235901%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd1b4cdc4065bb66cfe65a0e73ae9cc2c99a12c98' => 
    array (
      0 => './sites/templates/dash_main.html',
      1 => 1501980800,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3073859bcfc8aeced74-86235901',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
    <?php if (isset($_smarty_tpl->getVariable('t_file',null,true,false)->value)){?>
    <?php $_template = new Smarty_Internal_Template($_smarty_tpl->getVariable('t_file')->value, $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?>
    <?php }?>
    </div>
</div>