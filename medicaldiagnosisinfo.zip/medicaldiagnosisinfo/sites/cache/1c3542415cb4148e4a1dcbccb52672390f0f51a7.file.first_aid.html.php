<?php /* Smarty version Smarty-3.0.8, created on 2017-09-18 23:48:55
         compiled from "./sites/templates/first_aid.html" */ ?>
<?php /*%%SmartyHeaderCode:463459c03f47110818-70683953%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1c3542415cb4148e4a1dcbccb52672390f0f51a7' => 
    array (
      0 => './sites/templates/first_aid.html',
      1 => 1505771329,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '463459c03f47110818-70683953',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
