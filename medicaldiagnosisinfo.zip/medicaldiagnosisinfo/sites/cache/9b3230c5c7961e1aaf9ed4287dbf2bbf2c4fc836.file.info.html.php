<?php /* Smarty version Smarty-3.0.8, created on 2017-09-15 10:03:49
         compiled from "./sites/templates/info.html" */ ?>
<?php /*%%SmartyHeaderCode:425159bb8965e81900-41155372%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9b3230c5c7961e1aaf9ed4287dbf2bbf2c4fc836' => 
    array (
      0 => './sites/templates/info.html',
      1 => 1505462625,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '425159bb8965e81900-41155372',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<div class="row" id="ratings">
    <div class="col-md-10 col-md-offset-1">
        <div class="col-md-12"><div class="panel-heading bg-info"><h2>Blogs</h2></div></div>
        <div class="panel ">
            <div class="panel-body text-justify">
                <h4><img alt="consult" style="width: 100px; height: 100px !important;"  class="comp-logo-fly" src="<?php echo $_smarty_tpl->getVariable('lib_dir')->value;?>
/i/ic/rector.jpg" title="rector's photo">
                school news feeds.</h4>
            </div><!--end panel-body-->
        </div>
    </div><!--end panel-->
</div><!--end row-->