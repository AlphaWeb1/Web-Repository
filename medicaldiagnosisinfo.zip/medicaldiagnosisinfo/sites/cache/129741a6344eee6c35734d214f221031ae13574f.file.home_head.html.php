<?php /* Smarty version Smarty-3.0.8, created on 2017-09-15 09:54:23
         compiled from "./sites/templates/home_head.html" */ ?>
<?php /*%%SmartyHeaderCode:596659bb872f00c255-10082613%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '129741a6344eee6c35734d214f221031ae13574f' => 
    array (
      0 => './sites/templates/home_head.html',
      1 => 1505462053,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '596659bb872f00c255-10082613',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<ul class="list-inline">
    <?php if ($_smarty_tpl->getVariable('p')->value!='signup'){?><li><a href="?p=signup_page" class="btn btn-danger btn-lg btn-block navbar-btn"><span class="glyphicon glyphicon-registration-mark"></span> <span>Signup</span></a></li><?php }?>
    <?php if ($_smarty_tpl->getVariable('p')->value!='login'){?><li><a href="?p=home#login" class="btn btn-danger btn-lg btn-block navbar-btn" ><span class="glyphicon glyphicon-log-in"></span> <span>Login</span></a></li><?php }?>
</ul>
