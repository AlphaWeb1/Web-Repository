<?php /* Smarty version Smarty-3.0.8, created on 2017-09-20 11:34:37
         compiled from "./sites/templates/search.html" */ ?>
<?php /*%%SmartyHeaderCode:2860359c2362da58221-03247960%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd07da11a9d45ea80074896ffe2d2265a6031767e' => 
    array (
      0 => './sites/templates/search.html',
      1 => 1505900073,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2860359c2362da58221-03247960',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<script type="text/javascript">
    $(document).on('change', '#srch,#srch_for', function () {
        this.form.submit();
    });
</script>
<br class="well-sm"/><br class="well-sm"/>
<div class="row"><div class="col-md-3 btn-lg bg-primary text-justify"><h3>Dashboard: Search</h3></div>
    <div class="col-md-8"><br/>
        <a href="?p=dashboard&t=first_aid" class="btn btn-default"><span class=" text-danger fa fa-plus-square"></span> First Aid</a>
    </div>
</div><br/>
<div class="row">
    <div class="panel col-md-10 col-md-offset-1">
        <div class="panel-heading bg-primary"><form method="post">
                <div class="col-md-2"><label for="srch_for">Search For:</label>
                    <select class="form-control" name="srch_for" required id="srch_for">
                            <option value="0" <?php if ($_smarty_tpl->getVariable('vars')->value['for']=='0'){?> selected <?php }?>>Documents</option>
                            <option value="1" <?php if ($_smarty_tpl->getVariable('vars')->value['for']=='1'){?> selected <?php }?>>Articles / Blogs</option>
                            <option value="2" <?php if ($_smarty_tpl->getVariable('vars')->value['for']=='2'){?> selected <?php }?>>First Aid</option>
                    </select>
                </div>
                <div class="col-md-8"><label for='srch'>Search:</label>
                    <input id="srch" class="form-control" required placeholder="Enter search parameter here..." type="text" name="srch_param" value="<?php echo $_smarty_tpl->getVariable('vars')->value['param'];?>
"/></div>
                <div class="col-md-2"><label></label>
                    <button type="submit" class="form-control btn btn-block btn-info">
                        <span class="glyphicon glyphicon-search"></span> Search</button></div>
            </form>&nbsp;
            <br/>
        </div>
        <!--<div class="panel-heading bg-primary text-center text-info"><h4><b>Search Results</b></h4></div>-->
        <div class="panel-body bg-info">
            <?php if (isset($_smarty_tpl->getVariable('records',null,true,false)->value)&&$_smarty_tpl->getVariable('records')->value!=null){?>
                <ul><?php if ($_smarty_tpl->getVariable('vars')->value['for']=='0'){?>
                <?php  $_smarty_tpl->tpl_vars['recs'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('records')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['recs']->key => $_smarty_tpl->tpl_vars['recs']->value){
?>
                <li class=""> <div class="row"><div class="col-md-6"><h4><span class="glyphicon glyphicon-file"></span> 
                                <?php echo $_smarty_tpl->getVariable('recs')->value->file_name;?>
 | <b>By:</b> Dr. <?php echo $_smarty_tpl->getVariable('recs')->value->firstname;?>
 <?php echo $_smarty_tpl->getVariable('recs')->value->othernames;?>
</h4></div><div class="col-md-6">
                            <a class="btn-info btn-sm" href="?PME_sys_fl=0&PME_sys_fm=0&PME_sys_sfn[0]=-0&&p=dashboard&t=documents&PME_sys_operation=PME_op_View&PME_sys_rec=<?php echo $_smarty_tpl->getVariable('recs')->value->id;?>
">
                                <span class="glyphicon glyphicon-cloud-download"></span> More Info.</a></div></div>
                </li><?php }} ?>
                <?php }elseif($_smarty_tpl->getVariable('vars')->value['for']=='1'){?>
                <?php  $_smarty_tpl->tpl_vars['recs'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('records')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['recs']->key => $_smarty_tpl->tpl_vars['recs']->value){
?><li class="">
                    <div class="row"><div class="col-md-6"><h4>
                        <img class="img img-thumbnail" style="width:50px; heignt:50px;" id="b_img" src="<?php echo $_smarty_tpl->getVariable('lib_dir')->value;?>
/i/ic/<?php echo $_smarty_tpl->getVariable('recs')->value->blog_pic;?>
"> 
                                 <b>Title:</b> <?php echo $_smarty_tpl->getVariable('recs')->value->title;?>
 | <b>By:</b> Dr. <?php echo $_smarty_tpl->getVariable('recs')->value->firstname;?>
 <?php echo $_smarty_tpl->getVariable('recs')->value->othernames;?>
</h4></div>
                        <div class="col-md-6">
                            <a class="btn-info btn-sm" href="?PME_sys_fl=0&PME_sys_fm=0&PME_sys_sfn[0]=-0&&p=dashboard&t=blogs&PME_sys_operation=PME_op_View&PME_sys_rec=<?php echo $_smarty_tpl->getVariable('recs')->value->id;?>
">
                                <span class="glyphicon glyphicon-eye-open"></span> Read</a></div>
                    </div>
                </li><?php }} ?>
                <?php }elseif($_smarty_tpl->getVariable('vars')->value['for']=='2'){?>
                <?php  $_smarty_tpl->tpl_vars['recs'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('records')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['recs']->key => $_smarty_tpl->tpl_vars['recs']->value){
?><li class="">
                    <div class="row"><div class="col-md-6"><h4>
                        <img class="img img-thumbnail" style="width:50px; heignt:50px;" id="b_img" src="<?php echo $_smarty_tpl->getVariable('lib_dir')->value;?>
/i/fa/<?php echo $_smarty_tpl->getVariable('recs')->value->blog_pic;?>
">
                                 <b>First Aid:</b> <?php echo $_smarty_tpl->getVariable('recs')->value->title;?>
 | <b>By:</b> Dr. <?php echo $_smarty_tpl->getVariable('recs')->value->firstname;?>
 <?php echo $_smarty_tpl->getVariable('recs')->value->othernames;?>
</h4></div>
                        <div class="col-md-6">
                            <a class="btn-info btn-sm" href="?PME_sys_fl=0&PME_sys_fm=0&PME_sys_sfn[0]=-0&&p=dashboard&t=first_aid&PME_sys_operation=PME_op_View&PME_sys_rec=<?php echo $_smarty_tpl->getVariable('recs')->value->id;?>
">
                                <span class="glyphicon glyphicon-eye-open"></span> Read</a></div>
                    </div>
                </li><?php }} ?>
                <?php }?></ul>
            <div class="panel-footer center"><form method="post" action="?p=dashboard&t=search">
                    <?php $_template = new Smarty_Internal_Template("nav_controls.html", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?>
                </form><br/>&nbsp;</div>
            <?php }else{ ?><div class="col-md-8 col-md-offset-2 text-center"><?php $_template = new Smarty_Internal_Template("msg_display.html", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?></div><?php }?>
        </div>
    </div>
</div>