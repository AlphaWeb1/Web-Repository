<?php /* Smarty version Smarty-3.0.8, created on 2017-08-29 07:35:08
         compiled from "./sites/templates/capcha_login.html" */ ?>
<?php /*%%SmartyHeaderCode:2913659a4fd0cd43389-48263492%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '821e175fa518c8e1252d61fc95c4d887c1d14404' => 
    array (
      0 => './sites/templates/capcha_login.html',
      1 => 1503969920,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2913659a4fd0cd43389-48263492',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<div id="content" class="row">
    <hr/><br class="well-sm"/><br class="well-sm"/>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-info">
                <div class="panel-heading bg-warning"><a name="signup"><h3>---- <span class="glyphicon glyphicon-tags"></span> Image Authentication ----</h3></a></div>
                <form method="post" action="?p=capcha_login" enctype="multipart/form-data">
                    <div class="panel-body">
                        <h4>--Choose appropriate group of pictures from the grid below--</h4><br/>
                        <?php $_smarty_tpl->tpl_vars['cnt'] = new Smarty_variable(0, null, null);?> 
                        <?php if (isset($_smarty_tpl->getVariable('capcha_lists',null,true,false)->value)&&count($_smarty_tpl->getVariable('capcha_lists')->value)>0){?>
                        <?php  $_smarty_tpl->tpl_vars['recs'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('capcha_lists')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['recs']->key => $_smarty_tpl->tpl_vars['recs']->value){
?><div class="col-md-3"><label for="pic_no<?php echo $_smarty_tpl->getVariable('cnt')->value;?>
">
                        <img class="img-thumbnail" style="width: 200px; height: 150px; cursor: pointer;" src="<?php echo $_smarty_tpl->getVariable('lib_dir')->value;?>
/i/capcha/<?php echo $_smarty_tpl->tpl_vars['recs']->value;?>
"/>
                        </label></div><div class="col-md-1">
                        <input type="checkbox" name="cap_pic[]" value="<?php echo $_smarty_tpl->tpl_vars['recs']->value;?>
" class="checkbox-inline" id="pic_no<?php echo $_smarty_tpl->getVariable('cnt')->value;?>
"/><?php $_smarty_tpl->tpl_vars['cnt'] = new Smarty_variable($_smarty_tpl->getVariable('cnt')->value+1, null, null);?>
                        </div><?php }} ?>
                        <?php }else{ ?><div class="col-md-10 col-md-offset-1 text-center"><?php $_template = new Smarty_Internal_Template("msg_display.html", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?><br class="well-sm"/></div>
                        <?php }?>
<!--                        <div class="col-md-3"><label for="pic_no9"><img class="img-thumbnail" style="width: 100%; height: 30%; cursor: pointer;" src="-{$lib_dir}-/i/ic/crypt.png"/></label>
                        </div><div class="col-md-1"><input type="checkbox" name="pic" class="checkbox" style="position: absolute;" id="pic_no9"/></div><br/>-->
                        <hr/>
                    </div>
                    <div class="panel-footer center"><input type="hidden" name="hold" value="<?php echo $_smarty_tpl->getVariable('j')->value;?>
" />
                        <button class="btn btn-primary" name="capcha_login" value="lgn" type="submit">-- <span class="glyphicon glyphicon-check"></span> Verify --</button>
                    </div>
                </form>
            </div>
            <br class="well-sm"/><br class="well-sm"/>
            <div class="col-md-10 col-md-offset-2 text-center"><?php $_template = new Smarty_Internal_Template("msg_display.html", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?></div>
        </div>
    </div>
</div>

