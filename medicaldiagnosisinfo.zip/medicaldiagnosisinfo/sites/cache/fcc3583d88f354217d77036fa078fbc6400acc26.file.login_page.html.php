<?php /* Smarty version Smarty-3.0.8, created on 2017-09-16 12:15:38
         compiled from "./sites/templates/login_page.html" */ ?>
<?php /*%%SmartyHeaderCode:2355759bcf9caf0af68-69437003%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fcc3583d88f354217d77036fa078fbc6400acc26' => 
    array (
      0 => './sites/templates/login_page.html',
      1 => 1505556934,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2355759bcf9caf0af68-69437003',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<div class="row">
        <div class="col-md-8 col-md-offset-2 text-center"><?php $_template = new Smarty_Internal_Template("msg_display.html", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?></div>
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-primary">
            <div class="panel-heading text-danger"><a class="text-danger" name="login"><h3>--- <span class="glyphicon glyphicon-lock"></span>  Login Details ---</h3></a></div>
            <form method="post" action="?p=home#login">
                <div class="panel-body">
                    <label for="usern">User ID/ Username:</label><input type="text" class="form-control input-lg" placeholder="email or username number goes here..." required name="user" value="" id="usern"/><br/>
                    <label for="passw">Password:</label><input type="password" class="form-control input-lg" placeholder="password goes here..." required name="pass" id="passw"/>
                </div>
                <div class="panel-footer center">
                    <a href="?p=home" class="btn btn-info">-- <span class="glyphicon glyphicon-home"></span> Home --</a>
                    <a href="?p=forgot_password" class="btn btn-sm btn-default"><span class="glyphicon glyphicon-link"></span> Forget Password</a>
                    <button class="btn btn-primary" name="signin" value="login" type="submit">-- <span class="glyphicon glyphicon-log-in"></span> Login --</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="row"><br class="well-lg"><br class="well-lg"><br class="well-lg"></div>