<?php /* Smarty version Smarty-3.0.8, created on 2017-09-21 14:53:02
         compiled from "./sites/templates/msg1_display.xhtml" */ ?>
<?php /*%%SmartyHeaderCode:123559c3b62ef282c6-33102709%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '90f263e58a077f0130d34fcd733f765986d51b3b' => 
    array (
      0 => './sites/templates/msg1_display.xhtml',
      1 => 1503556998,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '123559c3b62ef282c6-33102709',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (isset($_smarty_tpl->getVariable('msg1',null,true,false)->value)){?>
<div>
<div class="alert alert-<?php echo $_smarty_tpl->getVariable('msg1')->value['type'];?>
">
<?php if (isset($_smarty_tpl->getVariable('msg1',null,true,false)->value['close'])&&$_smarty_tpl->getVariable('msg1')->value['close']=='true'){?>
<a class="close" data-dismiss="alert">x</a>
<?php }?>
<?php if (isset($_smarty_tpl->getVariable('msg1',null,true,false)->value['title'])){?>
<h4 class="alert-heading"><?php echo $_smarty_tpl->getVariable('msg1')->value['title'];?>
</h4>
<?php }?>
<?php echo $_smarty_tpl->getVariable('msg1')->value['content'];?>

<?php if (isset($_smarty_tpl->getVariable('msg1',null,true,false)->value['btn_text'])){?>
<br/>
<a href="<?php echo $_smarty_tpl->getVariable('msg1')->value['url'];?>
" class="btn btn-<?php echo $_smarty_tpl->getVariable('msg1')->value['btn_type'];?>
 btn-<?php echo $_smarty_tpl->getVariable('msg1')->value['size'];?>
"><?php echo $_smarty_tpl->getVariable('msg1')->value['btn_text'];?>
</a>
<?php }?>
</div>
</div>
<?php }?>