<?php /* Smarty version Smarty-3.0.8, created on 2017-08-30 04:59:45
         compiled from "./sites/templates/error_page.html" */ ?>
<?php /*%%SmartyHeaderCode:1755259a62a21a2e4a4-35203641%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'bc8cc0f2517a8043875b78fe377dfc169681048d' => 
    array (
      0 => './sites/templates/error_page.html',
      1 => 1502530979,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1755259a62a21a2e4a4-35203641',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php $_template = new Smarty_Internal_Template("page_title.html", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?>
<div class="col-md-8 col-md-offset-2 frow">
<div class="well-sm"></div>
<div class="row frow  bg-warning">
<?php if (isset($_smarty_tpl->getVariable('error',null,true,false)->value)){?>
    <div class="col-sm-12">
        <?php if (isset($_smarty_tpl->getVariable('error',null,true,false)->value->title)){?><div class="col-sm-2 bg-danger"><h3><?php echo $_smarty_tpl->getVariable('error')->value->title;?>
</h3></div><?php }?>
        <?php if (isset($_smarty_tpl->getVariable('error',null,true,false)->value->text)){?><div class="col-sm-7 bg-warning"><h4><?php echo $_smarty_tpl->getVariable('error')->value->text;?>
</h4></div><?php }?>
        <?php if (isset($_smarty_tpl->getVariable('error',null,true,false)->value->back_url)){?>
        <div class="col-sm-2 bg-warning"><br/><a href="?p=<?php echo $_smarty_tpl->getVariable('error')->value->back_url;?>
" class="btn btn-lg btn-danger"><span class="glyphicon glyphicon-backward"></span> <?php echo $_smarty_tpl->getVariable('error')->value->back_url;?>
</a>&nbsp;</div>
        <?php }?>
    </div>
<?php }?>
</div>
</div>
<?php $_template = new Smarty_Internal_Template("footer.html", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?>
