<?php /* Smarty version Smarty-3.0.8, created on 2017-09-16 12:15:58
         compiled from "./sites/templates/forgot_password.html" */ ?>
<?php /*%%SmartyHeaderCode:1882259bcf9deddb221-61631641%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4ac4e17f71583f92e6432b8e6648cfb63bac5231' => 
    array (
      0 => './sites/templates/forgot_password.html',
      1 => 1505556046,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1882259bcf9deddb221-61631641',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<hr/><br class="well-lg"/><br class="well-lg"/>
<div class="row">
    <div class="col-md-6 col-md-offset-3">
        <div class="panel panel-default">
            <div class="panel-heading text-center"><h3>--- <span class="glyphicon glyphicon-open"></span>  Recover Details ---</h3></div>
            <form method="post" action="">
                <div class="panel-body">
                    <label for="usern">Email or Username:</label><input type="text" class="form-control input-lg" placeholder="email or username goes here..." required name="user" value="" id="usern"/><br/>
                    <label for="passw">Phone Number:</label><input type="text" class="form-control input-lg" placeholder="phone number goes here..." required name="pass" id="passw"/>
                    <div class="col-md-8 col-md-offset-2 text-center"><?php $_template = new Smarty_Internal_Template("msg_display.html", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?></div>
                </div>
                <div class="panel-footer center">
                    <a href="?p=home" class="btn btn-warning"><span class="glyphicon glyphicon-home"></span> Home</a>
                    <button class="btn btn-primary" name="recover" value="recover" type="submit"><span class="glyphicon glyphicon-repeat"></span> Recover Password</button>
                    <a href="?p=home#login" class="btn btn-default"><span class="glyphicon glyphicon-log-in"></span> Login</a>
                    
                </div>
            </form>
        </div>
    </div>
</div>