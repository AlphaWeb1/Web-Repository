<?php /* Smarty version Smarty-3.0.8, created on 2017-09-21 20:15:48
         compiled from "./sites/templates/footer.html" */ ?>
<?php /*%%SmartyHeaderCode:975459c401d4104231-51370042%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1afbf6dde71f05fb14276057b7b14b86e5d0903f' => 
    array (
      0 => './sites/templates/footer.html',
      1 => 1506017720,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '975459c401d4104231-51370042',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<div class="row"><div id="footer" class="row navbar-fixed-bottom">
    <!--<footer id="footer">-->
    <h5><?php if (isset($_smarty_tpl->getVariable('user',null,true,false)->value)){?>
       |&nbsp;<a href="?p=dashboard&t=home"> Home</a>&nbsp;|
        <a href="?PME_sys_fl=0&PME_sys_fm=0&PME_sys_sfn[0]=0&p=dashboard&t=profile&PME_sys_operation=PME_op_View&PME_sys_rec=<?php echo $_smarty_tpl->getVariable('uid')->value;?>
">Profile</a>
        &nbsp;|
        <a href="?p=dashboard&t=blogs"> Blogs</a>&nbsp;|
        <a href="?p=dashboard&t=search"> Search</a>&nbsp;|
        <a href="?p=logout"> Logout</a>&nbsp;|
         <?php }else{ ?>
       |&nbsp;<a href="?p=home#signup">Signup</a>&nbsp;|
        <a href="?p=home#login"> Login</a>&nbsp;|
        <a href="?p=home#info">Site Home</a>&nbsp;|
        <?php }?> 
    </h5>
    <h4>© 2017 Medical Information Systems.&nbsp;|&nbsp;<a href="index.php#" target="_blank">Credits</a></h4>
    <!--</footer>-->
</div>
</div>
</body>
</html>
