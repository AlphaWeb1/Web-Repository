<?php /* Smarty version Smarty-3.0.8, created on 2017-09-18 22:28:50
         compiled from "./sites/templates/base_style.html" */ ?>
<?php /*%%SmartyHeaderCode:2792859c02c82aed087-35199350%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '61084c795cea2e45ac3485dbaf7f62a939c4f5a7' => 
    array (
      0 => './sites/templates/base_style.html',
      1 => 1505766335,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2792859c02c82aed087-35199350',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php echo '<?xml';?> version="1.0" encoding="UTF-8"<?php echo '?>';?>
<!--To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.-->
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->getVariable('lib_dir')->value;?>
/<?php echo $_smarty_tpl->getVariable('public_dir')->value;?>
/libs/jquery/jquery-ui.min.css"/>
<!--<link rel="stylesheet" href="libs/public/sub_public/jquery/jquery.datepick.css"/>-->
<link rel="stylesheet" href="<?php echo $_smarty_tpl->getVariable('lib_dir')->value;?>
/<?php echo $_smarty_tpl->getVariable('public_dir')->value;?>
/libs/bootstrap/css/bootstrap.min.css"/>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->getVariable('lib_dir')->value;?>
/<?php echo $_smarty_tpl->getVariable('public_dir')->value;?>
/libs/bootstrap/css/bootstrap-theme.min.css"/>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->getVariable('lib_dir')->value;?>
/<?php echo $_smarty_tpl->getVariable('public_dir')->value;?>
/libs/bootstrap-datetimepicker/css/bootstrap-datetimepicker.min.css"/>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->getVariable('lib_dir')->value;?>
/<?php echo $_smarty_tpl->getVariable('public_dir')->value;?>
/css/font-awesome.min.css"/>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->getVariable('lib_dir')->value;?>
/<?php echo $_smarty_tpl->getVariable('public_dir')->value;?>
/css/style.css"/>