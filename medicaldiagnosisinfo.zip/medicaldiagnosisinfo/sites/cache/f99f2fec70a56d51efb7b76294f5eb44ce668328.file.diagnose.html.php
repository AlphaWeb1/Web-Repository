<?php /* Smarty version Smarty-3.0.8, created on 2017-09-21 15:14:47
         compiled from "./sites/templates/diagnose.html" */ ?>
<?php /*%%SmartyHeaderCode:3074159c3bb47652874-67356571%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f99f2fec70a56d51efb7b76294f5eb44ce668328' => 
    array (
      0 => './sites/templates/diagnose.html',
      1 => 1505995994,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3074159c3bb47652874-67356571',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<script type="text/javascript">
    $(document).on('change', '#diag', function () {
        this.form.submit();
    });
</script>
<br class="well-sm"/><br class="well-sm"/>
<div class="row"><div class="col-md-3 btn-lg bg-primary text-justify"><h3>Dashboard: Diagnosis</h3></div>
</div><br/>
<div class="row">
    <div class="panel col-md-11">
        <div class="panel-heading bg-primary"><form method="post">
                <div class="col-md-1"><label>&nbsp;</label></div>
                <div class="col-md-8"><label for='diag'>Search:</label>
                    <input id="diag" class="form-control" required placeholder="Enter search parameter here..." type="text" name="diag" value="<?php echo $_smarty_tpl->getVariable('diag')->value;?>
"/></div>
                <div class="col-md-2"><label></label>
                    <button type="submit" class="form-control btn btn-block btn-info">
                        <span class="glyphicon glyphicon-search"></span> Diagnose</button></div><div class="col-md-1"><label><br/>&nbsp;</label></div>
            </form>&nbsp;<br/>
        </div>
        <div class="panel-body bg-info">
         <?php if (isset($_smarty_tpl->getVariable('records',null,true,false)->value)&&$_smarty_tpl->getVariable('records')->value!=null){?> <?php  $_smarty_tpl->tpl_vars['recs'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('records')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['recs']->key => $_smarty_tpl->tpl_vars['recs']->value){
?>
         <div class="panel col-lg-4 ">
            <br><div class="form-group text-center"><label for="blog_pix">
            <img class="img img-thumbnail" style="width:100px; heignt:100px;" id="b_img" src="<?php echo $_smarty_tpl->getVariable('lib_dir')->value;?>
/i/pr/<?php echo $_smarty_tpl->getVariable('recs')->value->profile_pic;?>
"/>
                </label></div>
            <div class="pme-main">
            <div class="form-group pme-row-1"><!--1159-->
            <label class="control-label pme-key-1">Illness</label><div class="pme-value-1"><?php echo $_smarty_tpl->getVariable('recs')->value->medical_disorder;?>
</div>
            </div>
            <div class="form-group pme-row-0">
            <label class="control-label pme-key-0">Added By</label>
            <div class="pme-value-0">Dr. <?php echo $_smarty_tpl->getVariable('recs')->value->firstname;?>
 <?php echo $_smarty_tpl->getVariable('recs')->value->othernames;?>
</div>
            </div>
            <div class="form-group pme-row-0">
            <label class="control-label pme-key-0">Treatment Procedure</label><div class="pme-value-0"><?php echo $_smarty_tpl->getVariable('recs')->value->treatment_procedure;?>
</div>
            </div>
            <div class="form-group pme-row-1">
            <label class="control-label pme-key-1">Signs of Illness</label><div class="pme-value-1"><?php echo $_smarty_tpl->getVariable('recs')->value->symptoms;?>
</div>
            </div>
            </div>
            <div class="form-group pme-navigation">
            <div class="pme-buttons"><input type="hidden" name="PME_sys_saveview" value="View">
            <a href="?PME_sys_fl=0&PME_sys_fm=0&PME_sys_sfn[0]=-0&p=dashboard&t=diagnosis&PME_sys_operation=PME_op_View&PME_sys_rec=<?php echo $_smarty_tpl->getVariable('recs')->value->id;?>
" class="btn btn-primary">
                <span class="glyphicon glyphicon-info-sign"></span> More Info.</a>
            </div></div>
         </div>
            <?php }} ?>
         <?php }else{ ?><div class="col-md-8 col-md-offset-2 text-center"><?php $_template = new Smarty_Internal_Template("msg_display.html", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?></div><?php }?>
        </div>
    </div>
</div>