<?php /* Smarty version Smarty-3.0.8, created on 2017-09-17 20:26:21
         compiled from "./sites/templates/library.html" */ ?>
<?php /*%%SmartyHeaderCode:1253859bebe4da60dd2-04622499%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '36fc4c22c0b4267d5fb8119846bc2a1dbfcf2aa4' => 
    array (
      0 => './sites/templates/library.html',
      1 => 1503711623,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1253859bebe4da60dd2-04622499',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<script type="text/javascript">
    $(document).on('change', '#level,#semester,#srch', function () {
        this.form.submit();
    });

</script>
<br class="well-sm"/><br class="well-sm"/>
<div class="row"><div class="col-md-4 btn-lg bg-warning text-justify"><h3>Dashboard:- e-Library</h3></div>
    <div class="col-md-8"><br class="well-sm"/>
        <?php if (isset($_smarty_tpl->getVariable('c_nav',null,true,false)->value)&&$_smarty_tpl->getVariable('c_nav')->value!='all'){?>
        <a href="?p=dashboard&t=library&k=all" class="btn btn-success"><span class="glyphicon glyphicon-book"></span> All books</a>
        <?php }?><?php if (isset($_smarty_tpl->getVariable('c_nav',null,true,false)->value)&&$_smarty_tpl->getVariable('c_nav')->value!='search'){?>
        <a href="?p=dashboard&t=library&k=search" class="btn btn-info"><span class="glyphicon glyphicon-search"></span> Search</a>
        <?php }?><?php if (isset($_smarty_tpl->getVariable('c_nav',null,true,false)->value)&&$_smarty_tpl->getVariable('c_nav')->value!='filter'){?>
        <a href="?p=dashboard&t=library&k=filter" class="btn btn-primary"><span class="glyphicon glyphicon-filter"></span> Category</a>
        <?php }?>
    </div>
</div><br/>
<div class="row">
    <?php if ($_smarty_tpl->getVariable('c_nav')->value=='filter'){?>
    <?php $_smarty_tpl->tpl_vars['cur_dir_name'] = new Smarty_variable('Select Book Category', null, null);?>
    <div class="col-md-8 col-md-offset-2">
        <div class="panel-heading bg-info text-center text-info"><h4><b><?php echo $_smarty_tpl->getVariable('cur_dir_name')->value;?>
</b>
            </h4></div>
        <div class="panel-body bg-success"><form method="post">
                <div><label for="level">Level </label>
                    <select class="dropdown input-sm" id="level" name="level"><optgroup>
                            <option value="nd1" <?php if ($_smarty_tpl->getVariable('level')->value=='nd1'){?> selected <?php }?>>ND I</option>
                            <option value="nd2" <?php if ($_smarty_tpl->getVariable('level')->value=='nd2'){?> selected <?php }?>>ND II</option>
                            <option value="hnd1" <?php if ($_smarty_tpl->getVariable('level')->value=='hnd1'){?> selected <?php }?>>HND I</option>
                            <option value="hnd2" <?php if ($_smarty_tpl->getVariable('level')->value=='hnd2'){?> selected <?php }?>>HND II</option>
                        </optgroup></select>&nbsp;&nbsp;&nbsp;&nbsp;
                    <label for="semester">Semester</label>
                    <select class="dropdown input-sm" id="semester" name="semester"><optgroup>
                            <option value="1st" <?php if ($_smarty_tpl->getVariable('semester')->value=='1st'){?> selected <?php }?>>First Semester</option>
                            <option value="2nd" <?php if ($_smarty_tpl->getVariable('semester')->value=='2nd'){?> selected <?php }?>>Second Semester</option></select>
                </div>
            </form></div>
        <div class="panel-heading bg-primary text-center text-info"><h4><b>Search Results</b></h4></div>
        <div class="panel-body bg-success">
            <?php if (count($_smarty_tpl->getVariable('datum')->value)>0){?><ul>
                <?php  $_smarty_tpl->tpl_vars['recs'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('datum')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['recs']->key => $_smarty_tpl->tpl_vars['recs']->value){
?>
                <li class=""> <div class="row"><div class="col-md-6"><h4><span class="glyphicon glyphicon-file"></span> 
                                <?php echo $_smarty_tpl->getVariable('recs')->value->file_name;?>
</h4></div><div class="col-md-6">
                            <a class="btn-warning btn-sm" href="<?php echo $_smarty_tpl->getVariable('lib_dir')->value;?>
/f/ebooks/<?php echo $_smarty_tpl->getVariable('recs')->value->department;?>
/<?php echo $_smarty_tpl->getVariable('recs')->value->stored_name;?>
">
                                <span class="glyphicon glyphicon-cloud-download"></span> Download File</a></div></div>
                </li>
                <?php }} ?></ul>
            <?php }else{ ?><?php $_template = new Smarty_Internal_Template("msg_display.html", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?>
            <?php }?>
        </div><br class="well-sm"/><br class="well-sm"/>
    </div>
    <?php }elseif($_smarty_tpl->getVariable('c_nav')->value=='search'){?>
    <?php $_smarty_tpl->tpl_vars['cur_dir_name'] = new Smarty_variable('Search Books', null, null);?>
    <div class="col-md-8 col-md-offset-2">
        <div class="panel-heading bg-info text-center text-info"><h4><b><?php echo $_smarty_tpl->getVariable('cur_dir_name')->value;?>
</b></h4></div>
        <div class="panel-body bg-success"><form method="post">
                <div class="col-md-7"><label for='srch'>Search:</label>
                    <input id="srch" class="form-control" required placeholder="Enter search parameter here..." type="text" name="srch_param" value="<?php echo $_smarty_tpl->getVariable('srch_param')->value;?>
"/></div>
                <div class="col-md-2"><label></label>
                    <button type="submit" class="form-control btn btn-block btn-info btn-sm">
                        <span class="glyphicon glyphicon-search"></span> Search</button></div>
            </form></div>
        <div class="panel-heading bg-primary text-center text-info"><h4><b>Search Results</b></h4></div>
        <div class="panel-body bg-success">
            <?php if (count($_smarty_tpl->getVariable('datum')->value)>0){?><ul>
                <?php  $_smarty_tpl->tpl_vars['recs'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('datum')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['recs']->key => $_smarty_tpl->tpl_vars['recs']->value){
?>
                <li class=""> <div class="row"><div class="col-md-6"><h4><span class="glyphicon glyphicon-file"></span> 
                                <?php echo $_smarty_tpl->getVariable('recs')->value->file_name;?>
</h4></div><div class="col-md-6">
                            <a class="btn-warning btn-sm" href="<?php echo $_smarty_tpl->getVariable('lib_dir')->value;?>
/f/ebooks/<?php echo $_smarty_tpl->getVariable('recs')->value->department;?>
/<?php echo $_smarty_tpl->getVariable('recs')->value->stored_name;?>
">
                                <span class="glyphicon glyphicon-cloud-download"></span> Download File</a></div></div>
                </li>
                <?php }} ?></ul>
            <?php }else{ ?><?php $_template = new Smarty_Internal_Template("msg_display.html", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?>
            <?php }?>
        </div><br class="well-sm"/><br class="well-sm"/>
    </div>
    <?php }elseif($_smarty_tpl->getVariable('c_nav')->value=='all'){?>
    <?php $_smarty_tpl->tpl_vars['cur_dir_name'] = new Smarty_variable('All Books', null, null);?>
    <div class="col-md-8 col-md-offset-2">
        <div class="panel-heading bg-danger text-center text-info"><h4><b><?php echo $_smarty_tpl->getVariable('cur_dir_name')->value;?>
</b></h4></div>
        <div class="panel-body bg-success">
            <?php if (count($_smarty_tpl->getVariable('datum')->value)>0){?><ul>
                <?php  $_smarty_tpl->tpl_vars['recs'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('datum')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['recs']->key => $_smarty_tpl->tpl_vars['recs']->value){
?>
                <li class=""> <div class="row"><div class="col-md-6"><h4><span class="glyphicon glyphicon-file"></span> 
                                <?php echo $_smarty_tpl->getVariable('recs')->value->file_name;?>
</h4></div><div class="col-md-6">
                            <a class="btn-warning btn-sm" href="<?php echo $_smarty_tpl->getVariable('lib_dir')->value;?>
/f/ebooks/<?php echo $_smarty_tpl->getVariable('recs')->value->department;?>
/<?php echo $_smarty_tpl->getVariable('recs')->value->stored_name;?>
">
                                <span class="glyphicon glyphicon-cloud-download"></span> Download File</a></div></div>
                </li>
                <?php }} ?></ul>
            <?php }else{ ?><?php $_template = new Smarty_Internal_Template("msg_display.html", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?>
            <?php }?>
        </div>
    </div><br class="well-sm"/><br class="well-sm"/>
    <?php }?>
</div>