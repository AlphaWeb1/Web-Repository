<?php global $ez_db, $smarty,$the_site,$sites_dir,$p;$t=null;

if (($uname=use_if_sent_("signup")) != null) {    
    $personal=array("f"=> use_if_sent_("first"),"o"=> use_if_sent_("others"),"pic"=> use_if_file_("pic"),"ph"=> use_if_sent_("phone"),
    "em"=> use_if_sent_("email"),"gn"=> use_if_sent_("gender"),"st"=> use_if_sent_("state"),"ct"=> use_if_sent_("city"),"ad"=> use_if_sent_("address")
    ,"cn"=> use_if_sent_("country"));
    $logins=array("ps"=> use_if_sent_("pass"),"cps"=> use_if_sent_("cpass"),"ut"=> use_if_sent_("utype"),"un"=>use_if_sent_('username'));
//    $usern=$ez_db->get_var("SELECT COUNT(`id`) FROM `users` WHERE `username`='".strtolower($uname)."';");
    user_signup_($personal,$logins);
}
