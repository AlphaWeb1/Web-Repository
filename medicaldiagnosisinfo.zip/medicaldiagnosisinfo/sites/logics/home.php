<?php global $ez_db, $smarty,$user_table,$the_site,$sites_dir;$t=null;
if($error_code!='001'){
$page_error=get_page_error_($error_code);
$smarty->assign('error',$page_error);
}

if (use_if_sent_('signin')!==NULL) {
    require_once 'login.php';
}
if (($t=use_if_sent_('t'))!=null){ $smarty->assign("t","$t");
   $smarty->assign("t_file","$t.html"); require_it_("$sites_dir/logics/$t");
}
$blogs=$ez_db->get_results("SELECT `blogs`.`id`,`profile_pic`,`firstname`,`othernames`,`blog_pic`,`article`,`title`,`date_added` FROM `blogs`,"
    . "`$user_table` WHERE `blogs`.`username`=`$user_table`.`username` AND `blog_type`='blog' AND `blogs`.`keep`=1 ORDER BY `date_added` DESC LIMIT 3;");

$testi=$ez_db->get_results("SELECT `testimonies`.`id`,`profile_pic`,`firstname`,`othernames`,`content`,`title`,`date_added` FROM "
. "`testimonies`,`$user_table` WHERE `testimonies`.`username`=`$user_table`.`username` AND `testimonies`.`keep`=1 ORDER BY `date_added` "
. "DESC LIMIT 3;");

$smarty->assign("testi", $testi);$smarty->assign("blogs", $blogs); $smarty->display("home.html");
$smarty->assign("msg1",array("title"=>"Message","content"=>"No Record Found!!!","type"=>"danger"));