<?php
global $sites_dir, $ez_db, $smarty;
//$user=get_user_("username");$ut=get_user_type_($user);
//$user_info=get_user_info_("`first_name`,`other_names`,`profile_pic`",$user,$ut);
if($error_code!='001'){
$page_error=get_page_error_($error_code);
$smarty->assign('error',$page_error);
}else{
$smarty->display("dashboard.html");
}
if (!use_if_sent_('t')!=null or ($t=use_if_sent_('t'))=="home"){
   $smarty->assign("t_file","dash_home.html"); require_it_("$sites_dir/logics/dashboard/home");
}
if (($t=use_if_sent_('t'))!=null and use_if_sent_('t')!="home") {
$smarty->assign("t_file","$t.html"); require_it_("$sites_dir/logics/dashboard/$t");
}
if (($r=use_if_sent_('r'))!=null and ($t=use_if_sent_('t'))!=null) {
$smarty->assign("r",$r); require_it_("$sites_dir/logics/dashboard/$t/$r");
}
if (($r=use_if_sent_('r'))!=null and ($i=use_if_sent_('i'))!=null and ($t=use_if_sent_('t'))!=null) {
$smarty->assign("r",$r); require_it_("$sites_dir/logics/dashboard/$t/$r/$i");
}
if($error_code!='001'){
$page_error=get_page_error_($error_code);
$smarty->assign('error',$page_error);
}else{
$smarty->display("dash_main.html");
}