<?php global $domain_name,$the_host,$protocol, $inc_dir, $ez_db, $smarty,$sites_dir;
 if (use_if_sent_("recover")!=NULL) {
    $username=  use_if_sent_("user");$recover=  use_if_sent_("pass");
if ($ez_db->get_var("SELECT COUNT(`id`) FROM `user_info` WHERE (`username`='$username' OR `email`='$username') AND "
        . "(`phone`='$recover') AND `keep`=1;")>0) {
    $password=$ez_db->get_var("SELECT `password` FROM `user_info` WHERE `username`='$username' OR `email`='$username' AND `keep`=1");
    $smarty->assign("msg", array("type" => "success", "title" => "Recovery Success", "content" => "Password recovery is successfull your password is "
        . "<b>$password</b> click <a class='btn btn-sm btn-success' href='?p=home#login'>Here...</a> to go to login page","close" => "true"));
}else{
    $smarty->assign("msg", array("type" => "warning", "title" => "Invalid recovery detail", "content" => "the supplied recovery detail is invalid check"
        . "and correct recovery detail","close" => "true"));
}
}
$smarty->display("forgot_password.html");