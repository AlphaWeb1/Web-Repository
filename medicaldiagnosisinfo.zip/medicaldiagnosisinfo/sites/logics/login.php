<?php global $domain_name,$the_host,$protocol, $inc_dir, $ez_db, $smarty,$sites_dir;
if (use_if_sent_("user") != null) { $logins=array("un"=> use_if_sent_("user"),"ps"=> use_if_sent_("pass")); 
    login_($logins);
}

