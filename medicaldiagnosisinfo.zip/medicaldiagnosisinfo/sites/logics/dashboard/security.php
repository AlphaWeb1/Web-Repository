<?php<?php global $user,$lib_dir,$ez_db,$smarty,$db_name,$db_pass,$db_user,$the_host,$sites_dir,$user_table,$uid;
$user = get_user_("user_log");
$username=$ez_db->get_var("SELECT `username` FROM `$user_table` WHERE `token`='$user';");
if (isset($_REQUEST['PME_sys_rec'])) {  $_REQUEST['PME_sys_rec']=$uid;  }
echo '<br class="well-sm"/><hr/>
<div class="row">
    <div class="col-md-4 btn-lg bg-primary text-justify"><h3>Dashboard: Security Profiles</h3></div>
    <div class="col-md-8"><br class="well-sm"/>
        <a href="?p=dashboard&t=profile&PME_sys_operation=PME_op_View&PME_sys_rec='.$uid.'" class="btn btn-primary"><span class="glyphicon glyphicon-book"></span> Personal Profiles</a>
        '.(isset($_REQUEST['PME_sys_operation'])?'<a href="?p=dashboard&t=home" class="btn btn-default">
        <span class="glyphicon glyphicon-home"></span> Home</a>':'').' 
    </div>
</div><hr/>';
$back_dir = '<a href="?p=dashboard&t=security&PME_sys_operation=PME_op_View&PME_sys_rec='.$uid.'" class="btn btn-warning"><span class="glyphicon glyphicon-backward"></span> Back</a>';

$opts['hn'] = $the_host;
$opts['un'] = $db_user;
$opts['pw'] = $db_pass;
$opts['db'] = $db_name;
$opts['tb'] = $user_table;
$t=  use_if_sent_("t");$p=  use_if_sent_("p");
// Name of field which is the unique key
$opts['key'] = 'id';

// Type of key field (int/real/string/date etc.)
$opts['key_type'] = 'int';
// Sorting field(s)
$opts['sort_field'] = array('id');

// Number of records to display on the screen
// Value of -1 lists all records in a table
$opts['inc'] = 10;

// Options you wish to give the users
// A - add,  C - change, P - copy, V - view, D - delete,
// F - filter, I - initial sort suppressed
$opts['options'] = 'VCD';
$opts['filters'] = '`username`=\''.$username.'\' AND `keep`=1';


// Number of lines to display on multiple selection filters

$opts['buttons']['A']['down'] = array(
    '<input type="hidden" name="PME_sys_saveadd" value="Save" />',
    '<button class="btn btn-danger" name="Submit" id="Submit" onclick="return PME_js_form_control(this.form);" type="submit">
  <span class="glyphicon glyphicon-floppy-disk"></span> Add User</button>',
    $back_dir
);

$opts['buttons']['C']['down'] = array(
    '<input type="hidden" name="PME_sys_savechange" value="Save" />',
    '<button class="btn btn-danger" name="Submit" id="Submit" onclick="return PME_js_form_control(this.form);" type="submit">
      <span class="glyphicon glyphicon-edit"></span> Update Info.</button>',
    $back_dir
);
$opts['buttons']['V']['down'] = array(
    '<input type="hidden" name="PME_sys_saveview" value="View" />',
    ((isset($_REQUEST['PME_sys_rec']) and $_REQUEST['PME_sys_rec'] != $uid)?'':' <a href="?PME_sys_fl=0&PME_sys_fm=0&PME_sys_sfn[0]=0&p=dashboard&t=security&PME_sys_operation=PME_op_Change&PME_sys_rec='. $uid.'" 
    class="btn btn-danger"><span class="glyphicon glyphicon-pencil"></span> Edit Profile</a>'),
    $back_dir
);

// Number of lines to display on multiple selection filters
$opts['multiple'] = '4';
$opts['buttons']['L']['down'] = array('<<','<','>','>>');

// Navigation style: B - buttons (default), T - text links, G - graphic links
// Buttons position: U - up, D - down (default)
$opts['navigation'] = 'DG';
$opts['url'] = array('images' => "$lib_dir/phpMyEdit/images/");

// Display special page elements
$opts['display'] = array(
    'form' => true,
    'query' => false,
    'sort' => false,
    'time' => false,
    'tabs' => false,
    'num_pages' => false,
    'num_records' => true
);

// Set default prefixes for variables
$opts['js']['prefix']               = 'PME_js_';
$opts['dhtml']['prefix']            = 'PME_dhtml_';
$opts['cgi']['prefix']['operation'] = 'PME_op_';
$opts['cgi']['prefix']['sys']       = 'PME_sys_';
$opts['cgi']['prefix']['data']      = 'PME_data_';

/* Get the user's default language and use it if possible or you can
   specify particular one you want to use. Refer to official documentation
   for list of available languages. */

$opts['triggers']['update']['before']  = "$sites_dir/logics/$p/update_security_pre.php";

$opts['cgi']['persist'] = array(
    'p' => use_if_sent_("p"),
    't' => $t,
);

$opts['language'] = $_SERVER['HTTP_ACCEPT_LANGUAGE'];

$opts['fdd']['id'] = array(
  'name'     => 'ID',
  'select'   => 'T',
  'options'  => 'AVCPDR', // auto increment
  'options|AVCDLF' => 'H',
  'maxlen'   => 11,
  'default'  => '0',
  'sort'     => true
);
$opts['fdd']['username'] = array(
  'name'     => 'Username',
  'input'   => 'R',
  'maxlen'   => 255,
  'sort'     => true
);
$opts['fdd']['email'] = array(
  'name'     => 'Email',
  'input'   => 'R',
  'maxlen'   => 65535,
  'sort'     => true
);
$opts['fdd']['password'] = array(
  'name'     => 'Password',
  'select'   => 'T',
  'maxlen'   => 65535,
  'sort'     => true
);
$opts['fdd']['access'] = array(
  'name'     => 'User As',
  'select'   => 'T',
  'maxlen'   => 20,
  'values2'  => array( "0"=> "Consult","1"=> "Medical Expert"),
  'sort'     => true
);
$opts['fdd']['keep'] = array(
  'name'     => 'Keep',
  'select'   => 'T',
  'maxlen'   => 1,
  'options|AVCDLF' => 'H',
  'default'  => '1',
  'sort'     => true
);
$pic=$ez_db->get_var("SELECT `profile_pic` FROM `$user_table` WHERE `id`=$uid AND `keep`=1");
// Now important call to phpMyEdit
if (isset($_REQUEST['PME_sys_operation']) and ( $_REQUEST['PME_sys_operation'] == 'PME_op_Add' or $_REQUEST['PME_sys_operation'] == 'PME_op_Delete' or
        $_REQUEST['PME_sys_operation'] == 'PME_op_Change' or $_REQUEST['PME_sys_operation'] == 'PME_op_View')) {
   echo '<div class="row"><div class="col-md-10 col-md-offset-2">';
   echo '<div class="panel col-lg-8 ">';
   echo '<div class="panel-heading bg-primary text-center"><h2><b>Security Profile</b></h2></div>';
   echo '<form role="form" method="post" id="" enctype="multipart/form-data"><div><div><br/>';
   echo '<div class="form-group pme-row-0 text-center"><div class="pme-value-0">
    <img class="img img-thumbnail" style="width:200px; heignt:200px;" src="'."$lib_dir/i/pr/$pic".'"/>
    </div></div>';
} else {
   echo '<div class="row"><div class="col-md-12">';
   echo '<form role="form" method="post" id="">';
}
require_once "$lib_dir/phpmyedit/phpMyEdit2.class.php";
new phpMyEdit($opts);

if (isset($_REQUEST['PME_sys_operation']) and ( $_REQUEST['PME_sys_operation'] == 'PME_op_Add' or $_REQUEST['PME_sys_operation'] == 'PME_op_Delete' or
        $_REQUEST['PME_sys_operation'] == 'PME_op_Change' or $_REQUEST['PME_sys_operation'] == 'PME_op_View')) {
   echo '</div>';
   echo '</div>';
   echo '<div class="form-group"></div></form><div class="col-lg-3"></div></div></div><br class="well-sm"/>&nbsp;<br class="well-sm"/>&nbsp;'
   . '<br class="well-sm"/>&nbsp;<br class="well-sm"/>';
} else {
   echo '<div class="form-group"></div></form>';
   echo '</div></div><br class="well-sm"/><br class="well-sm"/>';
}