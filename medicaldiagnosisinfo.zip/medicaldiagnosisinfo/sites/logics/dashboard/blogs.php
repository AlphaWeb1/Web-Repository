<script type="text/javascript">
$(document).ready(function(){
    pic_upload('#blog_pix','#b_img');
});
</script><?php global $lib_dir,$ez_db,$smarty,$db_name,$db_pass,$db_user,$the_host,$sites_dir,$blog_table,$user_table;
echo '<br class="well-sm"/><br class="well-sm"/><div class="row"><div class="col-md-4 btn-lg bg-primary text-justify"><h3>Dashboard:- Blogs</h3></div>
</div><br/>';
$back_dir = '<a href="?p=dashboard&t=blogs&PME_sys_operation=PME_op_List" class="btn btn-warning"><span class="glyphicon glyphicon-backward"></span> Back</a>';
$opts['hn'] = $the_host;
$opts['un'] = $db_user;
$opts['pw'] = $db_pass;
$opts['db'] = $db_name;
$opts['tb'] = 'blogs';
$t=  (use_if_sent_("t")==null?'home':use_if_sent_("t"));$p=  use_if_sent_("p");
// Name of field which is the unique key
$opts['key'] = 'id';

// Type of key field (int/real/string/date etc.)
$opts['key_type'] = 'int';
// Sorting field(s)
$opts['sort_field'] = array('-id');

// Number of records to display on the screen
// Value of -1 lists all records in a table
$opts['inc'] = 10;

// Options you wish to give the users
// A - add,  C - change, P - copy, V - view, D - delete,
// F - filter, I - initial sort suppressed
$opts['options'] = 'VLF';
$opts['filters'] = "`blog_type`='blog' AND `keep`=1";

$opts['buttons']['V']['down'] = array(
    '<input type="hidden" name="PME_sys_saveview" value="View" />',
    $back_dir
);

// Number of lines to display on multiple selection filters
$opts['multiple'] = '4';
$opts['buttons']['L']['down'] = array('<<','<','>','>>');

// Navigation style: B - buttons (default), T - text links, G - graphic links
// Buttons position: U - up, D - down (default)
$opts['navigation'] = 'DG';
$opts['url'] = array('images' => "$lib_dir/phpMyEdit/images/");

// Display special page elements
$opts['display'] = array(
    'form' => true,
    'query' => false,
    'sort' => false,
    'time' => false,
    'tabs' => false,
    'num_pages' => true,
    'num_records' => true
);
// Set default prefixes for variables
$opts['js']['prefix']               = 'PME_js_';
$opts['dhtml']['prefix']            = 'PME_dhtml_';
$opts['cgi']['prefix']['operation'] = 'PME_op_';
$opts['cgi']['prefix']['sys']       = 'PME_sys_';
$opts['cgi']['prefix']['data']      = 'PME_data_';

/* Get the user's default language and use it if possible or you can
   specify particular one you want to use. Refer to official documentation
   for list of available languages. */

$opts['cgi']['persist'] = array(
    'p' => use_if_sent_("p"),
    't' => $t,
);

$opts['language'] = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
$opts['fdd']['id'] = array(
  'name'     => 'ID',
  'select'   => 'T',
  'options'  => 'AVCPDR', // auto increment
  'options|AVCDLF' => 'H',
  'maxlen'   => 11,
  'default'  => '0',
  'sort'     => true
);
$opts['fdd']['username'] = array(
  'name'     => 'Username',
  'input'   => 'H',
  'options|VLF' => 'H',
  'maxlen'   => 255,
  'sort'     => true
);
$opts['fdd']['date_added'] = array(
  'name'     => 'Date Created',
  'input'   => 'R',
  'maxlen'   => 20,
  'default' => date('Y-m-d H:i:s'),
  'sort'     => true
);
$opts['fdd']['title'] = array(
  'name'     => 'Title',
  'input'   => 'T',
  'maxlen'   => 65535,
  'sort'     => true
);
$opts['fdd']['article'] = array(
  'name'     => 'Article',
  'input'   => 'T',
  'maxlen'   => 65535,
  'textarea' => array(
    'rows' => 3,
    'cols' => 50),
  'sort'     => true
);
$opts['fdd']['blog_pic'] = array(
  'name'     => 'Icon',
  'input'   => 'H',
  'options|DVLF' => 'H',
  'maxlen'   => 20,
  'sort'     => true
);
$opts['fdd']['keep'] = array(
  'name'     => 'Keep',
  'select'   => 'T',
  'maxlen'   => 1,
  'options|AVCDLF' => 'H',
  'default'  => '1',
  'sort'     => true
);
// Now important call to phpMyEdit
if (isset($_REQUEST['PME_sys_operation']) and ($_REQUEST['PME_sys_operation'] == 'PME_op_View')) {
    $sys_rec=use_if_sent_('PME_sys_rec');
$pic=$ez_db->get_var("SELECT `blog_pic` FROM `$blog_table` WHERE `id`=$sys_rec AND `keep`=1");
$blog_user=$ez_db->get_var("SELECT `username` FROM `$blog_table` WHERE `id`=$sys_rec AND `keep`=1");
$pic2=$ez_db->get_var("SELECT `profile_pic` FROM `$user_table` WHERE `username`='$blog_user'");
   echo '<div class="row"><div class="col-md-10 col-md-offset-2">';
   echo '<div class="panel col-lg-8 ">';
   echo '<div class="panel-heading bg-primary text-center"><h2><b>Blog</b></h2></div>';
   echo '<form role="form" method="post" id="" enctype="multipart/form-data"><div><div><br/>';
   echo '<div class="form-group pme-row-0 text-center"><div class="pme-value-0"><label for="blog_pix">
<img class="img img-thumbnail" style="width:150px; heignt:150px;" id="b_img" src="'."$lib_dir/i/pr/$pic2".'"/>
<img class="img img-thumbnail" style="width:100px; heignt:100px;" id="b_img" src="'."$lib_dir/i/ic/$pic".'"/></label>
</div></div>';
   if($_REQUEST['PME_sys_operation'] == 'PME_op_Change' OR $_REQUEST['PME_sys_operation'] == 'PME_op_Add'){
   echo '<div class="form-group pme-row-0">
<label for="blog_pix" class="control-label pme-key-0">Blog Icon</label><div class="pme-value-0">
<input class="form-control input-sm pme-input-0" type="file" id="blog_pix" name="blog_pix" size="60">
</div></div>';
        }
} else {
   echo '<div class="row"><div class="col-md-12">';
   echo '<form role="form" method="post" id="">';
}
require_once "$lib_dir/phpmyedit/phpMyEdit2.class.php";
new phpMyEdit($opts);
if (isset($_REQUEST['PME_sys_operation']) and ( $_REQUEST['PME_sys_operation'] == 'PME_op_Add' or $_REQUEST['PME_sys_operation'] == 'PME_op_Delete' or
        $_REQUEST['PME_sys_operation'] == 'PME_op_Change' or $_REQUEST['PME_sys_operation'] == 'PME_op_View')) {
   echo '</div>';
   echo '</div>';
   echo '<div class="form-group"></div></form><div class="col-lg-3"></div></div></div><br class="well-sm"/>&nbsp;<br class="well-sm"/>&nbsp;'
   . '<br class="well-sm"/>&nbsp;<br class="well-sm"/>';
} else {
   echo '<div class="form-group"></div></form>';
   echo '</div></div><br class="well-sm"/><br class="well-sm"/>';
}