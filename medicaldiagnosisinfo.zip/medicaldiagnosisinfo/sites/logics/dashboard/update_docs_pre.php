<?php global $user,$uid,$lib_dir,$ez_db,$smarty,$sites_dir,$user_table,$blog_table;
$doc_file=use_if_file_('doc_file');$url="$lib_dir/f/ebooks/";$pme_op=  use_if_sent_('PME_sys_operation');
if (($doc_file['tmp_name'])!=null) {  $username=$ez_db->get_var("SELECT `username` FROM `$user_table` WHERE `token`='$user';");
$newvals['file_name']=get_file_name_($doc_file);
    if (isset($_REQUEST['PME_sys_saveadd']) and $pme_op=='PME_op_Add') {
        $sys_rec=  inc_table_("documents", "id");$newvals['username']=$username;
    }
    if (isset($_REQUEST['PME_sys_savechange']) and $pme_op=='PME_op_Change') { 
        $sys_rec=use_if_sent_('PME_sys_rec');$newvals['username']=$username;
    }$newvals['saved_name']="$sys_rec"."_".$username."_".get_file_name_($doc_file);
    if (file_exists($url.$newvals['saved_name'])) {    unlink($url.$newvals['saved_name']);   }
    if (check_doc_($doc_file, $newvals['saved_name'], $url)==false) {  $smarty->display("msg_display.html");    return;    }
    if (isset($_REQUEST['PME_sys_savechange']) and $pme_op=='PME_op_Change') { 
        if (file_exists($url.$oldvals['saved_name']) and $oldvals['saved_name']!=$newvals['saved_name']) {    unlink($url.$oldvals['saved_name']);   }
    }
}else{  $newvals['saved_name']=$newvals['saved_name'];
    if (isset($_REQUEST['PME_sys_saveadd']) and $pme_op=='PME_op_Add') {
        $newvals['saved_name']="";
    }
    if (isset($_REQUEST['PME_sys_savechange']) and $pme_op=='PME_op_Change') { 
        $newvals['saved_name']=$newvals['saved_name'];
    }
}
if (isset($_REQUEST['PME_sys_saveadd']) and $pme_op=='PME_op_Add') {
    $smarty->assign("msg", array("type" => "info", "title" => "Document Update", "content" => "medical document is successfully added.",
            "close" => "true")); $smarty->display("msg_display.html");
}
if (isset($_REQUEST['PME_sys_savechange']) and $pme_op=='PME_op_Change') { 
    $smarty->assign("msg", array("type" => "info", "title" => "Document Update", "content" => "medical document is updated successfully.",
            "close" => "true")); $smarty->display("msg_display.html");
}