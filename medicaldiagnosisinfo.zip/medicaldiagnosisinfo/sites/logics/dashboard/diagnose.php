<?php global $user, $ez_db, $smarty, $lib_dir, $user_table; $for=0; $diag=""; $recs=null;
if (($diag=use_if_sent_('diag'))!=NULL) {
    $optns=  explode(",", $diag);$where2="";$c=0;
    foreach ($optns as $vals) {
        $where2.=($c==0?" `symptoms` LIKE'%$vals%' ":" AND `symptoms` LIKE'%$vals%' ");$c++;
    }
    $fields="`diagnosis`.`id`,`profile_pic`,`firstname`,`othernames`,`medical_disorder`,`treatment_procedure`,`symptoms`,`causes`,`date_added`"; 
    $where="`diagnosis`.`username`=`$user_table`.`username` AND ($where2) AND `diagnosis`.`keep`=1;"; $order="`date_added` DESC"; 
    $count="`diagnosis`.`id`";$tbl="`diagnosis`,`$user_table`";
    $prec = $ez_db->get_var("SELECT COUNT($count) FROM $tbl WHERE $where;");
    $pages = get_pages($prec, 10);
    $params = next_prev($prec, "$fields", "$tbl", " WHERE $where ORDER BY $order;", $fr = 0, $lmt = 10);
    $smarty->assign("nav_conts", array("lmt" => $lmt, "rl" => $params['rl'], "pn" => $params['pn'], "pr" => $params['pr'], "nr" => $params['nr'], 
        "total" => $prec, "pages" => $pages));
    $recs=$params['records'];
}
$smarty->assign("records", $recs);
$smarty->assign("msg",array("title"=>"Message","content"=>"No Record Found!!!","type"=>"danger"));
$smarty->assign("diag", $diag);