<?php global $user,$lib_dir,$ez_db,$smarty,$db_name,$db_pass,$db_user,$the_host,$sites_dir,$user_table,$uid,$usertype;$s_name=null;
$user = get_user_("user_log");$sys_op= use_if_sent_('PME_sys_operation');
$sys_rec=use_if_sent_('PME_sys_rec');
$username=$ez_db->get_var("SELECT `username` FROM `$user_table` WHERE `token`='$user';");
if ($sys_rec!=NULL) {
    $test_user=$ez_db->get_var("SELECT `username` FROM `documents` WHERE `id`=$sys_rec AND `keep`=1");
    $s_name=$ez_db->get_var("SELECT `saved_name` FROM `documents` WHERE `id`=$sys_rec AND `keep`=1");
    $f_name=$ez_db->get_var("SELECT `file_name` FROM `documents` WHERE `id`=$sys_rec AND `keep`=1");
    $source=$lib_dir.'/f/ebooks/'.$s_name;$dest=$lib_dir.'/f/download/'.$f_name;
    if (file_exists($dest)) {
        unlink($dest);
    }copy($source, $dest);
}else{$test_user=$username;
}
if ($test_user!=$username and $sys_op!='PME_op_View' and $sys_op!='PME_op_Add' or ($usertype==0 and ($sys_op=='PME_op_Add' or $sys_op=='PME_op_Change'))) {
    header("location:?p=dashboard&t=documents&PME_sys_operation=PME_op_List");
}
echo '<br class="well-sm"/><br class="well-sm"/><div class="row"><div class="col-md-4 btn-lg bg-primary text-justify"><h3>Dashboard:- Medical Documents</h3></div>
<div class="col-md-8"><br class="well-sm"/>'.($usertype==1?'<a href="?p=dashboard&t=documents&PME_sys_operation=PME_op_Add" class="btn btn-primary">
<span class="glyphicon glyphicon-plus-sign"></span> Add Document</a>':'').'</div></div><br/>';
$back_dir = '<a href="?p=dashboard&t=documents&PME_sys_operation=PME_op_List" class="btn btn-warning"><span class="glyphicon glyphicon-backward"></span> Back</a>';
$opts['hn'] = $the_host;
$opts['un'] = $db_user;
$opts['pw'] = $db_pass;
$opts['db'] = $db_name;
$opts['tb'] = 'documents';
$t=  (use_if_sent_("t")==null?'home':use_if_sent_("t"));$p=  use_if_sent_("p");
// Name of field which is the unique key
$opts['key'] = 'id';

// Type of key field (int/real/string/date etc.)
$opts['key_type'] = 'int';
// Sorting field(s)
$opts['sort_field'] = array('-id');

// Number of records to display on the screen
// Value of -1 lists all records in a table
$opts['inc'] = 10;

// Options you wish to give the users
// A - add,  C - change, P - copy, V - view, D - delete,
// F - filter, I - initial sort suppressed
$opts['options'] = ($usertype==1?'AVCDLF':'VLF');
$opts['filters'] = (($test_user!=$username)?"`username`='$username' AND ":"")."`keep`=1";//need review


$opts['buttons']['A']['down'] = array(
    '<input type="hidden" name="PME_sys_saveadd" value="Save" />',
    '<button class="btn btn-primary btn-sm" name="Submit" id="Submit" onclick="return PME_js_form_control(this.form);" type="submit">
  <span class="glyphicon glyphicon-file"></span> Add Document</button>',
    $back_dir
);

$opts['buttons']['C']['down'] = array(
    '<input type="hidden" name="PME_sys_savechange" value="Save" />',
    '<button class="btn btn-primary btn-lg" name="Submit" id="Submit" onclick="return PME_js_form_control(this.form);" type="submit">
      <span class="glyphicon glyphicon-edit"></span> Update Document.</button>',
    $back_dir
);

$opts['buttons']['D']['down'] = array(
    '<input type="hidden" name="PME_sys_savedelete" value="Delete" />',
    '<button class="btn btn-danger btn-lg" name="Submit" id="Submit" onclick="return PME_js_form_control(this.form);" type="submit">
  <span class="glyphicon glyphicon-remove"></span> Remove Document.</button>',
    $back_dir
);

$opts['buttons']['V']['down'] = array(
    '<input type="hidden" name="PME_sys_saveview" value="View" />',
    ($sys_rec=="" || $sys_rec==NULL?'':'<a href="'.$lib_dir.'/f/download/'.$f_name.'" class="btn btn-info">
<span class="glyphicon glyphicon-download"></span> Download Document</a>'),
    $back_dir
);

// Number of lines to display on multiple selection filters
$opts['multiple'] = '4';
$opts['buttons']['L']['down'] = array('<<','<','>','>>');

// Navigation style: B - buttons (default), T - text links, G - graphic links
// Buttons position: U - up, D - down (default)
$opts['navigation'] = 'DG';
$opts['url'] = array('images' => "$lib_dir/phpMyEdit/images/");

// Display special page elements
$opts['display'] = array(
    'form' => true,
    'query' => false,
    'sort' => false,
    'time' => false,
    'tabs' => false,
    'num_pages' => true,
    'num_records' => true
);
// Set default prefixes for variables
$opts['js']['prefix']               = 'PME_js_';
$opts['dhtml']['prefix']            = 'PME_dhtml_';
$opts['cgi']['prefix']['operation'] = 'PME_op_';
$opts['cgi']['prefix']['sys']       = 'PME_sys_';
$opts['cgi']['prefix']['data']      = 'PME_data_';

/* Get the user's default language and use it if possible or you can
   specify particular one you want to use. Refer to official documentation
   for list of available languages. */

$opts['triggers']['update']['before']  = "$sites_dir/logics/$p/update_docs_pre.php";
$opts['triggers']['insert']['before'] = "$sites_dir/logics/$p/update_docs_pre.php";

$opts['cgi']['persist'] = array(
    'p' => use_if_sent_("p"),
    't' => $t,
);

$opts['language'] = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
$opts['fdd']['id'] = array(
  'name'     => 'ID',
  'select'   => 'T',
  'options'  => 'AVCPDR', // auto increment
  'options|AVCDLF' => 'H',
  'maxlen'   => 11,
  'default'  => '0',
  'sort'     => true
);
$opts['fdd']['username'] = array(
  'name'     => 'Username',
  'input'   => 'H',
  'options|VLF' => 'H',
  'maxlen'   => 255,
  'default'  =>$username,
  'sort'     => true
);
$opts['fdd']['file_name'] = array(
  'name'     => 'Document Name',
  'input'   => 'H',
  'maxlen'   => 255,
  'sort'     => true
);
$opts['fdd']['saved_name'] = array(
  'name'     => 'Saved Name',
  'input'   => 'H',
  'options|VLF' => 'H',
  'maxlen'   => 255,
  'sort'     => true
);
$opts['fdd']['title'] = array(
  'name'     => 'Document Heading',
  'input'   => 'T',
  'maxlen'   => 255,
  'sort'     => true
);
$opts['fdd']['description'] = array(
  'name'     => 'File Descrition',
  'input'   => 'T',
  'options|LF' => 'H',
  'maxlen'   => 65535,
  'textarea' => array(
    'rows' => 5,
    'cols' => 50),
  'sort'     => true
);
$opts['fdd']['date_added'] = array(
  'name'     => 'Date Sent',
  'input'   => 'R',
  'maxlen'   => 20,
  'default' => date('Y-m-d H:i:s'),
  'sort'     => true
);
$opts['fdd']['keep'] = array(
  'name'     => 'Keep',
  'select'   => 'T',
  'maxlen'   => 1,
  'options|AVCDLF' => 'H',
  'default'  => '1',
  'sort'     => true
);
// Now important call to phpMyEdit
if (isset($_REQUEST['PME_sys_operation']) and ( $_REQUEST['PME_sys_operation'] == 'PME_op_Add' or $_REQUEST['PME_sys_operation'] == 'PME_op_Delete' or
        $_REQUEST['PME_sys_operation'] == 'PME_op_Change' or $_REQUEST['PME_sys_operation'] == 'PME_op_View')) { $pic=null;
    if ($sys_op != 'PME_op_Add') {
        $sys_rec=use_if_sent_('PME_sys_rec');
        $test_user=$ez_db->get_var("SELECT `username` FROM `documents` WHERE `id`=$sys_rec AND `keep`=1");
        $pic=$ez_db->get_var("SELECT `profile_pic` FROM `$user_table` WHERE `username`='$test_user'");
    }else{
        $pic=$ez_db->get_var("SELECT `profile_pic` FROM `$user_table` WHERE `username`='$username'");
    }
   echo '<div class="row"><div class="col-md-10 col-md-offset-2">';
   echo '<div class="panel col-lg-8 ">';
   echo '<div class="panel-heading bg-primary text-center"><h2><b>Medical Document / File.</b></h2></div>';
   echo '<form role="form" method="post" id="" achion="" enctype="multipart/form-data"><div><div><br/>';
   echo '<div class="form-group pme-row-0 text-center"><div class="pme-value-0"><label>
<img class="img img-thumbnail" style="width:100px; heignt:100px;" src="'."$lib_dir/i/pr/$pic".'"/></label>
</div></div>';
  if($sys_op == 'PME_op_Change' OR $sys_op == 'PME_op_Add'){
   echo '<div class="form-group pme-row-0">
<label for="doc_file" class="control-label pme-key-0">Document to Upload</label><div class="pme-value-0">
<input class="form-control input-sm pme-input-0" type="file" id="doc_file" '.($sys_op=='PME_op_Add'?'required':'').' name="doc_file" size="60" maxlength="65535">
</div></div>';
        }
} else {
   echo '<div class="row"><div class="col-md-12">';
   echo '<form role="form" method="post" id="">';
}
require_once "$lib_dir/phpmyedit/phpMyEdit2.class.php";
new phpMyEdit($opts);
if (isset($_REQUEST['PME_sys_operation']) and ( $_REQUEST['PME_sys_operation'] == 'PME_op_Add' or $_REQUEST['PME_sys_operation'] == 'PME_op_Delete' or
        $_REQUEST['PME_sys_operation'] == 'PME_op_Change' or $_REQUEST['PME_sys_operation'] == 'PME_op_View')) {
   echo '</div>';
   echo '</div>';
   echo '<div class="form-group"></div></form><div class="col-lg-3"></div></div></div><br class="well-sm"/>&nbsp;<br class="well-sm"/>&nbsp;'
   . '<br class="well-sm"/>&nbsp;<br class="well-sm"/>';
} else {
   echo '<div class="form-group"></div></form>';
   echo '</div></div><br class="well-sm"/><br class="well-sm"/>';
}