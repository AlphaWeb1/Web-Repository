<?php global $user, $uid, $lib_dir, $ez_db, $smarty, $sites_dir, $file_table;
$file_rec = use_if_sent_('PME_sys_rec');
echo '<hr/>
<div class="row">
    <div class="col-md-4 btn-lg bg-warning text-justify"><h3>Dashboard: Files and Folder</h3></div>
    <div class="col-md-8"><br class="well-sm"/>
        <a href="?p=dashboard&t=dirs" class="btn btn-warning"><span class="glyphicon glyphicon-file"></span> Back</a>
        <a href="?p=dashboard&t=home" class="btn btn-info"><span class="glyphicon glyphicon-briefcase"></span> Log Summary</a> 
    </div>
</div><hr/>';

if (($downloadOpt = use_if_sent_('download_opt')) != null) {
    $file_record = $ez_db->get_row("SELECT `enc_name`,`file_name`,`dir_name`,`enc_id` FROM `$file_table` WHERE `username`='$user' AND `id`=$file_rec "
            . "AND `keep`=1");
    $file = file("$lib_dir/f/$file_record->dir_name/$file_record->enc_name");
    if ($downloadOpt == 12) {
        if (file_exists($lib_dir . "/f/$file_record->dir_name/" . $file_record->enc_name)) {
            $file_string = file_get_contents($lib_dir . "/f/$file_record->dir_name/" . $file_record->enc_name);
            $file_string = base64_encode($file_string);
            if (file_exists($lib_dir . "/temp_f/$file_record->file_name")) {
                unlink($lib_dir . "/temp_f/$file_record->file_name");
            }
            file_put_contents($lib_dir . "/temp_f/$file_record->file_name", $file_string);
            $smarty->assign("msg", array("type" => "info", "title" => "Download", "content" => "Note: this download is encrypted version!!!<br/>"
                . "This file is successfully proccessed for download please click the file name below to download!!!<br/> "
                . "<a href='" . $lib_dir . "/temp_f/$file_record->file_name' class='btn btn-success text-capitalized'>$file_record->file_name</a>", "close" => "false"));
        }
    } elseif ($downloadOpt == 15) {
        //new form for key
        echo '<div class="row"><div class="col-md-10 col-md-offset-2">';
        echo '<div class="panel col-lg-8 ">';
        echo '<div class="panel-heading bg-danger text-center"><h2><b> '.$file_record->file_name.'</b></h2></div>';
        echo '<form role="form" method="post" action="?p=dashboard&t=download&download_opt=17" id=""><div><div><br/> '
        . '<input name="PME_sys_rec" type="hidden" value="'.$file_rec.'" />';
        echo '<div class="form-group pme-row-0">
         <label for="crypto_key" class="control-label pme-key-0">Cryptographic Key</label><div class="pme-value-0">
         <input class="form-control" type="text" value="" required id="crypto_key" name="crypto_key" size="60"/>
         </div></div>';
        echo '<div class="form-group pme-row-0">
         <button class="btn btn-info btn-lg" name="Submit" id="Submit" type="submit"><span class="glyphicon glyphicon-open"></span> Decrypt File.</button>
         </div></div>';
        echo '</div>';
        echo '</div>';
        echo '<div class="form-group"></div></form><div class="col-lg-3"></div></div></div><br class="well-sm"/>&nbsp;<br class="well-sm"/>&nbsp;'
        . '<br class="well-sm"/>&nbsp;<br class="well-sm"/>';
    } elseif ($downloadOpt == 17) {$crypt_key=  use_if_sent_('crypto_key'); 
    $public_key = $ez_db->get_var("SELECT `crypt_key` FROM `users` WHERE `username`='$user' AND `keep`=1");
        if (strtolower($crypt_key)==strtolower($file_record->enc_id) or strtolower($crypt_key)==strtolower($public_key)) {
            if (file_exists($lib_dir . "/f/$file_record->dir_name/" . $file_record->enc_name)) {
                $file_string = file_get_contents($lib_dir . "/f/$file_record->dir_name/" . $file_record->enc_name);
                if (file_exists($lib_dir . "/temp_f/$file_record->file_name")) {
                    unlink($lib_dir . "/temp_f/$file_record->file_name");
                }
                file_put_contents($lib_dir . "/temp_f/$file_record->file_name", $file_string);
                $smarty->assign("msg", array("type" => "info", "title" => "Download", "content" => 
                    "This file is successfully proccessed and decrypted for download please click the file name below to download!!!<br/> "
                    . "<a href='" . $lib_dir . "/temp_f/$file_record->file_name' class='btn btn-success text-capitalized'>$file_record->file_name</a>", "close" => "false"));
            }
        }else{
            $smarty->assign("msg", array("type" => "danger", "title" => "Error: Message", "content" => "This file cannot be decrypted because of invalid decryption key!!!<br/>", "close" => "false"));
        }
    }
} else {
    $smarty->assign("msg", array("type" => "danger", "title" => "Error: Corrupt URL", "content" => "This file cannot be downloaded !!!", "close" => "false"));
}$smarty->display("msg_display.html");
return;
