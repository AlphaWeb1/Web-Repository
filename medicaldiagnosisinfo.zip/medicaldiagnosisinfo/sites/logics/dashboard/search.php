<?php global $user, $ez_db, $smarty, $blog_table,$lib_dir, $user_table; $for=0; $srch_param=""; $recs=null;
$user = get_user_("user_log");
$username=$ez_db->get_var("SELECT `username` FROM `$user_table` WHERE `token`='$user';");
if (($for=  use_if_sent_('srch_for'))!=NULL) {
if (($srch_param=use_if_sent_('srch_param'))!=NULL) {
    if ($for==0) {
        $fields="`documents`.`id`,`firstname`,`othernames`,`file_name`,`saved_name`,`description`,`title`,`date_added`"; 
        $where="`documents`.`username`=`$user_table`.`username` AND (`title` LIKE'%$srch_param%' OR `file_name` LIKE'%$srch_param%' OR `description` "
            . "LIKE'%$srch_param%') AND `documents`.`keep`=1;"; $order="`date_added` DESC"; $count="`documents`.`id`";$tbl="`documents`,`$user_table`";
    }elseif ($for==1) {
        $fields="`blogs`.`id`,`blog_pic`,`firstname`,`othernames`,`blog_pic`,`article`,`title`,`date_added`"; $tbl="`blogs`,`$user_table`";
        $where="`blogs`.`username`=`$user_table`.`username` AND (`title` LIKE'%$srch_param%' OR `article` LIKE'%$srch_param%') AND `blog_type`='blog' "
                . "AND `blogs`.`keep`=1;"; $order="`date_added` DESC"; $count="`blogs`.`id`";
    }elseif ($for==2) {
        $fields="`blogs`.`id`,`blog_pic`,`firstname`,`othernames`,`blog_pic`,`article`,`title`,`date_added`"; $tbl="`blogs`,`$user_table`";
        $where="`blogs`.`username`=`$user_table`.`username` AND (`title` LIKE'%$srch_param%' OR `article` LIKE'%$srch_param%') AND `blog_type`='firstaid'"
                . " AND `blogs`.`keep`=1;"; $order="`date_added` DESC"; $count="`blogs`.`id`";
    }  
//    $prec = $ez_db->get_var("SELECT COUNT($count) FROM $tbl WHERE $where;");
//    $pages = get_pages($prec, 10);
//    $params = next_prev($prec, "$fields", "$tbl", " WHERE $where ORDER BY $order;", $fr = 0, $lmt = 10);  
}else{
    if ($for==0) {
        $fields="`documents`.`id`,`firstname`,`othernames`,`file_name`,`saved_name`,`description`,`title`,`date_added`"; $tbl="`documents`,`$user_table`";
        $where="`documents`.`username`=`$user_table`.`username` AND `documents`.`keep`=1 "; $order="`date_added` DESC"; $count="`documents`.`id`";
    }elseif ($for==1) {
        $fields="`blogs`.`id`,`blog_pic`,`firstname`,`othernames`,`blog_pic`,`article`,`title`,`date_added`"; $tbl="`blogs`,`$user_table`";$count="`blogs`.`id`";
        $where="`blogs`.`username`=`$user_table`.`username` AND `blog_type`='blog' AND `blogs`.`keep`=1 "; $order="`date_added` DESC"; 
    }elseif ($for==2) {
        $fields="`blogs`.`id`,`blog_pic`,`firstname`,`othernames`,`blog_pic`,`article`,`title`,`date_added`"; $tbl="`blogs`,`$user_table`";$count="`blogs`.`id`";
        $where="`blogs`.`username`=`$user_table`.`username` AND `blog_type`='firstaid' AND `blogs`.`keep`=1 "; $order="`date_added` DESC"; 
    } 
//    $prec = $ez_db->get_var("SELECT COUNT(`id`) FROM `files` WHERE (`department`='$user_info->department') AND (`level`='$level' AND "
//    . "`semester`='$semester') AND `keep`=1");
//    $pages = get_pages($prec, 10);
//    $params = next_prev($prec, "*", "`files`", " WHERE (`department`='$user_info->department') AND (`level`='$level' AND `semester`='$semester') "
//    . "AND `keep`=1 ORDER BY `file_name` ASC", $fr = 0, $lmt = 10);    
}
}else{
    $fields="`documents`.`id`,`firstname`,`othernames`,`file_name`,`saved_name`,`description`,`title`,`date_added`"; $tbl="`documents`,`$user_table`"; $for=0;
        $where="`documents`.`username`=`$user_table`.`username` AND `documents`.`keep`=1;"; $order="`date_added` DESC"; $count="`documents`.`id`";
}
 $prec = $ez_db->get_var("SELECT COUNT($count) FROM $tbl WHERE $where;");
 $pages = get_pages($prec, 10);
 $params = next_prev($prec, "$fields", "$tbl", " WHERE $where ORDER BY $order;", $fr = 0, $lmt = 10);
 
$recs=$params['records'];
$smarty->assign("nav_conts", array("lmt" => $lmt, "rl" => $params['rl'], "pn" => $params['pn'], "pr" => $params['pr'], "nr" => $params['nr'], 
    "total" => $prec, "pages" => $pages));
$smarty->assign("vars", array("for"=>$for,"param"=>$srch_param));$smarty->assign("records", $recs);
$smarty->assign("msg",array("title"=>"Message","content"=>"No Record Found!!!","type"=>"danger"));