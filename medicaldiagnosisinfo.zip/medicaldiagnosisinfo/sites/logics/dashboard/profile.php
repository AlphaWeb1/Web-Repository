<script type="text/javascript">
    $(document).on('change','#country, #state, #PME_data_state, #PME_data_country',function(){
        this.form.submit();
   });
</script>
<?php global $user,$lib_dir,$ez_db,$smarty,$db_name,$db_pass,$db_user,$the_host,$sites_dir,$uid,$user_table;$loop=1;
$user = get_user_("user_log");
$username=$ez_db->get_var("SELECT `username` FROM `$user_table` WHERE `token`='$user';");
if (isset($_REQUEST['PME_sys_rec'])) {  $_REQUEST['PME_sys_rec']=$uid;  }
echo '<hr/>
<div class="row">
    <div class="col-md-4 btn-lg bg-primary text-justify"><h3>Dashboard: Personal Profiles</h3></div>
    <div class="col-md-8"><br class="well-sm"/>
        <a href="?p=dashboard&t=security&PME_sys_operation=PME_op_View&PME_sys_rec='.$uid.'" class="btn btn-info"><span class="glyphicon glyphicon-lock"></span> Security Profiles</a>
        '.(isset($_REQUEST['PME_sys_operation'])?'<a href="?p=dashboard&t=home" class="btn btn-default">
        <span class="glyphicon glyphicon-home"></span> Home</a>':'').' 
    </div>
</div><hr/>';
$back_dir = '<a href="?p=dashboard&t=profile&PME_sys_operation=PME_op_View&PME_sys_rec='.$uid.'" class="btn btn-warning"><span class="glyphicon glyphicon-backward"></span> Back</a>';

$opts['hn'] = $the_host;
$opts['un'] = $db_user;
$opts['pw'] = $db_pass;
$opts['db'] = $db_name;
$opts['tb'] = $user_table;
$t=  use_if_sent_("t");$p=  use_if_sent_("p");
// Name of field which is the unique key
$opts['key'] = 'id';

// Type of key field (int/real/string/date etc.)
$opts['key_type'] = 'int';
// Sorting field(s)
$opts['sort_field'] = array('id');

// Number of records to display on the screen
// Value of -1 lists all records in a table
$opts['inc'] = 10;

// Options you wish to give the users
// A - add,  C - change, P - copy, V - view, D - delete,
// F - filter, I - initial sort suppressed
$opts['options'] = 'VCD';
$opts['filters'] = '`username`=\''.$username.'\' AND `keep`=1';


// Number of lines to display on multiple selection filters

$opts['buttons']['A']['down'] = array(
    '<input type="hidden" name="PME_sys_saveadd" value="Save" />',
    '<button class="btn btn-primary btn-sm" name="Submit" id="Submit" onclick="return PME_js_form_control(this.form);" type="submit">
  <span class="glyphicon glyphicon-floppy-disk"></span> Add User</button>',
    $back_dir
);

$opts['buttons']['C']['down'] = array(
    '<input type="hidden" name="PME_sys_savechange" value="Save" />',
    '<button class="btn btn-danger btn-lg" name="Submit" id="Submit" onclick="return PME_js_form_control(this.form);" type="submit">
      <span class="glyphicon glyphicon-edit"></span> Update Info.</button>',
    $back_dir
);

$opts['buttons']['D']['down'] = array(
    '<input type="hidden" name="PME_sys_savedelete" value="Delete" />',
    '<button class="btn btn-danger btn-lg" name="Submit" id="Submit" onclick="return PME_js_form_control(this.form);" type="submit">
  <span class="glyphicon glyphicon-remove"></span> Delete Info.</button>',
    $back_dir
);

$opts['buttons']['V']['down'] = array(
    '<input type="hidden" name="PME_sys_saveview" value="View" />',
    ((isset($_REQUEST['PME_sys_rec']) and $_REQUEST['PME_sys_rec'] != $uid)?'':' <a href="?PME_sys_fl=0&PME_sys_fm=0&PME_sys_sfn[0]=0&p=dashboard&t=profile&PME_sys_operation=PME_op_Change&PME_sys_rec='. $uid.'" 
    class="btn btn-primary btn-lg"><span class="glyphicon glyphicon-pencil"></span> Edit Profile</a>'),
    $back_dir
);

// Number of lines to display on multiple selection filters
$opts['multiple'] = '4';
$opts['buttons']['L']['down'] = array('');

// Navigation style: B - buttons (default), T - text links, G - graphic links
// Buttons position: U - up, D - down (default)
$opts['navigation'] = 'DG';
$opts['url'] = array('images' => "$lib_dir/phpMyEdit/images/");

// Display special page elements
$opts['display'] = array(
    'form' => true,
    'query' => false,
    'sort' => false,
    'time' => false,
    'tabs' => false,
    'num_pages' => false,
    'num_records' => true
);

// Set default prefixes for variables
$opts['js']['prefix']               = 'PME_js_';
$opts['dhtml']['prefix']            = 'PME_dhtml_';
$opts['cgi']['prefix']['operation'] = 'PME_op_';
$opts['cgi']['prefix']['sys']       = 'PME_sys_';
$opts['cgi']['prefix']['data']      = 'PME_data_';

/* Get the user's default language and use it if possible or you can
   specify particular one you want to use. Refer to official documentation
   for list of available languages. */

$opts['triggers']['update']['before']  = "$sites_dir/logics/$p/update_user_pre.php";
$opts['triggers']['delete']['before'] = "$sites_dir/logics/$p/delete_user_pre.php";

$opts['cgi']['persist'] = array(
    'p' => use_if_sent_("p"),
    't' => $t,
);

$opts['language'] = $_SERVER['HTTP_ACCEPT_LANGUAGE'];

$opts['fdd']['id'] = array(
  'name'     => 'ID',
  'select'   => 'T',
  'options'  => 'AVCPDR', // auto increment
  'options|AVCDLF' => 'H',
  'maxlen'   => 11,
  'default'  => '0',
  'sort'     => true
);
$opts['fdd']['username'] = array(
  'name'     => 'Username',
  'input'   => 'R',
  'maxlen'   => 255,
  'sort'     => true
);
$opts['fdd']['firstname'] = array(
  'name'     => 'First Name',
  'select'   => 'T',
  'maxlen'   => 65535,
  'sort'     => true
);
$opts['fdd']['othernames'] = array(
  'name'     => 'Othernames',
  'select'   => 'T',
  'maxlen'   => 65535,
  'sort'     => true
);
$opts['fdd']['phone'] = array(
  'name'     => 'Phone Number',
  'select'   => 'T',
  'maxlen'   => 20,
  'sort'     => true
);
$opts['fdd']['gender'] = array(
  'name'     => 'Gender',
  'select'   => 'O',
  'maxlen'   => 32,
  'values2'  => array('female'=>'Female','male'=>'Male'),
  'default'  => 'female',
  'sort'     => true
);

$opts['fdd']['country'] = array(
  'name'     => 'Country',
  'select'   => 'D',
  'maxlen'   => 32,
  'sort'     => true
);
$countries = $ez_db->get_results("SELECT `name` FROM `country` ORDER BY `name`ASC");
foreach ($countries as  $country) {
    $opts['fdd']['country']['values2'][$country->name]=$country->name;
}
$opts['fdd']['state'] = array(
  'name'     => 'State',
  'select'   => 'D',
  'maxlen'   => 32,
  'sort'     => true
);
$cty=$ez_db->get_var("SELECT `country` FROM `$user_table` WHERE `token`='$user' AND `keep`=1;");
if (isset($_REQUEST['country'])) {
   $cty = $_REQUEST['country'];
   $cid = $ez_db->get_var("SELECT `states` FROM `country` WHERE `name`='" . $cty . "'");
   if ($cid != "") {
      $states_id = explode("_", $cid);
      $str = "IN(" . $states_id[0];
      for ($x = 1; $x < count($states_id) - 1; $x++) {
         $str.="," . $states_id[$x];
      }$str.=")";
      $states = $ez_db->get_results("SELECT `name` from `states` WHERE `id` $str order by `name`ASC");
   }
}else{ 
    if ($_REQUEST['PME_sys_operation'] == 'PME_op_View') {
       $state=$ez_db->get_var("SELECT `state` FROM `$user_table` WHERE `token`='$user' AND `keep`=1;");
        $opts['fdd']['state']['values2'][$state]=$state;   
    }else{
        $cid = $ez_db->get_var("SELECT `states` FROM `country` WHERE `name`='" . $cty . "'");
        if ($cid != "") {
           $states_id = explode("_", $cid);
           $str = "IN(" . $states_id[0];
           for ($x = 1; $x < count($states_id) - 1; $x++) {
              $str.="," . $states_id[$x];
           }$str.=")";
           $states = $ez_db->get_results("SELECT `name` from `states` WHERE `id` $str order by `name`ASC");
            foreach ($states as  $state) {
                $opts['fdd']['state']['values2'][$state->name]=$state->name;
            }
        }
    }
}

$opts['fdd']['city'] = array(
  'name'     => 'City',
  'select'   => 'D',
  'maxlen'   => 32,
  'sort'     => true
);
$st=$ez_db->get_var("SELECT `state` FROM `$user_table` WHERE `token`='$user' AND `keep`=1;");
if (isset($_REQUEST['state'])) {
   $st= $_REQUEST['state'];
   $cid=$ez_db->get_var("SELECT `id` FROM `state` WHERE `name`='$st';");
   $lgas = $ez_db->get_results("SELECT `name` FROM `cities` WHERE `state_id`='$cid' order by `name` ASC");
    foreach ($lgas as  $lga) {
        $opts['fdd']['city']['values2'][$lga->name]=$lga->name;
    }
}else{ 
    if ($_REQUEST['PME_sys_operation'] == 'PME_op_View') {
       $lga=$ez_db->get_var("SELECT `city` FROM `$user_table` WHERE `token`='$user' AND `keep`=1;");
        $opts['fdd']['city']['values2'][$lga]=$lga;   
    }else{
       $cid=$ez_db->get_var("SELECT `id` FROM `states` WHERE `name`='$st';");
       $lgas = $ez_db->get_results("SELECT `name` FROM `cities` WHERE `state_id`='$cid' order by `name` ASC");
        foreach ($lgas as  $lga) {
            $opts['fdd']['city']['values2'][$lga->name]=$lga->name;
        }
    }
}
$opts['fdd']['address'] = array(
  'name'     => 'Address',
  'input'   => 'T',
  'maxlen'   => 65535,
  'textarea' => array(
    'rows' => 5,
    'cols' => 50),
  'default'  => 'female',
  'sort'     => true
);
$opts['fdd']['keep'] = array(
  'name'     => 'Keep',
  'select'   => 'T',
  'maxlen'   => 1,
  'options|AVCDLF' => 'H',
  'default'  => '1',
  'sort'     => true
);
$opts['fdd']['profile_pic'] = array(
  'name'     => 'Profile Picture',
  'input'   => 'H',
  'options|V' => 'H',
  'maxlen'   => 32,
  'sort'     => true
);
$pic=$ez_db->get_var("SELECT `profile_pic` FROM `$user_table` WHERE `id`=$uid AND `keep`=1");
// Now important call to phpMyEdit
if (isset($_REQUEST['PME_sys_operation']) and ( $_REQUEST['PME_sys_operation'] == 'PME_op_Add' or $_REQUEST['PME_sys_operation'] == 'PME_op_Delete' or
        $_REQUEST['PME_sys_operation'] == 'PME_op_Change' or $_REQUEST['PME_sys_operation'] == 'PME_op_View')) {
   echo '<div class="row"><div class="col-md-10 col-md-offset-2">';
   echo '<div class="panel col-lg-8 ">';
   echo '<div class="panel-heading bg-primary text-center"><h2><b>My Profile</b></h2></div>';
   echo '<form role="form" method="post" id="" enctype="multipart/form-data"><div><div><br/>';
   echo '<div class="form-group pme-row-0 text-center"><div class="pme-value-0">
<img class="img img-thumbnail" style="width:200px; heignt:200px;" src="'."$lib_dir/i/pr/$pic".'"/>
</div></div>';
   if($_REQUEST['PME_sys_operation'] == 'PME_op_Change'){
   echo '<div class="form-group pme-row-0">
<label for="profile_pix" class="control-label pme-key-0">Profile Picture</label><div class="pme-value-0">
<input class="form-control input-sm pme-input-0" type="file" id="profile_pix" name="profile_pix" size="60" maxlength="65535">
</div></div>';
        }
} else {
   echo '<div class="row"><div class="col-md-12">';
   echo '<form role="form" method="post" id="">';
}
require_once "$lib_dir/phpmyedit/phpMyEdit2.class.php";
new phpMyEdit($opts);
if ($loop==0) {
//$smarty->display("msg_display.html");
}
if (isset($_REQUEST['PME_sys_operation']) and ( $_REQUEST['PME_sys_operation'] == 'PME_op_Add' or $_REQUEST['PME_sys_operation'] == 'PME_op_Delete' or
        $_REQUEST['PME_sys_operation'] == 'PME_op_Change' or $_REQUEST['PME_sys_operation'] == 'PME_op_View')) {
   echo '</div>';
   echo '</div>';
   echo '<div class="form-group"></div></form><div class="col-lg-3"></div></div></div><br class="well-sm"/>&nbsp;<br class="well-sm"/>&nbsp;'
   . '<br class="well-sm"/>&nbsp;<br class="well-sm"/>';
} else {
   echo '<div class="form-group"></div></form>';
   echo '</div></div><br class="well-sm"/><br class="well-sm"/>';
}