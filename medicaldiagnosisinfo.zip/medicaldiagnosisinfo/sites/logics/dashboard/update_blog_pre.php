<?php global $user,$uid,$lib_dir,$ez_db,$smarty,$sites_dir,$user_table,$blog_table;
$t=  use_if_sent_('t');
$pict=use_if_file_('blog_pix');$url="$lib_dir/i/".(($t=='first_aid')?"fa":"ic")."/";$pme_op=  use_if_sent_('PME_sys_operation');
if (($pict['tmp_name'])!=null) {  $username=$ez_db->get_var("SELECT `username` FROM `$user_table` WHERE `token`='$user';");
    if (isset($_REQUEST['PME_sys_saveadd']) and $pme_op=='PME_op_Add') {
        $sys_rec=  inc_table_("$blog_table", "id");$newvals['username']=$username;
    }
    if (isset($_REQUEST['PME_sys_savechange']) and $pme_op=='PME_op_Change') { 
        $sys_rec=use_if_sent_('PME_sys_rec');$newvals['username']=$username;
    }$newvals['blog_pic']="$sys_rec"."_".$username."_".get_file_name_($pict);
    if (file_exists($url.$newvals['blog_pic'])) {    unlink($url.$newvals['blog_pic']);   }
    if (check_file_($pict, $newvals['blog_pic'], $url)==false) {  $smarty->display("msg_display.html");    return;    }
    if (isset($_REQUEST['PME_sys_savechange']) and $pme_op=='PME_op_Change') { 
        if (file_exists($url.$oldvals['blog_pic']) and $oldvals['blog_pic']!=$newvals['blog_pic']) {    unlink($url.$oldvals['blog_pic']);   }
    }
}else{  $newvals['blog_pic']=$newvals['blog_pic'];
    if (isset($_REQUEST['PME_sys_saveadd']) and $pme_op=='PME_op_Add') {
        $newvals['blog_pic']="";
    }
    if (isset($_REQUEST['PME_sys_savechange']) and $pme_op=='PME_op_Change') { 
        $newvals['blog_pic']=$newvals['blog_pic'];
    }
}
if (isset($_REQUEST['PME_sys_saveadd']) and $pme_op=='PME_op_Add') {
    $smarty->assign("msg", array("type" => "info", "title" => (($t=='first_aid')?"First aid":"Blog")." Update", "content" => 
        (($t=='first_aid')?"first aid":"blog")." is successfully added.", "close" => "true")); $smarty->display("msg_display.html");
}
if (isset($_REQUEST['PME_sys_savechange']) and $pme_op=='PME_op_Change') { 
    $smarty->assign("msg", array("type" => "info", "title" => (($t=='first_aid')?"First aid":"Blog")." Update", "content" => 
        (($t=='first_aid')?"first aid":"blog")." info. is updated successfully.","close" => "true")); $smarty->display("msg_display.html");
}