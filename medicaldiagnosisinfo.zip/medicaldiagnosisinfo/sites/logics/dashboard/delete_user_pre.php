<?php global $user,$uid,$lib_dir,$ez_db,$smarty,$sites_dir;
$ez_db->query("UPDATE `users` SET `keep`=0 WHERE `id`=$uid AND `username`='$user';");
header("location:?p=logout");
return;