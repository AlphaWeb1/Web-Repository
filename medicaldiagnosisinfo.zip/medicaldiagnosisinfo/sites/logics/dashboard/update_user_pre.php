<?php global $user,$uid,$lib_dir,$ez_db,$smarty,$sites_dir,$user_table;
$pict=use_if_file_('profile_pix');$url="$lib_dir/i/pr/";
if ((use_if_file_('profile_pix')['tmp_name'])!=null) {  $username=$ez_db->get_var("SELECT `username` FROM `$user_table` WHERE `token`='$user';");
    $newvals['profile_pic']="$uid"."_".$username."_".get_file_name_($pict);
    if (file_exists("$lib_dir/i/pr/".$newvals['profile_pic'])) {    unlink("$lib_dir/i/pr/".$newvals['profile_pic']);   }
    if (check_file_($pict, $newvals['profile_pic'], $url)==false) {  $smarty->display("msg_display.html");    return;    }
    if (file_exists("$lib_dir/i/pr/".$oldvals['profile_pic']) and 
        $oldvals['profile_pic']!=$newvals['profile_pic']) {    unlink("$lib_dir/i/pr/".$oldvals['profile_pic']);   }
    
}else{  $newvals['profile_pic']=$newvals['profile_pic'];
}$loop=0;
$smarty->assign("msg", array("type" => "success", "title" => "Profile Update Success", "content" => "profile information was successfully updated.",
            "close" => "true")); $smarty->display("msg_display.html");