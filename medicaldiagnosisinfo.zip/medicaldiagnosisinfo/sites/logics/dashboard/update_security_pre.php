<?php global  $smarty;
$smarty->assign("msg", array("type" => "success", "title" => "Security Update Success", "content" => "security information was successfully updated.",
            "close" => "true")); $smarty->display("msg_display.html");