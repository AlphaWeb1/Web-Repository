<?php
global $ez_db,$user_table, $smarty,$sites_dir;$user_names=NULL;
_session(1);
$user = get_user_("user_log");
$uid=  get_user_id_($user); $smarty->assign("uid","$uid");
$p= use_if_sent_("p");
if((!isset($user) and use_if_sent_("p")=='dashboard')){
_session(0);$p="home";
}elseif( use_if_sent_("p")==null){
_session(0);$p="home";
}else if(isset($user) and $user!=null){$usertype=$ez_db->get_var("SELECT `access` FROM `$user_table` WHERE `token`='$user' AND `keep`=1;");
$smarty->assign("tpe",$usertype);
$p="dashboard"; $user_names=$ez_db->get_var("SELECT CONCAT(`firstname`,' ',`othernames`,' (',`username`,')') FROM `$user_table` WHERE `token`='$user';");
}
if( use_if_sent_("t")!=null){ $t=  (use_if_sent_("t")==null?'home':use_if_sent_("t")); $smarty->assign("t","$t");
}
if(use_if_sent_("p")=="logout"){_session(0);$p="home";header("location:?p=home");}

$smarty->assign('title',get_page_title_("p"));
$smarty->assign("user_names",  $user_names);$smarty->assign("user",  $user);$smarty->assign("p",$p);
if($p!="cms"){
$smarty->display("site_header.html");
}
require_it_("$sites_dir/logics/$p");
if($error_code!='001'){
$page_error=get_page_error_($error_code);
$smarty->assign('error',$page_error);$smarty->display("error_page.html");
}



