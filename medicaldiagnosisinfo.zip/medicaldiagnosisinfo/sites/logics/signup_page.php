<?php global $ez_db, $smarty,$the_site,$sites_dir,$p; $t=null; $states = NULL; $cities = NULL;
$selected = array("country" => "", "state" => "", "city" => "");
if($error_code!='001'){
$page_error=get_page_error_($error_code);
$smarty->assign('error',$page_error);
}
if (($t=use_if_sent_('t'))!=null){ $smarty->assign("t","$t");
   $smarty->assign("t_file","$t.html"); require_it_("$sites_dir/logics/$p/$t.php");
}

require_once 'signup.php';
$countries = $ez_db->get_results("SELECT `name` FROM `country` ORDER BY `name`ASC");
if (isset($_REQUEST['country'])) {
   $selected["country"] = $_REQUEST['country'];
   $cid = $ez_db->get_var("SELECT `states` FROM `country` WHERE `name`='" . $selected["country"] . "'");
   if ($cid != "") {
      $states_id = explode("_", $cid);
      $str = "IN(" . $states_id[0];
      for ($x = 1; $x < count($states_id) - 1; $x++) {
         $str.="," . $states_id[$x];
      }$str.=")";
      $states = $ez_db->get_results("SELECT `name` from `states` WHERE `id` $str order by `name`ASC");
   }
}
if (isset($_REQUEST['state'])) {
   $selected["state"] = $_REQUEST['state'];
   $cid = $ez_db->get_var("SELECT `id` FROM `states` WHERE `name`='" . $selected["state"] . "'");
   $cities = $ez_db->get_results("SELECT `name` FROM `cities` WHERE `state_id`='$cid' order by `name` ASC");
}
if (isset($_REQUEST['city'])) {
   $selected["city"] = $_REQUEST['city'];
}
$smarty->assign("cities",$cities);  $smarty->assign("selected",$selected);  $smarty->assign("states",$states);$smarty->assign("countries",$countries);
$smarty->assign("vars",array("first"=>use_if_sent_('first'),"others"=>use_if_sent_('others'),"gender"=>use_if_sent_('gender'),
    "phone"=>use_if_sent_('phone'),"email"=>use_if_sent_('email'),"pass"=>use_if_sent_('pass'),"cpass"=>use_if_sent_('cpass'),
    "address"=>use_if_sent_('address'),"type"=>use_if_sent_('utype'),"user"=>use_if_sent_('username')));
$smarty->display("signup_page.html");