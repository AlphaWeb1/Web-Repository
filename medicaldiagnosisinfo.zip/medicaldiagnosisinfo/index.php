<?php
ob_start();
$command = basename(__FILE__);
require_once "config.php";
require_once "$lib_dir/functions.php";
require_once "$lib_dir/$db_dir/ezsql/ez_sql_core.php";
require_once "$lib_dir/$db_dir/ezsql/ez_sql_pdo.php";
require_once "$lib_dir/$db_dir/db_config.php";
require "$lib_dir/smarty.php";
if($error_code!='001'){
    $page_error=get_page_error_($error_code);
    $smarty->assign('error',$page_error);$smarty->assign('title','ERROR'); $smarty->display("error_page.html");
}else{
    require_once "$sites_dir/logics/bodies.php";
}
$smarty->display("footer.html");
?>