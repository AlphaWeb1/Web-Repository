<?php
global $command;
$the_host = str_replace("www.", "", $_SERVER["HTTP_HOST"]);
$the_server = php_uname('n')."_".$_SERVER['SERVER_ADDR'];
$this_dir = __DIR__;
$script_base = $_SERVER['PHP_SELF'];//web name of running script 

$script_path = dirname($script_base);//web directory of running script
$caller_dir = realpath(getenv('PHP_SELF'));//real directory of running script
$dir_path = substr($caller_dir, strlen($this_dir));//real path from web root to calling script
$the_port = $_SERVER['SERVER_PORT'];
$doc_root = $_SERVER['DOCUMENT_ROOT'];
$this_file = $doc_root.$script_base;
$sys_path = dirname($this_file);//use this instead of dirname(__FILE__) works when symlinking to $_SERVER['DOCUMENT_ROOT']??
if (strlen($dir_path)==0) {//substr returns an empty string if the third parameter is 0
    $web_folder = $script_path;
} else {
    $web_folder = substr($script_path, 0, -strlen($dir_path));//this folder relative to DOCUMENT_ROOT
}
$protocol="http";
$protocol.=((isset($_SERVER['HTTPS'])&&$_SERVER['HTTPS']=='on')?"s":"");
$protocol.="://";
$my_globals = array(
    'command'=>$command,
    'the_host'=>$the_host,
    'the_server'=>$the_server,
    'the_port'=>$the_port,
    'this_dir'=>$this_dir,
    'script_base'=>$script_base,
    'web_folder'=>$web_folder,
    'protocol'=>$protocol,
    'dbms'=>'mysql',
    'domain_name'=>'medicaldiagnosisinfo',
    'db_user'=>'root',
    'db_pass'=>'',
    'db_name'=>'medical_diag',
    'db_dir'=>'database',
    'error_code'=>'001',
    'ez_db'=>null,
    'lib_dir'=>'lib',
    'public_dir'=>'public',
    'inc_dir'=>'inc',
    'sites_dir'=>'sites',
    'page_mgt'=>'cms',
    'plugins_dir'=>'plugins',
    'content_table'=>'pages',
    'error_tbl'=>'errors',
    'user_table'=>'user_info',
    'file_table'=>'files',
    'blog_table'=>'blogs',
);
foreach ($my_globals as $key => $value) {
    $$key = $value;
}
