<?php
return date("F jS Y h:i A", time());
?>