<?php
return date("F jS Y h:i A", my_date($value));
?>