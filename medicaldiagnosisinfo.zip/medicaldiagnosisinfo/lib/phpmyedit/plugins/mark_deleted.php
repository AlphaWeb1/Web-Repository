<?php

$mark_record_as_deleted = sprintf('UPDATE %s SET `keep` = NULL WHERE `'.$this->key.'` = %d',
                  $this->tb, $oldvals[$this->key]);

$archive_table_name = $this->tb."_history";
$create_archive_table = sprintf("CREATE TABLE `$archive_table_name` LIKE `$this->tb`;");
$archive_deleted_records = sprintf("INSERT INTO `$archive_table_name` (SELECT * FROM `$this->tb` WHERE `keep` IS NULL)");
$purge_deleted_records = sprintf("DELETE FROM `$this->tb` WHERE `keep` IS NULL");

$this->MyQuery($mark_record_as_deleted);

if(check_if_table_exists($archive_table_name)){
}else{
    $this->MyQuery($create_archive_table);
}
if($this->MyQuery($archive_deleted_records)){
$this->MyQuery($purge_deleted_records);
}
export_table($this->tb);
return false;