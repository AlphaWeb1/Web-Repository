<?php
#MyCMS
#/lib/phpMyEdit/plugins/nice_slug.php
#2015/03/08 05:52:36 WAT
$the_slug= ascii_string($newvals['title']);
if($newvals['name']==""){$newvals['name'] = $the_slug;}
if($newvals['menu']==""){$newvals['menu'] = $newvals['title'];}

