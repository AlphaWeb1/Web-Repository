<?php
global $smarty,$the_site;
$user = $_SESSION["site_$the_site"]['username'];

if($_REQUEST['i'] == 'laboratory_settings'){
	$instid = filter_var($_REQUEST['id'], FILTER_SANITIZE_NUMBER_INT);
	$newvals['username'] = $instid;
}elseif($_REQUEST['i'] == 'availability'){
	$newvals['username'] = $user;	
}


