<?php //try{$ez_db=new ezSQL_pdo("$dbms:host=$the_host;dbname=".$db_name, "$db_user",$db_pass); }catch(Exception $e){}
if(check_db_exist_($db_name)!=true){ $error_code="502";
}else{ $ez_db=new ezSQL_pdo("$dbms:host=$the_host;dbname=".$db_name, "$db_user",$db_pass); 
}
