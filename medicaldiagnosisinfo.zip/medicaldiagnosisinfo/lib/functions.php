<?php

function _session($id) {
    if ($id == 1) {
        return @session_start();
    } elseif ($id == 0) {
        return @session_destroy();
    }
}

function check_control_header($smarty) {
    $smarty->display("header.php");
}

function check_db_exist_($dbs) {
    global $dbms, $db_user, $the_host, $db_pass;
    $return = false;
    $db = new PDO("$dbms:host=$the_host", "$db_user", "$db_pass");
    $query = $db->prepare("SHOW DATABASES;");
    $query->execute();
    if ($query->rowCount() > 0) {
        while ($data = $query->fetch()) {
            if ($data[0] == $dbs) {
                $return = true;
            }
        }
    }
    return $return;
}

function check_email_($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

function check_if_exists_($db_table, $db_field, $value) {
    global $ez_db;
    if ($ez_db->get_results("SELECT COUNT(`$db_field`) FROM `$db_table` WHERE `$db_field` = '" . $value . "'") > 0) {
        return true;
    } else {
        return false;
    }
}

function check_phone_($phone) {
    return filter_var($phone,FILTER_SANITIZE_NUMBER_INT);//still under construct
}

function check_key_validity_and_expiration_($key) {
//    under construct
}

function company_login_($code, $user, $pass) {
    global $ez_db,$smarty;
    if($ez_db->get_var("SELECT COUNT(`id`) FROM `users` WHERE (`username`='$user' OR `email`='$user') AND `keep`=1")>0){
        $rst=$ez_db->get_row("SELECT `username`,`password`,`token` FROM `users` WHERE `username`='$user'");
        if (strtolower($code)==strtolower($rst->token) or (strtolower($code)==strtolower($rst->token) and 
            strtolower($pass)!=strtolower($rst->password))) {
            set_session_("username", $rst->username);
            header("location:?p=dashboard");
        }elseif (($shss=strtolower(sha1(sha1($pass))))!=($psss=strtolower($rst->password))) {
            $smarty->assign("msg",array("title"=>"Message","content"=>"Invalid password!!!","type"=>"warning","close"=>'true'));
        }elseif (strtolower($code)!=strtolower($rst->token)) {
           $smarty->assign("msg",array("title"=>"Message","content"=>"Invalid token!!!","type"=>"warning","close"=>'true'));
        }
    }else{
      $smarty->assign("msg",array("title"=>"Message","content"=>"Invalid email or username!!!","type"=>"warning","close"=>'true')); 
    }
}

function crypto_rand_secure_($min, $max) {
    //http://us1.php.net/manual/en/function.openssl-random-pseudo-bytes.php#104322
    $range = $max - $min;
    if ($range < 0) {
        return $min; // not so random...
    } $log = log($range, 2);
    $bytes = (int) ($log / 8) + 1; // length in bytes
    $bits = (int) $log + 1; // length in bits
    $filter = (int) (1 << $bits) - 1; // set all lower bits to 1
    do {
        $rnd = hexdec(bin2hex(openssl_random_pseudo_bytes($bytes)));
        $rnd = $rnd & $filter; // discard irrelevant bits
    } while ($rnd >= $range);
    return $min + $rnd;
}

function customer_login_($user, $pass) {
//    still under construct
}

function get_a_col($tbl) {
    global $ez_db;
    if ($tbl != NULL) {
        $record = $ez_db->get_results("SELECT * FROM $tbl LIMIT 2");
        $fields = array();
        foreach ($record as $value) {
            $counter = 0;
            foreach ($value as $key => $val) {
                $fields[$counter] = $key;
                $counter++;
            } break;
        }
        return $fields[0];
    } else {
        return NULL;
    }
}

function check_file_($file,$pic_name,$url){
    global $ez_db,$smarty,$sites_dir;   $return=false;
    $target_file =$url.$pic_name."";    $fileType = pathinfo($target_file, PATHINFO_EXTENSION);
    if ($file==NULL) { $return=false;
       $smarty->assign("msg", array("type" => "warning", "title" => "Invalid File", "content" => "this is not a file or file is not selected.",
            "close" => "true"));
    }elseif (file_exists($target_file)) {
       $smarty->assign("msg",array("title"=>"File Exist","content"=>"there is an image file with this name or path, rename the image and reupload!!!",
           "type"=>"danger","close"=>"true"));
    }elseif (!(strtolower ($fileType) == "jpg" || strtolower ($fileType) == "jpeg" || strtolower ($fileType) == "jpe" || strtolower ($fileType) == "png" || strtolower ($fileType) == "gif")) {
       $smarty->assign("msg",array("title"=>"Error","content"=>"Sorry, only Image file is required.","type"=>"danger","close"=>"true"));
    }elseif(move_uploaded_file($file["tmp_name"], $target_file)){   $return=true;
    }
    return $return;
}

function check_doc_($file,$pic_name,$url){
    global $ez_db,$smarty,$sites_dir;   $return=false;
    $target_file =$url.$pic_name."";    $fileType = pathinfo($target_file, PATHINFO_EXTENSION);
    if ($file==NULL) { $return=false;
       $smarty->assign("msg", array("danger" => "warning", "title" => "Invalid File", "content" => "this is not a file or file is not selected.",
            "close" => "true"));
    }elseif (file_exists($target_file)) {
       $smarty->assign("msg",array("title"=>"File Exist","content"=>"there is a document file with this name or path, rename the file and reupload!!!",
           "type"=>"danger","close"=>"true"));
    }elseif (!(strtolower ($fileType) == "xls" || strtolower ($fileType) == "xlsx" || strtolower ($fileType) == "ppt" || 
            strtolower ($fileType) == "docm" || strtolower ($fileType) == "dotm" || strtolower ($fileType) == "pptx" || 
            strtolower ($fileType) == "txt" || strtolower ($fileType) == "dotx" || strtolower ($fileType) == "rtfx" || 
            strtolower ($fileType) == "dot" || strtolower ($fileType) == "doc" || strtolower ($fileType) == "docx" || 
            strtolower ($fileType) == "pdf" || strtolower ($fileType) == "pdfx" || strtolower ($fileType) == "rtf")) {
       $smarty->assign("msg",array("title"=>"Error","content"=>"Sorry, only Document files are required.","type"=>"danger","close"=>"true"));
    }elseif(move_uploaded_file($file["tmp_name"], $target_file)){   $return=true;
    }
    return $return;
}

function get_default_trid() {
    global $ez_db;  $token = "";
    do {    $token = get_token_(8);
    } while ($ez_db->get_var("SELECT COUNT(`id`) FROM `contracts` WHERE `transaction_id`='$token'") > 0);
    return $token;
}

function get_file_name_($param) {
    $return = null;
    if (is_file($param["tmp_name"])) {
        $return = basename($param["name"]);
    } return $return;
}

function inc_table_($table, $field) {
    global $ez_db;
    if (($return = $ez_db->get_var("SELECT COUNT(`$field`)+1 FROM `$table`;")) != null) {
        return $return;
    } else {
        return null;
    }
}

function get_pages($prec, $divisor) {
    $val1 = $prec / $divisor;
    $page = explode(".", "$val1");
    if (isset($page[1])) {
        $page[0] = (($page[1] > 0) ? filter_var($page[0], FILTER_VALIDATE_INT) +
                        1 : filter_var($page[0], FILTER_VALIDATE_INT));
        return $page[0];
    } else {
        return $val1;
    }
}

function get_page_before_last($prec, $divisor) {
    $val1 = $prec / $divisor;
    $page = explode(".", "$val1");
    return filter_var($page[0], FILTER_VALIDATE_INT);
}

function get_page_error_($error_code) {
    global $ez_db, $error_tbl;
    if ($error_code == "502") {
        return array("title" => "Database Error", "text" => "No database found in the server", "back_url" => "home", "code" => "502");
    } else {
        return $ez_db->get_row("SELECT `title`,`text`,`back_url`,`code` FROM `$error_tbl` WHERE `code`='$error_code' AND `keep`='1';");
    }
}

function get_page_title_($p) {
    global $ez_db, $content_table;
    $return = "Home";
    if (($url_p = use_if_sent_($p)) != null) {
        $return = $ez_db->get_var("SELECT `display_name` FROM `$content_table` WHERE `name`='$url_p' AND `keep`=1");
    }
    return $return;
}

function get_record_count($file, $fileType) {
    $content_count = false;
    if ($fileType == "xml") {
        $xml_file = simplexml_load_file($file);
        $content_count = count($xml_file->record);
    }
    return $content_count;
}

function get_session_($id) {
    if (isset($_SESSION[$id]) and $_SESSION[$id] != null) {
        return $_SESSION[$id];
    } else {
        return null;
    }
}

function get_token_($length) {
    //http://us1.php.net/manual/en/function.openssl-random-pseudo-bytes.php#104322
    $token = "";
    $codeAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $codeAlphabet.= "abcdefghijklmnopqrstuvwxyz";
    $codeAlphabet.= "0123456789";
    for ($i = 0; $i < $length; $i++) {
        $token .= $codeAlphabet[crypto_rand_secure_(0, strlen($codeAlphabet))];
    }
    return $token;
}

function get_user_($sid) {
    global $ez_db, $user_table;
    if (isset($_SESSION[$sid]) and $_SESSION[$sid] != null) {
        if ($ez_db->get_var("SELECT COUNT(`id`) FROM `$user_table` WHERE `token`='" . $_SESSION[$sid] . "' AND `keep`=1") > 0) {
            return $_SESSION[$sid];
        } else {
            return null;
        }
    } else {
        return null;
    }
}

function get_user_id_($user) {
    global $ez_db, $user_table;
    if ( ($usr=$ez_db->get_var("SELECT `id` FROM `$user_table` WHERE `token`='$user' AND `keep`=1")) !=null) {
        return $usr;
    } else {
        return null;
    }
}

function get_user_info_($infos, $user) {
    global $ez_db,$user_table;
    $return = null;
    if ($user != null) {
        $return = $ez_db->get_row("SELECT $infos FROM `$user_table` WHERE `token`='$user' AND `keep`=1");
    } return $return;
}

function get_user_type_($user) {
    global $ez_db, $user_table;
    $ez_db->get_var("SELECT `land_page` FROM `$user_table` WHERE `username`='$user' AND `keep`=1");
    return;
}

function get_where_construct_KMP($tbl, $recs, $db) {
    $return = "";
    $record = $db->get_results("SELECT * FROM $tbl LIMIT 2");
    $fields = array();
    foreach ($record as $value) {
        $counter = 0;
        foreach ($value as $key => $val) {
            $fields[$counter] = $key;
            $counter++;
        } break;
    }
    if ($recs != NULL and $tbl != NULL) {
        $params = explode(" ", $recs);
        $where_str = "";
        $x = 0;
        $y = 0;
        foreach ($fields as $value2) {
            foreach ($params as $param) {
                if ($x == 0 and $y == 0) {
                    $where_str.="`$value2`='%$param%'";
                } else {
                    $where_str.=" OR `$value2`LIKE'%$param%'";
                }
                $y++;
            }
            $x++;
        }
        $return = "WHERE " . $where_str;
    }
    return $return . "  ORDER BY `" . (($recs != NULL and $recs != "") ? $fields[1] : $fields[0]) . "` ASC";
}

function next_prev($prec, $tbcols, $tbn, $querycond, $fr, $lmt) {
    global $ez_db;
    if (!isset($_REQUEST['nxtrec'], $_REQUEST['prerec']) or isset($_REQUEST['prev_start'])) {
        $nr = $lmt;
        $pr = 0;
        $pn = 1;
        $recleft = $prec;
        $records = table_navs($tbcols, $tbn, $querycond, $fr, $lmt);
    }

    if (isset($_REQUEST['next'])) {
        $nr = $_POST['nxtrec'];
        $records = table_navs($tbcols, $tbn, $querycond, $nr, $lmt);

        $recleft = $prec - $nr;
        $pn = $_POST['pn'] + 1;
        $nr = $_POST['nxtrec'] + $lmt;
        if ($pn == 2) {
            $pr = 0;
        } else {
            $pr = $_POST['nxtrec'] - $lmt;
        }
    }

    if (isset($_REQUEST['next_end'])) {
        $nr = (get_page_before_last($prec, $lmt) * $lmt);
        $records = table_navs($tbcols, $tbn, $querycond, $nr, $lmt);

        $recleft = $prec - $nr;
        $pn = get_pages($prec, $lmt);
        $nr = (get_page_before_last($prec, $lmt) * $lmt) + $lmt;
        if ($pn == 2) {
            $pr = 0;
        } else {
            $pr = (get_page_before_last($prec, $lmt) * $lmt) - $lmt;
        }
    }

    if (isset($_REQUEST['prev'])) {
        $pr = $_POST['prerec'];
        $records = table_navs($tbcols, $tbn, $querycond, $pr, $lmt);

        $recleft = + $lmt;
        if ($pr == 0) {
            $recleft = $prec;
            $pn = 1;
            $pr = $_POST['prerec'];
            $nr = $_POST['nxtrec'] - $lmt;
        } else {
            $recleft = $_POST['rl'] + $lmt;
            $pn = $_POST['pn'] - 1;
            $pr = $pr - $lmt;
            $nr = $_POST['nxtrec'] - $lmt;
        }
    }
    return array('pn' => $pn, 'rl' => $recleft, 'pr' => $pr, 'nr' => $nr, "records" => $records);
}

function require_it_($p) {
    global $error_code;
    if (file_exists("$p.php")) {
        require_once "$p.php";
    } else {
        $error_code = "505";
    }
}

function send_mail_to_($email, $profl, $key=null) {
    global $domain_name, $the_host, $protocol;
    $return = true;
    $the_site_path = "$protocol$the_host/$domain_name";
//    $the_site_path = "http://$domain_name";
    $the_link = $the_site_path . "/?p=confirm_signup&k=" . $key;
    $the_Message = "Dear Mr/Mrs/Miss " . $profl['f'] . " " . $profl['o'] . "

Thank you for taking the time to sign up!

You filled the signup form using the Name: \n
" . $profl['f'] . " " . $profl['o'] . "\n
and this email address.\n

Let us know your email is valid by clicking on the link below.\n
If it's not clickable you can copy and paste it into your web browser.\n
The link will expire after twenty four hours (24hrs) time.\n

$the_link\n

Thank You,\n
The " . ucfirst($domain_name) . " team." . PHP_EOL;
    $the_Subject = "Signup Confirmation request from " . ucfirst($domain_name);
if(mail($email, $the_Subject, $the_Message,
     "From: signup@$domain_name\r\n" .
     "Reply-To: info@$domain_name\r\n" .
     "X-Mailer: PHP/" . phpversion())==TRUE){ 
    $return=true;
}
    return $return;
}

function set_session_($id, $value) {
    $_SESSION[$id] = $value;
}

function login_($logins){
  global $ez_db, $smarty, $user_table; $token="";
  if ($ez_db->get_var("SELECT COUNT(`id`) FROM `$user_table` WHERE (`username` ='".$logins['un']."' OR `email`='".$logins['un']."') AND `password`='".$logins['ps']."' AND `keep`=1;")>0) {
      $token=get_token_(25);
      $ez_db->query("UPDATE `$user_table` SET `token`='$token' WHERE (`username` ='".$logins['un']."' OR `email`='".$logins['un']."') AND `password`='".$logins['ps']."' AND `keep`=1;");
      _session(1); set_session_("user_log", $token); header("location:?p=dashboard&t=home");
  }else{
      $smarty->assign("msg", array("type" => "warning", "title" => "Login Fail", "content" => "invalid email/username or password",
            "close" => "true"));
  }
}

function table_navs($cols, $tbname, $cond, $flimit, $limit) {
    global $ez_db;
    $query_result = $ez_db->get_results("SELECT $cols FROM $tbname $cond LIMIT $flimit, $limit");
    return $query_result;
}

function user_signup_($prsnl, $login) {
    global $smarty, $ez_db, $lib_dir,$sites_dir, $user_table, $company_table,$dir_table;
    $return = false; $url="$lib_dir/i/pr/";
    $pic_name=inc_table_($user_table, 'id') . "_".$login['un']."_" . get_file_name_($prsnl['pic']);
    if ($login['cps'] != $login['ps']) {
        $smarty->assign("msg", array("type" => "warning", "title" => "Password Mismatch", "content" => "the password supplied does not match confirm password",
            "close" => "true"));
    } elseif (check_if_exists_($user_table, "username", $login['un']) == false) {
        $smarty->assign("msg", array("type" => "warning", "title" => "Invalid Username: username exist", "content" => "the username supplied is already used by another user",
            "close" => "true"));
    }  elseif (check_email_($prsnl['em']) == false) {
        $smarty->assign("msg", array("type" => "warning", "title" => "Invalid Email", "content" => "the email supplied is invalid","close" => "true"));
    } elseif (check_if_exists_($user_table, "email", $prsnl['em']) == false) {
        $smarty->assign("msg", array("type" => "warning", "title" => "Invalid Email: email exists", "content" => "the email supplied is already used by another user",
            "close" => "true"));
    } elseif (check_if_exists_($user_table, "phone", $prsnl['ph']) == false) {
        $smarty->assign("msg", array("type" => "warning", "title" => "Invalid Phone: phone contact exists", "content" => "a student is already using this phone number.",
            "close" => "true"));
    } elseif (check_phone_($prsnl['ph']) == false) {
        $smarty->assign("msg", array("type" => "warning", "title" => "Invalid Phone", "content" => "the phone number supplied is invalid.",
            "close" => "true"));
    }elseif (check_file_($prsnl['pic'],$pic_name,$url) == false) {
    }else{
        if (send_mail_to_($prsnl['em'], $prsnl) == true) {
            $pic_name=inc_table_($user_table, 'id') . "_".$login['un']."_" . get_file_name_($prsnl['pic']);
            if ($ez_db->query("INSERT INTO `$user_table` (`firstname`,`othernames`,`state`,`city`,`email`,`phone`,`gender`,`profile_pic`,`password`,
                `access`,`date_reg`,`username`,`address`,`country`,`keep`) VALUES('" . $prsnl['f'] . "','" . $prsnl['o'] . "','" . $prsnl['st'] . "','" . $prsnl['ct'] . "',"
                    . "'" . $prsnl['em'] . "','" . $prsnl['ph'] . "','" . $prsnl['gn'] . "','" . $pic_name . "','".$login['ps']."','".$login['ut']."',"
                    . "'".  date("Y-m-d H:i:s"). "','".$login['un']."','" . $prsnl['ad'] . "','" . $prsnl['cn'] . "','1')")) {
                    $smarty->assign("msg", array("type" => "success", "title" => "Signup Success", "content" => "You Can now login to your site account."
                    ,"close" => "true","url"=>"?p=home#login","btn_text"=>"<span class='glypgicon glyphicon-signin'></span> Login",
                        "btn_type"=>"info","size"=>""));
            } else {
                $smarty->assign("msg", array("type" => "succes", "title" => "Signup Error", "content" => "there was an anonymous error while signing up, contact technical maintenance.",
                    "close" => "true"));
            }
        } else {
            $smarty->assign("msg", array("type" => "warning", "title" => "Signup Error: sending confirmation", "content" => "unable to register user because the email system cannot send a confirmation text to the supplied mail.",
                "close" => "true"));
        }
    }
//    one more step to complete
}

function use_if_exists_($p) {
    if (file_exists(use_if_sent_($p) . ".php")) {
        require use_if_sent_($p) . ".php";
    }
}

function use_if_sent_($p) {
    $return = null;
    if (isset($_REQUEST[$p])) {
        $return = filter_var($_REQUEST[$p], FILTER_SANITIZE_STRING);
    }
    return $return;
}

function use_if_set_($obj) {
    $return = null;
    if (isset($obj) && $obj != null) {
        $return = $obj;
    }
    return $return;
}

function use_if_file_($file) {
    $return = null;
    if (isset($_FILES[$file]) and $_FILES[$file] != null) {
        $return = $_FILES[$file];
    }
    return $return;
}
