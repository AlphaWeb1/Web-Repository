<?php global $my_globals;
require_once ("Smarty/Smarty.class.php");
$smarty = new Smarty;
//$smarty->debugging = true;//debug
$smarty->left_delimiter = '<!---{';
$smarty->right_delimiter = '}--->';
$smarty->setTemplateDir("./$sites_dir/templates/");
$smarty->addTemplateDir("./$lib_dir/$page_mgt/$sites_dir/templates/");
$smarty->setCompileDir("./$sites_dir/cache/");
$smarty->setCacheDir("./$sites_dir/");
$smarty->addPluginsDir("./$lib_dir/$page_mgt/$sites_dir/plugins/");
foreach ($my_globals as $key => $value) {
    $smarty->assign($key, $value);
}
$smarty->display("base_style.html");$smarty->display("base_script.html");

