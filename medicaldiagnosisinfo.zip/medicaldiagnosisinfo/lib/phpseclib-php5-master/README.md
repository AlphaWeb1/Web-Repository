# phpseclib-php5

> ## Abandoned! Or, rather, rebranded!
>
> ABANDONED in favour of the 2.0 branch in the phpseclib repository.
>  https://github.com/phpseclib/phpseclib/tree/2.0
>


PHP5 offers several features that PHP4 doesn't offer. This repo takes advantage of those features.

To keep this repo up-to-date with the baseline phpseclib do the following:

```
git remote add base git://github.com/phpseclib/phpseclib
git pull base master
```

Note that this repo is **only** for PHP5 specific enhancements. New features and non-PHP5 bugs need to be discussed in the [phpseclib issue tracker](https://github.com/phpseclib/phpseclib/issues?direction=desc&sort=created&state=closed).
