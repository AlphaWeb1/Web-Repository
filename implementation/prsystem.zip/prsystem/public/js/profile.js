$(document).ready(function(){

	var fname="",email="",password="",password2="",phone="",recovery="",preview="";

	$('#sec-2').hide();
	$('#quest-box2').hide();

	recovery_question();
	updatesecurity();
	update_profile();
        updateothers();
	savepost();

	$(document).on('click','#change-sec',function(){
		$('#sec-2').slideDown();
	});

	function recovery_question(){
		$(document).on('click','.rec-quest2',function(){
			recovery = $('.rec-quest2:checked').val();
			// else if(recover == "pet" || recover == "uncle" || recover == "friend" || recover == "food" ){

			// }
			if(recovery == "supquestion" ){
				$('#quest-box2').show().html('<label for="yquestion2"> Your Question</label>'+
                '<input type="text" id="yquestion2" name="recquest2" class="form-control"'+ 
                'placeholder="Supply your question?" value="" />');
			 }else if(recovery == "pet"){
			 	$('#quest-box2').show().html('<label for="yquestion2"> Your Question</label>'+
			 	 '<input type="text" id="yquestion2" name="recquest2" class="form-control"'+
			 	 'value="What\'s the name of your pet?" disabled />');
			 }else if(recovery == "uncle"){
			 	$('#quest-box2').show().html('<label for="yquestion2"> Your Question</label>'+
			 	 '<input type="text" id="yquestion2" name="recquest2" class="form-control"'+
			 	 'value="What\'s the name of your uncle?" disabled />');
			 }else if(recovery == "friend"){
			 	$('#quest-box2').show().html('<label for="yquestion2"> Your Question</label>'+
			 	 '<input type="text" id="yquestion2" name="recquest2" class="form-control"'+
			 	 'value="What\'s the name of your best friend?" disabled />');
			 }else if(recovery == "food"){
			 	$('#quest-box2').show().html('<label for="yquestion2"> Your Question</label>'+
			 	 '<input type="text" id="yquestion2" name="recquest2" class="form-control"'+
			 	 'value="What\'s the name of your favorite food?" disabled />');
			 }
		});
		
	}

	function updatesecurity(){
		$(document).on('click','#save-sec',function(){
			var ans3 = $('#answer3').val();
			var kwd3 = $('#keyword3').val();
			var quest2 = $('#yquestion2').val();
			if(recovery == ""){
				return;
			}else if(ans3 == ""){
				return;
			}else if(quest2 == ""){
				return;
			}else if(kwd3 == ""){
				return;
			}else{
				$.post(url+'profile/updatesecurity',{qu2:quest2,an3:ans3,kw3:kwd3},function(res){
						alert(res);
					});
			}
		});
	}
        function updateothers(){
		$(document).on('click','#save-chn',function(){
                        var patt = $("#r-ptn").is(':checked'); 
                        var pat=0;
                        if (patt==true){
                            pat=1;
                        }else{
                            pat=0;
                        }
                        $.post(url+'profile/updateothers',{patt:pat},function(res){
                            alert(res);
                        });
		});
	}

	function update_profile(){
		$(document).on('click', '#updateprofile', function(){

			var fname = $('#fname').val(),
			phone = $('#phone').val(),
			address = $('#address').val();

			if(fname=="" || phone==""|| address==""){
			 	$('#error_msg').html('<span style="color:#ff0039;font-size: 12px;font-family: robotobold;"><span class="glyphicon glyphicon-alert"></span>Empty field not allowed');
			 }else if(!preview){
					preview = $("#img-wrap > img").attr('src');
					preview = preview.replace(url, "");
				}
			 else{
			 	preview = preview;
			 	$.post(url+'profile/updateprofile', {fn:fname, phn:phone, addr:address,prv:preview}, function(response){
						$(location).attr('href', window.location.href);
						$('#error-msg').html('<span style="color:green;font-size: 12px;font-family: robotobold;"><span class="glyphicon glyphicon-ok">'+ 
							'</span> Your Profile has been updated successfully');
				});
			 }
		});
	}

	function savepost(){
		$(document).on('click','#post-but',function(){
			var postcont = $('#post-content').val();
			if(postcont === ""){
				$('#post-content').focus();
				return;
			}
				$.post(url+'home/savepost', {posts:postcont}, function(res){
					alert(res);
				});
			
		});
	}

		$("#pic-input").change(function(){
			var type_allowed = "image/jpeg,image/jpg,image/png,image/gif";

				if (this.files && this.files[0]) {
			      	fr = new FileReader();
			      	fr.readAsDataURL(this.files[0]);
			      	fr.onload = function (e) {
			      	    preview = e.target.result;
			      	    type = preview.substring(5, preview.indexOf(";"));
			      	    if (type_allowed.indexOf(type) < 0) {
			      	        alert('Unsupported file type');
			      	   } else {
			      	        $('#pic-wrap').empty();
			      	        $('#pic-wrap').append('<img id="pic-wrap" img-circle" src="' + preview + '">');
			      	    }
		        	};
		    	}
		    	return false;
		});

});