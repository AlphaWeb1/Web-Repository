<?php

class Index extends Controller {

    function __construct() {
        parent::__construct();
        Session::init();
    }

    function index() {
        Session::set('recovery',false);
        $this->view->render("index/index", FALSE);
    }

    function checkmail(){
        $this->model->check_mail($_POST['em']);
    }

    function register(){
    	$this->model->register($_POST['fn'],$_POST['em'],$_POST['pass'],$_POST['ph'],$_POST['qu'],$_POST['an']);
    }

    function login(){
        $this->model->login($_POST['iem'],$_POST['ipass']);
    }

    function logout(){

        Session::destroy();
        header('location:'.URL);
    }

}
