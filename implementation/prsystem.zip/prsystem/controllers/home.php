<?php

class Home extends Controller {

    function __construct() {
        parent::__construct();
        Session::init();
    }

    function index() {
    	$this->view->blogscontent = $this->model->blogcontent();
    	$this->view->blogcontent = $this->model->blogcontent2();
        $this->view->render("home/index", FALSE);
    }

    function savepost(){
    	$this->model->savepost($_POST['posts']);
    }

}
