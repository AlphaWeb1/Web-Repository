<?php

class Home_model extends Model {

    public function __construct() {
        parent::__construct();
    }

    function blogcontent(){
        $sql = $this->db->select("SELECT `signup_tbl`.`email`,`signup_tbl`.`fullname`,`blog_tbl`.`id`,`content`,`blog_date`,`blog_time` FROM `blog_tbl` INNER JOIN `signup_tbl` ON `blog_tbl`.`email` = `signup_tbl`.`email`");
        return $sql;
    }

    function blogcontent2(){
        $sql = $this->db->select("SELECT DISTINCT `signup_tbl`.`email`,`signup_tbl`.`fullname`,`blog_tbl`.`id`,`content`,`blog_date`,`blog_time` FROM `signup_tbl`,`blog_tbl` WHERE `signup_tbl`.`email`=`blog_tbl`.`email` AND"
                . " `blog_tbl`.`email` = '".Session::get('prsemail')."'");

        return $sql;
    }

    function savepost($posts){
        $query = $this->db->insert('blog_tbl', array(
                'email' => Session::get('prsemail'),
                'content' => $posts,
                'blog_date' => date('Y-m-d'),
                'blog_time' => date('h:i:s')
            ));

        // if($query > 0){
        //     echo 'okay';
        // }else{
        //     echo 'notokay';
        // }

    }

}
