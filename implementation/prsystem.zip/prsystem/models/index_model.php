<?php

class Index_model extends Model {

    public function __construct() {
        parent::__construct();
    }

    function check_mail($mail) {
        // Remove all illegal characters from email
        $email = filter_var($_POST['em'], FILTER_SANITIZE_EMAIL);

        // Validate e-mail
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
            $query = $this->db->select("SELECT id FROM signup_tbl WHERE email = '$email' LIMIT 1");
            if (count($query) < 1) {
                echo '<span style="color:#257D08;font-size: 12px;font-family: robotobold;"><span class="glyphicon glyphicon-ok"></span> ' . $mail . ' is OK </span>';
                exit();
            } else {
                echo '<span style="color:#ff0039;font-size: 12px;font-family: robotobold;"><span class="glyphicon glyphicon-remove"></span> ' . $mail . ' already exist in our system';
                exit();
            }
        } else {
            echo '<span style="color:#ff0039;font-size: 12px;font-family: robotobold;"><span class="glyphicon glyphicon-remove"></span> ' . $_POST['e'] . ' not a valid email address';
        }
    }

    function register($fname,$email,$pass,$phone,$question,$answer) {
        // echo $email;
        $query = $this->db->select("SELECT id FROM signup_tbl WHERE email = '$email' LIMIT 1");
        if(count($query) > 0){
            
            echo '<span style="color:#ff0039;font-size: 12px;font-family: robotobold;"><span class="glyphicon glyphicon-remove"></span> User already exist, please login';
                exit();
        }else{
                $st = $this->db->insert('signup_tbl', array(
                'fullname' => $fname,
                'email' => $email,
                'password' => $pass,
                'phone' => $phone
                ));

                $st2 = $this->db->insert('security_quest', array(
                'email'  => $email,
                'recovery_quest' => $question,
                'recovery_ans' => $answer
                    ));
            echo '<span style="color:#00ff39;font-size: 12px;font-family: robotobold;"><span class="glyphicon glyphicon-remove"></span> User Successfully Created with Username: '.$email.'and Password: '.$pass;
                // echo 'account successfully created';
        }
        
        // $this->login($email, $pass);
    }

    function login($email, $pass) {
        $sql = $this->db->select("SELECT email, password FROM signup_tbl WHERE email=:email AND password=:password", array(":email"=>$email, ":password"=>$pass));
        
        foreach ($sql as $key => $value) {}

        if(count($sql) > 0){
            Session::set('activeUser', true);
            Session::set('prsemail', $value['email']);
            echo '1';
        }else{
            
        }
                
           }

}
