<?php
class Recovery_model extends Model {

    public function __construct() {
        parent::__construct();
    }
    public function get_info(){
        $param = array(
            ':email' => $_POST['get_email']
        );
        Session::set("usmail", $_POST['get_email']);
        $sql= $this->db->select("SELECT `enable_pattern`,`recovery_quest` FROM `security_quest` WHERE (`security_quest`.`email`=:email)",$param);
        return json_encode($sql);
    }
    public function check_pattern(){
        $param=array(
            ':email' => Session::get("usmail")
        );
        $keyw=$_POST['keyw'];
        $ans=$_POST['answ'];
        $bovero=-1;
        $string='<span style="color:#ff0039;font-size: 12px;font-family: robotobold;"><span class="glyphicon glyphicon-remove"></span> Supplied Answer is not Valid ';
        $sql= $this->db->select("SELECT `keyword`,`recovery_ans`,`password` FROM `security_quest`,`signup_tbl` WHERE (`security_quest`.`email`=:email) AND `signup_tbl`.`email`=`security_quest`.`email` ",$param);
        foreach ($sql as $key => $value) {}
        if (count($sql) > 0) {
            if (strtolower($value['keyword'])==  strtolower($keyw)) {
                if (strtolower($value['recovery_ans'])== strtolower($ans)) {
                    $string='<span style="color:#00ff39;font-size: 12px;font-family: robotobold;"><span class="glyphicon glyphicon-remove"></span> |Pattern Check Is Successfull| Your Account Password is ( '.$value['password'].' )';
                }else{
                    $bovero= $this->boyerMoore(strtolower($ans), strtolower($keyw));
                    if ($bovero>-1) {
                        $string='<span style="color:#00ff39;font-size: 12px;font-family: robotobold;"><span class="glyphicon glyphicon-remove"></span> |Pattern Check Is Successfull| Your Account Password is ( '.$value['password'].' )';
                    }else{
                        $string='<span style="color:#ff0039;font-size: 12px;font-family: robotobold;"><span class="glyphicon glyphicon-remove"></span> Patter Check Cannot Recover Account Password Check Your Answer!!!';
                    }
                }
            }else{
                $string='<span style="color:#ff0039;font-size: 12px;font-family: robotobold;"><span class="glyphicon glyphicon-remove"></span> Supplied Keyword is not Valid, Enter a Valid Keyword!!! ';
            }
        }
        return $string;
    }
    public function check_normal(){
        $param=array(
            ':email' => Session::get("usmail")
        );
        $string='<span style="color:#ff0039;font-size: 12px;font-family: robotobold;"><span class="glyphicon glyphicon-remove"></span> Supplied Answer is not Valid, Enter a Valid Answer!!!';
        $sql= $this->db->select("SELECT `security_quest`.`recovery_ans`,`signup_tbl`.`password` FROM `security_quest`,`signup_tbl` WHERE (`security_quest`.`email`=:email) AND `signup_tbl`.`email`=`security_quest`.`email` ",$param);
        foreach ($sql as $key => $value) {}
        if (count($sql) > 0) {
            if (strtolower($value['recovery_ans'])==  strtolower($_POST['answ'])) {
                $string='<span style="color:#00ff39;font-size: 12px;font-family: robotobold;"><span class="glyphicon glyphicon-remove"></span> Your Account Password is ( '.$value['password'].' )';
            }else{
                $string='<span style="color:#ff0039;font-size: 12px;font-family: robotobold;"><span class="glyphicon glyphicon-remove"></span> Supplied Answer is not Valid, Enter a Valid Answer!!!';
            }
        }
        return $string;
    }
    function check_mail($param) {
        $chst='0';
        $param = array(
            ':email' => $param
        );
        $sql= $this->db->select("SELECT `email` FROM `security_quest` WHERE (`email`=:email) ",$param);
        foreach ($sql as $key => $value) {}
        if (count($sql) > 0) {
            $chst='1';
        }
        return $chst;
    }
   
    function boyerMoore($text, $pattern) {
        $patlen = strlen($pattern);
        $textlen = strlen($text);
        $table = $this->makeCharTable($pattern);

        for ($i=$patlen-1; $i < $textlen;) { 
            $t = $i;
            for ($j=$patlen-1; $pattern[$j]==$text[$i]; $j--,$i--) { 
                if($j == 0){ return $i;}
            }
            $i = $t;
            if(array_key_exists($text[$i], $table)){
                $i = $i + max($table[$text[$i]], 1);
            }else{
                $i += $patlen;
            }
        }
        return -1;
    }

    function makeCharTable($string) {
        $len = strlen($string);
        $table = array();
        for ($i=0; $i < $len; $i++) { 
            $table[$string[$i]] = $len - $i - 1; 
        }
        return $table;
    }
}