<!DOCTYPE html>
<html>
    <head>
  
        <title>Password Recovery System</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="" />


        <link href="<?php echo URL;?>public/css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all" />
        <link href="<?php echo URL;?>public/css/jquery-ui.min.css" rel="stylesheet" type="text/css" media="all" />
        <link href="<?php echo URL;?>public/css/style.css" rel="stylesheet" type="text/css" media="all" />

        <script src="<?php echo URL;?>public/js/jquery-1.11.1.min.js"></script>
        <script src="<?php echo URL;?>public/js/jquery-ui.min.js"></script>
    </head>

    <body>

    <div class="container">
        <nav class="navbar navbar-inverse">
            <div class="container-fluid">
            <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-2">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#">PR System</a>
            </div>
                <ul class="nav navbar-nav navbar-right">
                    <div class="col-lg-1"></div>
                </ul>
            <?php Session::init(); 
                if(Session::get('recovery') == true): ?>
                <ul class="nav navbar-nav navbar-right">
                    <a href="<?php echo URL; ?>" class="btn btn-info">Login</a>
                    <div class="col-lg-1"></div>
                </ul>
            <?php endif; 
                if(Session::get('activeUser') == false): ?>
                <ul class="nav navbar-nav navbar-right">
                    <button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal">Sign up</button>
                </ul>
            <?php else:?>
                <ul class="nav navbar-nav navbar-right">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                    <?php echo Session::get('prsemail');?> <span class="caret"></span></a>

                    <ul class="dropdown-menu" role="menu">
                        <li><a href="<?php echo URL;?>profile/index"><span class="glyphicon glyphicon-user"></span> Profile</a></li>
                        <li class="divider"></li>
                        <li><a href="<?php echo URL;?>home"><span class="glyphicon glyphicon-book"></span> Blogs</a></li>
                        <li class="divider"></li>
                        <li><a href="<?php echo URL?>index/logout">
                        <span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
                     </ul>
                </li>
                </ul>
            </div>
            <?php endif;?>
        </nav>
    </div>
            

