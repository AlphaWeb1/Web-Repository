<div class="container">
    <div class="col-sm-8">
        <div>
            <textarea title="Type your blog" name="postarea" id="post-content" class="form-control text-primary input-md post-txt" rows="2" cols="50" placeholder="Type your blog" required></textarea> 
        </div>
        <div id="post-btn">
            <button type="submit" id="post-but" class="btn btn-success input-sm">Post</button>
        </div>
        <?php
          foreach($this->blogscontent as $key => $value) {?>
        <div>
            <div id="blog-cont">
               <div class="col-sm-4">
                    <div class="b-name">
                        <img src="<?php echo URL.'public/images/dave1.jpg'?>" class="" id="blog-pic">
                        <?php echo $value['fullname'];?>
                    </div>
                    <div><?php echo $value['blog_date'];?></div>
               </div>
               <div class="col-sm-8">
                <div class="b-cont">
                <?php echo $value['content'];?>
                </div>
               </div> 
            </div>
        </div>
        <?php }?>
    </div>

    <div class="col-sm-4">
        <div>My Blogs</div>
        <?php
          foreach($this->blogcontent as $key => $value) {?>
        <div>
            <div id="blog-cont2">
                <?php echo $value['content'];?>
                <br class="well-sm"/>
                <div><?php echo $value['blog_date']." ".$value['blog_time'];?></div>
            </div>
        </div>
        <?php }?>
    </div>
</div>