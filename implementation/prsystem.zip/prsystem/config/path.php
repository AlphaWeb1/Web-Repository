<?php

  define('URL', 'http://localhost/prsystem/');
  define('HASH_GENERAL_KEY', 'MixitUp200');
// This is for database passwords only
  define('HASH_PASSWORD_KEY', 'catsFLYhigh2000miles');