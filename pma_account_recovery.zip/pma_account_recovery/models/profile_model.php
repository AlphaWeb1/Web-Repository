<?php

class Profile_model extends Model {

    public function __construct() {
        parent::__construct();
    }

    function updatesecurity($question2, $answer3,$keyword3){
        // echo $question2. '-'. $answer3; return;
        $query = $this->db->exec("UPDATE `security_quest` SET `recovery_quest` = '$question2', `recovery_ans` = '$answer3', `keyword` = '$keyword3' WHERE `email` = '".Session::get('prsemail')."' ");
        if ($query > 0) {
            echo 'Security Info Successfully Updated';
           return $this->fetchprofile();
        }else{
            echo 'notokay';
        }
    }
        function updateothers($params){
        // echo $question2. '-'. $answer3; return;
        $query = $this->db->exec("UPDATE `security_quest` SET `enable_pattern` = '$params' WHERE `email` = '".Session::get('prsemail')."' ");
        
            echo 'Pattern Check Enability is Successfully Updated';
           return $this->fetchprofile();
        
    }

    function fetchprofile() {
        $param = array(
            ':email' => Session::get('prsemail')
        );
        $sql = $this->db->select("SELECT `fullname`,`phone`,`signup_tbl`.`email`,`address`,`recovery_quest`,`recovery_ans`,`pic_path`,`enable_pattern`,`enable_email`,`enable_phone` FROM `signup_tbl`,`security_quest` WHERE (`signup_tbl`.`email`=`security_quest`.`email`) "
                . " AND `signup_tbl`.`email`=:email",$param);
        foreach ($sql as $key => $value) {}
        if (count($sql) > 0) {
            Session::set('fullname', $value['fullname']);
            Session::set('phone', $value['phone']);
            Session::set('address', $value['address']);
            Session::set('prsemail', $value['email']);
        }
        return $sql;
    }

    function updateprofile($fname, $phone, $address, $pict) {
            $dataname1 = Session::get('prsemail').'.jpg';
            $file1 = $this->base64_to_jpeg($pict,$dataname1);
            $dir1 = 'public/images/profile_images';
            if (!file_exists($dir1)) {
                mkdir($dir1, 0777, true);   
            }
            if(file_exists($dir1.'/'.$file1)){
                copy($file1, $dir1.'/'.$file1);
            }else{
            copy($file1, $dir1.'/'.$file1);
            }
            $file_dir = $dir1.'/'.$file1;
        $query = $this->db->exec("UPDATE signup_tbl SET fullname = '$fname', phone='$phone', address='$address', pic_path='$file_dir' WHERE email = '" . Session::get('prsemail') . "'");
            $this->fetchprofile();
    }

    function base64_to_jpeg($base64_string, $output_file) {
        $ifp = fopen($output_file, "wb");

        $data = explode(',', $base64_string);

        fwrite($ifp, base64_decode($data[1]));
        fclose($ifp);

        return $output_file;
    }

}
