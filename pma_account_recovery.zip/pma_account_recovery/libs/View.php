<?php

class View {

    function __construct() {
 
    }

    public function render($name, $noInclude = true) {
        $path = 'views/' . $name . '.php';
        
        if ($noInclude == false) {
            require 'views/header.php';
            require $path;
            require 'views/footer.php';
        } else {
            require $path;
        }
    }

}
