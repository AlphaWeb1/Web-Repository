<?php
class Recovery  extends Controller{
    function __construct() {
        parent::__construct();
        Session::init();
    }

    function index() {
        Session::set('recovery',true);
        $this->view->render("index/recovery", FALSE);
    }

    function get_info(){
        echo $this->model->get_info();
    }

    function check_pattern(){
    	$this->model->check_pattern();
    }

    function check_opt(){
        $opt=$_POST['stat'];
        if ($opt=='1') {
            echo $this->model->check_pattern();
        }else{
            echo $this->model->check_normal();
        }
    	
    }

    function check_mail() {
        echo $this->model->check_mail($_POST['get_email']);
    }

}
