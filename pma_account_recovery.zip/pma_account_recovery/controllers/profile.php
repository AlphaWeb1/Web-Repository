<?php

class Profile extends Controller {

    function __construct() {
        parent::__construct();
        Session::init();
    }

    function index() {
    	$this->view->userinfo = $this->model->fetchprofile();
        $this->view->render("home/profile", FALSE);
    }

    function updatesecurity(){
    	$this->view->userinfo =$this->model->updatesecurity($_POST['qu2'],$_POST['an3'],$_POST['kw3']);
//            header("location:http://localhost/pma_account_recovery/profile/index");
    }
    function updateothers(){
    	$this->model->updateothers($_POST['patt']);
    }

    function updateprofile(){
        if($_POST['fn']==""||$_POST['phn']==""||$_POST['addr']==""){
            echo '0';
            exit();
        }
    	$this->model->updateprofile($_POST['fn'],$_POST['phn'],$_POST['addr'],$_POST['prv']);
    }

}
