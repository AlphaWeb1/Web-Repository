var url = "http://localhost/pma_account_recovery/";
jQuery(document).ready(function(){

	var fname="",email="",password="",password2="",phone="",recover="";

	login();
	checkmail();
	personal_details();
	recovery_quest();
	register();

	$('#quest-box').hide();
	$('#reg-2').hide();
	$('#reg-span1').hide();

	$(document).on('click','#reg-span1',function(){
		$('#reg-1').slideDown();
		$('#reg-span1').hide();
	});

	function checkmail(){
		$(document).on('blur','#email',function(){
			email = $('#email').val();
			$.post(url+'index/checkmail',{em:email},function(res){
				$('#email_error').html(res);
			});
		});
	}

	function personal_details(){
		$(document).on('click','#reg-next',function(){

		fname = $('#fname').val();
		email = $('#email').val();
		password = $('#password').val();
		password2 = $('#cpassword').val();
		phone = $('#phone').val();

		if(fname == "" || email == "" || password == "" || password2 == "" || phone == ""){
			$('#pr-warning').html('<span style="color:#ff0039;font-size: 12px;font-family: robotobold;"><span class="glyphicon glyphicon-alert">'+
				'</span>None of the fields can be left empty');
			return;
		}else if(password !== password2){
			$('#p-warning').html('<span style="color:#ff0039;font-size: 12px;font-family: robotobold;"><span class="glyphicon glyphicon-alert">'+
				'</span>password does not match');
			return;
		}
		else{
			$('#reg-1').slideUp();
			$('#reg-2').slideDown();
			$('#reg-span1').show();
		}	
		
		});
	}

	function recovery_quest(){
		$(document).on('click','.rec-quest',function(){
			recover = $('.rec-quest:checked').val();
			// else if(recover == "pet" || recover == "uncle" || recover == "friend" || recover == "food" ){

			// }
			if(recover == "supquestion" ){
				$('#quest-box').show().html('<label for="yquestion"> Your Question</label>'+
                '<input type="text" id="yquestion" name="recquest" class="form-control"'+ 
                'placeholder="Supply your question?" value="" />');
			 }else if(recover == "pet"){
			 	$('#quest-box').show().html('<label for="yquestion"> Your Question</label>'+
			 	 '<input type="text" id="yquestion" name="recquest" class="form-control"'+
			 	 'value="What\'s the name of your pet?" disabled />');
			 }else if(recover == "uncle"){
			 	$('#quest-box').show().html('<label for="yquestion"> Your Question</label>'+
			 	 '<input type="text" id="yquestion" name="recquest" class="form-control"'+
			 	 'value="What\'s the name of your uncle?" disabled />');
			 }else if(recover == "friend"){
			 	$('#quest-box').show().html('<label for="yquestion"> Your Question</label>'+
			 	 '<input type="text" id="yquestion" name="recquest" class="form-control"'+
			 	 'value="What\'s the name of your best friend?" disabled />');
			 }else if(recover == "food"){
			 	$('#quest-box').show().html('<label for="yquestion"> Your Question</label>'+
			 	 '<input type="text" id="yquestion" name="recquest" class="form-control"'+
			 	 'value="What\'s the name of your favorite food?" disabled />');
			 }
		});
		
	}

	function register(){
		$(document).on('click','#register',function(){
			var ans = $('#answer').val();
			var quest = $('#yquestion').val();
			if(recover == ""){
				return;
			}else if(ans == ""){
				return;
			}else{
				$.post(url+'index/register',{fn:fname,em:email,pass:password,ph:phone,qu:quest,an:ans},function(res){
					$('#hint').html(res);
					});
				// });
			}
		});
	}

	function login(){
		$('form#login').submit(function(){
			var iemail = $('#inputEmail').val(),
				ipass = $('#inputPassword').val();

			if(iemail == "" || ipass == ""){
				return;
			}else{
				$.post(url+'index/login',{iem:iemail,ipass:ipass},function(res){
					if(res === '1'){
						window.location = url+'home/index';
					}else{
						$('#loginerror').html('<span style="color:#ff0039;font-size: 12px;font-family: robotobold;"><span class="glyphicon glyphicon-remove"></span> Invalid Username or Password');
					}
				});
			}
	});

	}
	
});