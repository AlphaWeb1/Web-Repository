$(document).ready(function(){
    $('.recove').hide();
    function change_state(){
        $(document).on('click','#get-sec',function (){
            var get_email=$("#inputEmail").val();
            if (get_email==''){
                $('#oscrup').html('<span style="color:#ff0039;font-size: 12px;font-family: robotobold;"><span class="glyphicon glyphicon-remove"></span> Empty Email is Not Valid');
            }else{
                $.post('http://localhost/pma_account_recovery/recovery/check_mail',{get_email:get_email},function(res){
                    if(res=='1'){
                        $.post('http://localhost/pma_account_recovery/recovery/get_info',{get_email:get_email},function(resp){
                            var obj =JSON.parse(resp);
                            $.each(obj,function(key,data){
                                if (data.enable_pattern=='1'){
                                    $("#patter").html('<label>Pattern Status: </label><span class="glyphicon glyphicon-open"></span>');
                                    $("#respc").html('<label for="r-ans" class="col-md-2">Answer:</label>'+
                                        '<div class="col-md-10">'+
                                            '<input type="text" id="r-ans" name="r-ans" class="form-control" placeholder="Security Answer" value=""/>'+
                                        '</div>'+
                                        '<label for="r-key" class="col-md-2">Keyword:</label>'+
                                        '<div class="col-md-5">'+
                                            '<input type="text" id="r-key" name="r-key" class="form-control" placeholder="Keyword" value=""/>'+
                                            '<div id="oscrupg"></div>'+
                                        '</div>');
                                }else{
                                    $("#patter").html('<label>Pattern Status: </label><span class="glyphicon glyphicon-lock"></span>');
                                    $("#respc").html('<label for="r-ans" class="col-md-2">Answer:</label>'+
                                        '<div class="col-md-10">'+
                                            '<input type="text" id="r-ans" name="r-ans" class="form-control" placeholder="Security Answer" value=""/>'+
                                            '<div id="oscrupg"></div>'+
                                        '</div>');
                                }
                                $("#secur-quest").html('<label for="s-quest">Security Question:</label> '+data.recovery_quest);
                                $("#r-ans").attr('code',data.enable_pattern)
                            });
                        });
                        $('.recove').show();$('.recov').hide();
                    }else{
                        $('#oscrup').html('<span style="color:#ff0039;font-size: 12px;font-family: robotobold;"><span class="glyphicon glyphicon-remove"></span> Supplied mail is not Registered Email');
                    }
                });
            }
        });
    }
    function  verify(){
        $(document).on('click','#verf-sec',function (){
            var keyw=""; 
            var answ=$("#r-ans").val();
            var rstat=$("#r-ans").attr('code');
            var param={answ:answ,stat:rstat};
            if (rstat=='1'){
              keyw= $("#r-key").val(); 
              param={answ:answ,stat:rstat,keyw:keyw};
            }
            $.post('http://localhost/pma_account_recovery/recovery/check_opt',param,function(resp){ 
                $('#oscrupg').html(resp);
            });
        });
    }
    verify();
    change_state();
});