<?php

  define('URL', 'http://localhost/pma_account_recovery/');
  define('HASH_GENERAL_KEY', 'MixitUp200');
// This is for database passwords only
  define('HASH_PASSWORD_KEY', 'catsFLYhigh2000miles');