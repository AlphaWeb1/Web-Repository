<?php
// print_r($this->userinfo);
foreach ($this->userinfo as $key => $value) {
    
}
?>
<div class="container">
    <div class="col-sm-6">
        <h4 id="p-head" data-toggle="collapse" data-target="#mycollapse">Personal Profile Settings</h4>
        <form  method="post" onsubmit="return false;" class="collapse collapsed" id="mycollapse">
            <fieldset>
                <div class="ppics">
                    <label for="pic-input">
                        <div id="pic-wrap">
                            <img class="img-circle" src="<?php echo URL . $value['pic_path']; ?>">
                        </div>
                    </label>
                    <input type="file" id="pic-input" />
                </div>
                <div class="form-group">
                    <label for="fname"> Full Name</label>
                    <input type="text" id="fname" name="fname" class="form-control" placeholder="firstname" value="<?php echo $value['fullname']; ?>" />
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" placeholder="Email" value="<?php echo $value['email']; ?>" disabled/>
                </div>
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="number" id="phone" name="phone" class="form-control" placeholder="phone" value="<?php echo $value['phone']; ?>"/>
                </div>
                <div class="form-group">
                    <label for="address"> Address</label>
                    <input type="text" id="address" name="address" class="form-control" placeholder="Address" value="<?php echo $value['address']; ?>"/>
                </div>
                <div id="error-msg"></div>
                <button type="submit" id="updateprofile" class="btn btn-primary input-md pull-right" name="btnUpdate">Save</button>
            </fieldset>
        </form>
    </div>
    <div class="col-sm-6">
        <h4 id="p-head" data-toggle="collapse" data-target="#mycollapse1">Security Settings</h4>
        <div  class="collapse" id="mycollapse1">
            <div>
                <div class="col-sm-12">
<!--                    <form  method="post" onsubmit="return false;">
                        <fieldset>-->
                            <label>Enable Pattern Check <input type="checkbox" id="r-ptn" name="secopts" class="form-control" value="<?php echo $value['enable_pattern']; ?>" <?php if ($value['enable_pattern'] == 1) { ?>checked<?php } ?>/>
                            </label><br/>
             <!--               <label>Enable Mail Check<input type="checkbox" id="r-ans" name="secopts" class="form-control" value="<?php //echo $value['enable_email'];   ?>" <?php //if($value['enable_email']==1){  ?>checked<?php //}  ?>/>
                            </label><br/>
                            <label>Enable Phone Check<input type="checkbox" id="r-ans" name="secopts" class="form-control" value="<?php //echo $value['enable_phone']; ?>" <?php //if($value['enable_phone']==1){ ?>checked<?php //} ?>/>
                            </label>-->
                            <button type="submit" class="col-lg-4 btn btn-info input-md" id="save-chn">Save Change</button>
<!--                        </fieldset>
                    </form>-->
                </div>
                <div id="pr-qst">Question: <?php echo $value['recovery_quest']; ?></div>
                <div class="form-group">
                    <label for="r-ans">Answer</label>
                    <input type="text" id="r-ans" name="answer2" class="form-control" placeholder="" value="<?php echo $value['recovery_ans']; ?>" disabled/>
                </div> 
                <button type="button" class="btn btn-info input-md" id="change-sec">Change Security Question</button>
            </div>
            <div>
                <div id="sec-2">
                    <h4 id="recovery-quest">Choose a Recovery Question</h4>
                    <div class="form-group">
                        <label for="pet2"> What's the name of your pet?</label>
                        <input type="radio" class="rec-quest2" id="pet2" name="recquest2" value="pet"/> 
                    </div> 
                    <div class="form-group">
                        <label for="uncle2"> What's the name of your uncle?</label>
                        <input type="radio" class="rec-quest2" id="uncle2" name="recquest2" value="uncle"/> 
                    </div> 
                    <div class="form-group">
                        <label for="friend2"> What's the name of your best friend?</label>
                        <input type="radio" class="rec-quest2" id="friend2" name="recquest2" value="friend"/> 
                    </div> 
                    <div class="form-group">
                        <label for="food2"> What's the name of your favorite food?</label>
                        <input type="radio" class="rec-quest2" id="food2" name="recquest2" value="food"/> 
                    </div> 
                    <div class="form-group">
                        <label for="supquestion2"> Supply your own question</label>
                        <input type="radio" class="rec-quest2" id="supquest2" name="recquest2" value="supquestion"/> 
                    </div> 
                    <div id="quest-box2" class="form-group">
                        <label for="yquestion2"> Your Question</label>
                        <input type="text" id="yquestion2" name="recquest2" class="form-control" placeholder="Supply your question?" value="" /> 
                    </div>
                    <div class="form-group">
                        <label for="answer3"> Answer</label>
                        <input type="text" id="answer3" name="answer3" class="form-control" value="" placeholder="Supply your answer?"/> 
                    </div>
                    <div class="form-group">
                        <label for="keyword3" title="The main word to remind you of the Answer"> Keyword</label>
                        <input type="text" title="The main word to remind you of the Answer" id="keyword3" name="keyword3" placeholder="Supply a keyword from your answer?" class="form-control" value="" /> 
                    </div>
                    <div class="form-group">
                        <div id="hint"></div>
                        <button type="submit" id="save-sec" class="btn btn-primary">Save</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>