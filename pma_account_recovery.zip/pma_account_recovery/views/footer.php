<div class="container">
<footer id="foot">
</div>
    
</footer>


<script src="<?php echo URL;?>public/js/bootstrap.js"></script>
<script src="<?php echo URL;?>public/js/SmoothScroll.js"></script>
<script type="text/javascript" src="<?php echo URL;?>public/js/index.js"></script>
<script type="text/javascript" src="<?php echo URL;?>public/js/profile.js"></script>
<script type="text/javascript" src="<?php echo URL;?>public/js/recovery.js"></script>
</body>
</html>