<?php ?>
<div class="container">
    <div class="form-cont">
        <legend class="leg-post">Recovery Page</legend>
        <div class="form-cont2">
            <form class="form-horizontal" id="login" method="post" onsubmit="return false;">
                <fieldset>
                    <div class="recov">
                        <div class="form-group">
                            <label for="inputEmail" class="col-md-2">Email:</label>
                            <div class="col-md-10">
                                <input class="form-control" id="inputEmail" placeholder="Email" type="text">
                                <div id="oscrup"></div>
                            </div>
                        </div>
                        <div class="form-group">
                            <button type="buttion" class="btn btn-primary" id="get-sec">Fetch Security Question</button>
                        </div>
                        <hr/>
                    </div>
                    <div class="recove">
                        <!--<h4 id="p-head">Security Settings</h4>-->
                        <div id="patter"><label>Pattern Status: </label>

                        </div>
                        <div id="secur-quest"><label for="s-quest">Security Question:</label></div>
                        <br class="well-sm"/>
                        <div class="form-group" id="respc">
                            <label for="r-ans" class="col-md-2">Answer:</label>
                            <div class="col-md-10">
                                <input type="text" id="r-ans" name="r-ans" class="form-control" placeholder="Security Answer" value=""/>
                                <div id="oscrupg"></div>
                            </div>
                        </div> 
                        <div class="form-group">
                            <button type="buttion" class="btn btn-success" id="verf-sec">Check and Recover</button>
                        </div>
                    </div>
                </fieldset>
            </form>
        </div>
    </div>

    <div id="myModal" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Register</h4>
                </div>
                <div class="modal-body">
                    <form action="<?php echo URL; ?>profile/UserProfileUpdate" method="post" onsubmit="return false;">
                        <h4 id="personal-det">Personal Info <span id="reg-span1" class="glyphicon glyphicon-chevron-down"></span></h4>
                        <fieldset>  
                            <div id="reg-1">
                                <div class="form-group">
                                    <label for="fname"> Full Name</label>
                                    <input type="text" id="fname" name="fname" class="form-control" placeholder="fullname" value="" /> 
                                </div> 
                                <div class="form-group">
                                    <label for="email"> Email</label>
                                    <input type="email" id="email" name="email" class="form-control" placeholder="email" value="" /> 
                                    <span id="email_error"></span>
                                </div>
                                <div class="form-group">
                                    <label for="password"> Password</label>
                                    <input type="password" id="password" name="password" class="form-control" placeholder="" value="" /> 
                                </div> 
                                <div class="form-group">
                                    <label for="cpassword"> Confirm Password</label>
                                    <input type="password" id="cpassword" name="cpassword" class="form-control" placeholder="" value="" /> 
                                    <div id="p-warning"></div>
                                </div>
                                <div class="form-group">
                                    <label for="password"> Phone</label>
                                    <input type="text" id="phone" name="phone" class="form-control" placeholder="phone" value="" /> 
                                </div> 
                                <div id="pr-warning"></div>
                                <button type="button" class="btn btn-default" id="reg-next">Next</button> 
                            </div>

                            <h4 id="recovery-quest">Recovery Question</h4>
                            <div id="reg-2">
                                <div class="form-group">
                                    <label for="pet"> What's the name of your pet?</label>
                                    <input type="radio" class="rec-quest" id="pet" name="recquest" value="pet"/> 
                                </div> 
                                <div class="form-group">
                                    <label for="uncle"> What's the name of your uncle?</label>
                                    <input type="radio" class="rec-quest" id="uncle" name="recquest" value="uncle"/> 
                                </div> 
                                <div class="form-group">
                                    <label for="friend"> What's the name of your best friend?</label>
                                    <input type="radio" class="rec-quest" id="friend" name="recquest" value="friend"/> 
                                </div> 
                                <div class="form-group">
                                    <label for="food"> What's the name of your favorite food?</label>
                                    <input type="radio" class="rec-quest" id="food" name="recquest" value="food"/> 
                                </div> 
                                <div class="form-group">
                                    <label for="supquestion"> Supply your own question</label>
                                    <input type="radio" class="rec-quest" id="supquest" name="recquest" value="supquestion"/> 
                                </div> 
                                <div id="quest-box" class="form-group">
                                    <label for="yquestion"> Your Question</label>
                                    <input type="text" id="yquestion" name="recquest" class="form-control" placeholder="Supply your question?" value="" /> 
                                </div>
                                <div class="form-group">
                                    <label for="answer"> Answer</label>
                                    <input type="text" id="answer" name="answer" class="form-control" value="" /> 
                                </div>
                                <div class="form-group">
                                    <div id="hint"></div>
                                    <button type="submit" id="register" class="btn btn-primary">Submit</button>
                                </div>
                            </div>

                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
